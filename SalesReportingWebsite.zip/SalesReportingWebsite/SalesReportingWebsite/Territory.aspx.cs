﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SalesReportingWebsite
{
    public partial class Territory : PageBase
    {
        public int memberships;
        protected void Page_Load(object sender, EventArgs e)
        {

            //VBFunctions.ADFunctions obj = new VBFunctions.ADFunctions();
            //string userID = obj.GetUserName();
            //// string dirEntry = obj.GetDirectoryEntry();
            //memberships = obj.VerifyGroupMemberships("LDAP://192.168.100.3/ou=Cooper Network Users,dc=coopersurgical1,dc=com", "coopservice", "^CSIServ2016!", userID);

            if (!Page.IsPostBack)

            {
                TerritoryReportingChild li = new TerritoryReportingChild();

                DataTable table = new DataTable();



                ddlTerritoryName.DataSource = li.TerritoryNameList().Tables[0];
                ddlTerritoryName.DataTextField = "TerritoryName";
                ddlTerritoryName.DataBind();

                ddlTerritoryManagerName.DataSource = li.TerritoryManagerNameList().Tables[0];
                ddlTerritoryManagerName.DataTextField = "TerritoryManagerName";
                ddlTerritoryManagerName.DataBind();


                ddlRegionName.DataSource = li.RegionNameList().Tables[0];
                ddlRegionName.DataTextField = "RegionName";
                ddlRegionName.DataBind();

                ddlCompanyName.DataSource = li.CompanyNameList().Tables[0];
                ddlCompanyName.DataTextField = "CompanyName";
                ddlCompanyName.DataBind();


                newTerritoryManagerName.DataSource = li.TerritoryManagerNameList().Tables[0];
                newTerritoryManagerName.DataTextField = "TerritoryManagerName";
                newTerritoryManagerName.DataBind();

                newRegionName.DataSource = li.RegionNameList().Tables[0];
                newRegionName.DataTextField = "RegionName";
                newRegionName.DataBind();

                newCompanyName.DataSource = li.CompanyNameList().Tables[0];
                newCompanyName.DataTextField = "CompanyName";
                newCompanyName.DataBind();

                BindGridView();
            }
        }

        #region EventHandling

        protected void Territory_RowEditing(object sender, GridViewEditEventArgs e)
        {
            TerritoryGridView.EditIndex = e.NewEditIndex;
            int index = e.NewEditIndex;
            GridViewRow row = TerritoryGridView.Rows[e.NewEditIndex];

            BindGridView();
        }

        protected void Territory_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            TerritoryGridView.EditIndex = -1;
            BindGridView();
        }


        protected void Territory_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            if (Page.IsValid)
            {
                TerritoryReportingChild li = new TerritoryReportingChild();
                GridViewRow row = TerritoryGridView.Rows[e.RowIndex];
                string display = "";
                bool isFormFilled = true;
                try
                {
                    li.TerritoryID = Convert.ToInt32(TerritoryGridView.DataKeys[e.RowIndex].Values[0]);

                    if (((TextBox)row.FindControl("TerritoryCode")).Text != string.Empty)
                    {
                        li.TerritoryCode = Convert.ToInt32(((TextBox)row.FindControl("TerritoryCode")).Text);
                    }
                    else
                    {
                        display = "Territory Code cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (((TextBox)row.FindControl("TerritoryName")).Text != string.Empty)
                    {
                        li.TerritoryName = Convert.ToString(((TextBox)row.FindControl("TerritoryName")).Text);
                    }
                    else
                    {
                        display = "Territory Name cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    

                    if (((DropDownList)row.FindControl("TerritoryManager")).SelectedValue != "Select One")
                    {
                        li.TerritoryManagerName = Convert.ToString(((DropDownList)row.FindControl("TerritoryManagerID")).SelectedValue);
                    }
                    else
                    {
                        display = "Select  Territory Manager Name from dropdown";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }


                    

                    if (((DropDownList)row.FindControl("RegionName")).SelectedValue != "Select One")
                    {
                        li.RegionName = ((DropDownList)row.FindControl("RegionName")).SelectedValue;
                    }
                    else
                    {
                        display = "Select Region Name from dropdown";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }


                    if (((DropDownList)row.FindControl("CompanyName")).SelectedValue != "Select One")
                    {
                        li.CompanyName = ((DropDownList)row.FindControl("CompanyName")).SelectedValue;
                    }
                    else
                    {
                        display = "Select Company Name from dropdown";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (!String.IsNullOrEmpty(Convert.ToString((Request.Form[row.FindControl("EffectiveDate").UniqueID]))))
                    {
                        li.EffectiveDate = Convert.ToDateTime((Request.Form[row.FindControl("EffectiveDate").UniqueID]));
                    }
                    else
                    {
                        display = "Effective Date cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (!String.IsNullOrEmpty(Convert.ToString((Request.Form[row.FindControl("ExpirationDate").UniqueID]))))
                    {
                        li.ExpirationDate = Convert.ToDateTime((Request.Form[row.FindControl("ExpirationDate").UniqueID]));
                    }
                    else
                    {
                        display = "Expiration Date cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (li.ExpirationDate < li.EffectiveDate)
                    {
                        display = "Expiration Date must be after Effective date";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (isFormFilled)
                    {
                        DataSet result = li.UpdateSKPickingBoard(li, memberships);

                        string res = Convert.ToString(result.Tables[0].Rows[0].ItemArray[0]);

                        if (res.Equals("Duplicate SubCategoryCode"))
                        {
                            display = "Sub Category Code already exists in the database";
                            ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        }
                        else if (res.Equals("Duplicate SubCategoryName"))
                        {
                            display = "Sub Category Name already exists in the database";
                            ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        }
                        else if (res.Equals("Duplicate CommissionSubCategoryCode"))
                        {
                            display = "Sub Commission Category Code already exists in the database";
                            ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        }
                        else if (res.Equals("Success"))
                        {
                        }
                    }
                    //if (memberships > 0)
                    //{
                    //    li.UpdateSKPickingBoard(li, memberships);
                    //}
                    //else
                    //{
                    //    string display = "You must be a member of SK_Picking _Operations or SK_Picking_Warehouse groups to make changes.";
                    //    ClientScript.RegisterStartupScript(this.GetType(), "yourMessage", "alert('" + display + "');", true);
                    //}

                }
                catch (Exception ex)
                {
                    throw ex;
                }

                TerritoryGridView.EditIndex = -1;
                BindGridView();
            }
        }

        protected void Territory_SortData(object sender, GridViewSortEventArgs e)
        {
            if (TerritoryGridView.EditIndex >= -1)
            {
                TerritoryGridView.EditIndex = -1;
            }
            BindGridView();
            SortGrid(sender, e);
        }

        protected void Territory_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow && TerritoryGridView.EditIndex == e.Row.RowIndex)
            {
                TerritoryReportingChild li = new TerritoryReportingChild();


                //Find the DropDownList in the Row
                DropDownList ddlRegionNameList = (e.Row.FindControl("CategoryName") as DropDownList);
                ddlRegionNameList.DataSource = li.RegionNameList().Tables[0];
                ddlRegionNameList.DataTextField = "RegionName";
                ddlRegionNameList.DataValueField = "RegionName";
                ddlRegionNameList.DataBind();

                //Add Default Item in the DropDownList
                ddlRegionNameList.Items.Insert(0, new ListItem("Select One"));

                //Select the Country of Customer in DropDownList
                string regionNames = (e.Row.FindControl("lblRegionName") as Label).Text;
                ddlRegionNameList.Items.FindByValue(regionNames).Selected = true;


                //Find the DropDownList in the Row
                DropDownList ddlCompanyNameList = (e.Row.FindControl("CompanyName") as DropDownList);
                ddlCompanyNameList.DataSource = li.CompanyNameList().Tables[0];
                ddlCompanyNameList.DataTextField = "CompanyName";
                ddlCompanyNameList.DataValueField = "CompanyName";
                ddlCompanyNameList.DataBind();

                //Add Default Item in the DropDownList
                ddlCompanyNameList.Items.Insert(0, new ListItem("Select One"));

                //Select the Country of Customer in DropDownList
                string companyNames = (e.Row.FindControl("lblCompanyName") as Label).Text;
                ddlCompanyNameList.Items.FindByValue(companyNames).Selected = true;


                //Find the DropDownList in the Row
                DropDownList ddlTerritoryManagerNameList = (e.Row.FindControl("TerritoryManagerName") as DropDownList);
                ddlTerritoryManagerNameList.DataSource = li.TerritoryManagerNameList().Tables[0];
                ddlTerritoryManagerNameList.DataTextField = "TerritoryManagerName";
                ddlTerritoryManagerNameList.DataValueField = "TerritoryManagerName";
                ddlTerritoryManagerNameList.DataBind();

                //Add Default Item in the DropDownList
                ddlTerritoryManagerNameList.Items.Insert(0, new ListItem("Select One"));

                //Select the Country of Customer in DropDownList
                string territoryManagerNames = (e.Row.FindControl("lblTerritoryManagerName") as Label).Text;
                ddlTerritoryManagerNameList.Items.FindByValue(territoryManagerNames).Selected = true;


            }
        }

        protected void Territory_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            if (TerritoryGridView.EditIndex >= -1)
            {
                TerritoryGridView.EditIndex = -1;
            }
            BindGridView();
            PageGrid(sender, e);
        }

        protected void chkBoxResetCheckedChanged(object sender, EventArgs e)
        {
            if (TerritoryGridView.EditIndex >= -1)
            {
                TerritoryGridView.EditIndex = -1;
            }
            ddlTerritoryName.SelectedIndex = 0;
            ddlTerritoryManagerName.SelectedIndex = 0;
            ddlCompanyName.SelectedIndex = 0;
            ddlRegionName.SelectedIndex = 0;
            BindGridView();
        }

        #endregion
        protected void btnSaveNewTerritory_Click(object sender, EventArgs e)
        {
            bool isFormFilled = true;
            string display = "";
            TerritoryReportingChild li = new TerritoryReportingChild();
            string territoryCode = newTerritoryCode.Text;
            string territoryName = newTerritoryName.Text;
            string territoryManagerName = newTerritoryManagerName.SelectedValue.ToString();
            string regionName = newRegionName.SelectedValue.ToString();
            string companyName = newCompanyName.SelectedValue.ToString();
            string effectiveDate = Request.Form[newEffectiveDate.UniqueID];


            if (String.IsNullOrEmpty(effectiveDate) || String.IsNullOrEmpty(territoryCode)
                || String.IsNullOrEmpty(territoryName) || String.IsNullOrEmpty(territoryManagerName) || String.IsNullOrEmpty(regionName)
                || String.IsNullOrEmpty(companyName))
            {
                display = "Please select all the mandatory fields ";
                ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                isFormFilled = false;
            }


            if (isFormFilled)
            {
                DataSet result = li.AddNewTerritory(territoryCode, territoryName, territoryManagerName, regionName, companyName,  effectiveDate);

                string res = Convert.ToString(result.Tables[0].Rows[0].ItemArray[0]);

                if (res.Equals("Duplicate SubCategoryCode"))
                {
                    display = "Sub Category Code already exists in the database";
                    ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                    isFormFilled = false;
                }
                else if (res.Equals("Duplicate SubCategoryName"))
                {
                    display = "Sub Category Name already exists in the database";
                    ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                    isFormFilled = false;
                }
                else if (res.Equals("Duplicate CommissionSubCategoryCode"))
                {
                    display = "Commission Sub Category Code already exists in the database";
                    ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                    isFormFilled = false;
                }
                else if (res.Equals("Success"))
                {
                    display = "A new Category is successfully added in the database";
                    ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                    isFormFilled = true;
                }
                if (isFormFilled)
                {
                    newTerritoryCode.Text = "";
                    newTerritoryName.Text = "";
                    newTerritoryManagerName.SelectedIndex = 0;
                    newRegionName.SelectedIndex = 0;
                    newCompanyName.SelectedIndex = 0;
                    BindGridView();
                }
            }
        }

        protected void btnAddNewTerritory_Click(object sender, EventArgs e)
        {
            ModalPopupExtender1.Show();
        }

        protected void ddl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (TerritoryGridView.EditIndex >= -1)
            {
                TerritoryGridView.EditIndex = -1;
            }
            BindGridView();
        }

        private void BindGridView()
        {
            int count;
            TerritoryReportingChild obj = new TerritoryReportingChild();

            string territoryName = ddlTerritoryName.SelectedValue.ToString();
            string territoryManagerName = ddlTerritoryManagerName.SelectedValue.ToString();
            string regionName = ddlRegionName.SelectedValue.ToString();
            string companyName = ddlCompanyName.SelectedValue.ToString();
            DataSet ds = obj.GetSKPickingBoard2(territoryName, territoryManagerName, regionName, companyName);
            TerritoryGridView.DataSource = ds.Tables[0];
            TerritoryGridView.DataBind();
            count = ds.Tables[0].Rows.Count;
            if (count > 1)
            {
                lblRecordCount.Text = "Record Count: " + count;
            }
            else
            {
                lblRecordCount.Text = "Record Count: " + count;
            }

        }

        protected void btnExportToExcel_Click(object sender, EventArgs e)
        {
            TerritoryReportingChild obj = new TerritoryReportingChild();
            DataSet ds = obj.GetSKPickingBoard2("Select One", "Select One", "Select One", "Select One");

            WorkbookEngine we = new WorkbookEngine();
            we.ExportDataSetToExcel(ds.Tables[0], "Territory Sales Reporting");
        }
    }
}