﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SalesReportingWebsite
{
    public partial class SubSegment : PageBase
    {
        public int memberships;
        protected void Page_Load(object sender, EventArgs e)
        {

            VBFunctions.ADFunctions obj = new VBFunctions.ADFunctions();
            string userID = obj.GetUserName();
            // string dirEntry = obj.GetDirectoryEntry();
            memberships = obj.VerifyGroupMemberships("LDAP://192.168.100.3/ou=Cooper Network Users,dc=coopersurgical1,dc=com", "webapps", "Yankees#1", userID);

            if (!Page.IsPostBack)

            {
                if (memberships == 1 || memberships == 2)
                {
                    SubSegmentReportingChild li = new SubSegmentReportingChild();

                    DataTable table = new DataTable();

                    ddlSegmentName.DataSource = li.SegmentNameList().Tables[0];
                    ddlSegmentName.DataTextField = "SegmentName";
                    ddlSegmentName.DataBind();

                    ddlSubSegmentName.DataSource = li.SubSegmentNameList().Tables[0];
                    ddlSubSegmentName.DataTextField = "SubSegmentName";
                    ddlSubSegmentName.DataBind();

                    newSegmentName.DataSource = li.SegmentNameList().Tables[0];
                    newSegmentName.DataTextField = "SegmentName";
                    newSegmentName.DataBind();



                    BindGridView();
                }
            }
        }
        
        #region EventHandling
              
        protected void SubSegment_RowEditing(object sender, GridViewEditEventArgs e)
        {
            SubSegmentGridView.EditIndex = e.NewEditIndex;
            int index = e.NewEditIndex;
            GridViewRow row = SubSegmentGridView.Rows[e.NewEditIndex];

            BindGridView();
        }
        
        protected void SubSegment_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            SubSegmentGridView.EditIndex = -1;
            BindGridView();
        }


        protected void SubSegment_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            if (Page.IsValid)
            {
                SubSegmentReportingChild li = new SubSegmentReportingChild();
                GridViewRow row = SubSegmentGridView.Rows[e.RowIndex];
                string display = "";
                bool isFormFilled = true;
                try
                {
                    li.SubSegmentID = Convert.ToInt32(SubSegmentGridView.DataKeys[e.RowIndex].Values[0]);

                    if (((TextBox)row.FindControl("SubSegmentCode")).Text != string.Empty)
                    {
                        li.SubSegmentCode = Convert.ToString(((TextBox)row.FindControl("SubSegmentCode")).Text);
                    }
                    else
                    {
                        display = "Sub Segment Code cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (((TextBox)row.FindControl("SubSegmentName")).Text != string.Empty)
                    {
                        li.SubSegmentName = Convert.ToString(((TextBox)row.FindControl("SubSegmentName")).Text);
                    }
                    else
                    {
                        display = "Sub Segment Name cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (((DropDownList)row.FindControl("SegmentName")).SelectedValue != "Select One")
                    {
                        li.SegmentName = ((DropDownList)row.FindControl("SegmentName")).SelectedValue;
                    }
                    else
                    {
                        display = "Select Segment Name from dropdown";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }
                    if (!String.IsNullOrEmpty(Convert.ToString((Request.Form[row.FindControl("EffectiveDate").UniqueID]))))
                    {
                        li.EffectiveDate = Convert.ToDateTime((Request.Form[row.FindControl("EffectiveDate").UniqueID]));
                    }
                    else
                    {
                        display = "Effective Date cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }
                    if (!String.IsNullOrEmpty(Convert.ToString((Request.Form[row.FindControl("ExpirationDate").UniqueID]))))
                    {
                        li.ExpirationDate = Convert.ToDateTime((Request.Form[row.FindControl("ExpirationDate").UniqueID]));
                    }
                    else
                    {
                        display = "Expiration Date cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (li.ExpirationDate < li.EffectiveDate)
                    {
                        display = "Expiration Date must be after Effective date";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (isFormFilled)
                    {
                        if (memberships == 1 || memberships == 2)
                        {
                            DataSet result = li.UpdateSKPickingBoard(li, memberships);

                            string res = Convert.ToString(result.Tables[0].Rows[0].ItemArray[0]);

                            if (res.Equals("Duplicate SubSegmentName"))
                            {
                                display = "Sub Segment Name already exists in the database";
                                ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                            }
                            else if (res.Equals("Duplicate SubSegmentCode"))
                            {
                                display = "Sub Segment Code already exists in the database";
                                ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                            }
                            else if (res.Equals("Success"))
                            {
                            }
                        }
                        else
                        {
                            display = "You must be a member of Consolidated Sales Reporting – Admin or Consolidated Sales Reporting – Finance   groups to make changes.";
                            ClientScript.RegisterStartupScript(this.GetType(), "yourMessage", "alert('" + display + "');", true);
                        }
                    }
                   

                }
                catch (Exception ex)
                {
                    throw ex;
                }

                SubSegmentGridView.EditIndex = -1;
                BindGridView();
            }
        }

        protected void SubSegment_SortData(object sender, GridViewSortEventArgs e)
        {
            if (SubSegmentGridView.EditIndex >= -1)
            {
                SubSegmentGridView.EditIndex = -1;
            }
            BindGridView();
            SortGrid(sender, e);
        }

        protected void SubSegment_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow && SubSegmentGridView.EditIndex == e.Row.RowIndex)
            {
                SubSegmentReportingChild li = new SubSegmentReportingChild();

                //Find the DropDownList in the Row
                DropDownList ddlSegmentNameList = (e.Row.FindControl("SegmentName") as DropDownList);
                ddlSegmentNameList.DataSource = li.SegmentNameList().Tables[0];
                ddlSegmentNameList.DataTextField = "SegmentName";
                ddlSegmentNameList.DataValueField = "SegmentName";
                ddlSegmentNameList.DataBind();

                //Add Default Item in the DropDownList
                ddlSegmentNameList.Items.Insert(0, new ListItem("Select One"));

                //Select the Country of Customer in DropDownList
                string subSegmentNames = (e.Row.FindControl("lblSegmentName") as Label).Text;
                ddlSegmentNameList.Items.FindByValue(subSegmentNames).Selected = true;


            }
        }

        protected void SubSegment_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            if (SubSegmentGridView.EditIndex >= -1)
            {
                SubSegmentGridView.EditIndex = -1;
            }
            BindGridView();
            PageGrid(sender, e);
        }
        
        protected void chkBoxResetCheckedChanged(object sender, EventArgs e)
        {
            if (SubSegmentGridView.EditIndex >= -1)
            {
                SubSegmentGridView.EditIndex = -1;
            }
            ddlSegmentName.SelectedIndex = 0;
            ddlSubSegmentName.SelectedIndex = 0;
            BindGridView();
        }

        #endregion
  protected void btnSaveNewSubSegment_Click(object sender, EventArgs e)
        {
            bool isFormFilled = true;
            string display = "";
            SubSegmentReportingChild li = new SubSegmentReportingChild();
            string segmentName = newSegmentName.Text;
            string subSegmentName = newSubSegmentName.Text;
            string subSegmentCode = newSubSegmentCode.Text;
            string effectiveDate = Request.Form[newEffectiveDate.UniqueID];
            
          
            if (String.IsNullOrEmpty(effectiveDate) || String.IsNullOrEmpty(subSegmentCode) 
                || String.IsNullOrEmpty(subSegmentName) || String.IsNullOrEmpty(segmentName))
            {
                display = "Please select all the mandatory fields ";
                ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                isFormFilled = false;
            }
            

            if (isFormFilled)
            {
                if (memberships == 1 || memberships == 2)
                {
                    DataSet result = li.AddNewSubSegment(subSegmentCode, subSegmentName, segmentName, effectiveDate);

                    string res = Convert.ToString(result.Tables[0].Rows[0].ItemArray[0]);

                    if (res.Equals("Duplicate SubSegmentName"))
                    {
                        display = "SubSegment Name already exists in the database";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }
                    else if (res.Equals("Duplicate SubSegmentCode"))
                    {
                        display = "SubSegment Code already exists in the database";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }
                    else if (res.Equals("Success"))
                    {
                        display = "A new SubSegment is successfully added in the database";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = true;
                    }
                }
                else
                {
                    display = "You must be a member of Consolidated Sales Reporting – Admin or Consolidated Sales Reporting – Finance   groups to make changes.";
                    ClientScript.RegisterStartupScript(this.GetType(), "yourMessage", "alert('" + display + "');", true);
                }
                if (isFormFilled)
                    {
                        newSubSegmentCode.Text = "";
                        newSubSegmentName.Text = "";
                        ddlSegmentName.DataSource = li.SegmentNameList().Tables[0];
                        ddlSegmentName.DataTextField = "SegmentName";
                        ddlSegmentName.DataBind();
                        ddlSubSegmentName.DataSource = li.SubSegmentNameList().Tables[0];
                        ddlSubSegmentName.DataTextField = "SubSegmentName";
                        ddlSubSegmentName.DataBind();
                        BindGridView();
                    }
               
            }
        }

        protected void btnAddNewSubSegments_Click(object sender, EventArgs e)
        {
            ModalPopupExtender1.Show();
        }

        protected void ddl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (SubSegmentGridView.EditIndex >= -1)
            {
                SubSegmentGridView.EditIndex = -1;
            }
            BindGridView();
        }

        private void BindGridView()
        {
            int count;
            SubSegmentReportingChild obj = new SubSegmentReportingChild();
           
            string segmentName = ddlSegmentName.SelectedValue.ToString();
            string subSegmentName = ddlSubSegmentName.SelectedValue.ToString();
            DataSet ds = obj.GetSKPickingBoard2(segmentName,subSegmentName);
            SubSegmentGridView.DataSource = ds.Tables[0];
            SubSegmentGridView.DataBind();
            count = ds.Tables[0].Rows.Count;
            if (count > 1)
            {
                lblRecordCount.Text = "Record Count: " + count;
            }
            else
            {
                lblRecordCount.Text = "Record Count: " + count;
            }
            
        }
                
        protected void btnExportToExcel_Click(object sender, EventArgs e)
        {
            ModalPopupExtender2.Show();
           
        }

        protected void btnexcelDownloadAll_Click(object sender, EventArgs e)
        {
            ModalPopupExtender2.Hide();
            SubSegmentReportingChild obj = new SubSegmentReportingChild();
            DataSet ds = obj.GetSKPickingBoard2("Select One", "Select One");
            WorkbookEngine we = new WorkbookEngine();
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                if (dr.IsNull("ExpirationDate"))
                {
                    dr.Delete();
                }
                //DateTime expirationDate = Convert.ToDateTime(dr["ExpirationDate"].ToString());
            }
            we.ExportDataSetToExcel(ds.Tables[0], "Segment Reporting");
        }

        protected void btnexcelDownload_Click(object sender, EventArgs e)
        {
            ModalPopupExtender2.Hide();
            SubSegmentReportingChild obj = new SubSegmentReportingChild();
            DataSet ds = obj.GetSKPickingBoard2("Select One", "Select One");
            WorkbookEngine we = new WorkbookEngine();
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                if (!dr.IsNull("ExpirationDate"))
                {
                    dr.Delete();
                }
                //DateTime expirationDate = Convert.ToDateTime(dr["ExpirationDate"].ToString());
            }
            we.ExportDataSetToExcel(ds.Tables[0], "Segment Reporting");
        }
    }
}