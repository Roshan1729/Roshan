﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SalesReportingWebsite
{
    public partial class SubCategory : PageBase
    {
        public int memberships;
        protected void Page_Load(object sender, EventArgs e)
        {

            //VBFunctions.ADFunctions obj = new VBFunctions.ADFunctions();
            //string userID = obj.GetUserName();
            //// string dirEntry = obj.GetDirectoryEntry();
            //memberships = obj.VerifyGroupMemberships("LDAP://192.168.100.3/ou=Cooper Network Users,dc=coopersurgical1,dc=com", "coopservice", "^CSIServ2016!", userID);

            if (!Page.IsPostBack)

            {
                SubCategoryReportingChild li = new SubCategoryReportingChild();

                DataTable table = new DataTable();



                ddlCategoryName.DataSource = li.CategoryNameList().Tables[0];
                ddlCategoryName.DataTextField = "CategoryName";
                ddlCategoryName.DataBind();

                ddlCommissionCategoryName.DataSource = li.CommissionCategoryNameList().Tables[0];
                ddlCommissionCategoryName.DataTextField = "CommissionCategoryName";
                ddlCommissionCategoryName.DataBind();


                ddlSubCategoryName.DataSource = li.SubCategoryNameList().Tables[0];
                ddlSubCategoryName.DataTextField = "SubCategoryName";
                ddlSubCategoryName.DataBind();

                ddlCommissionSubCategoryName.DataSource = li.CommissionSubCategoryNameList().Tables[0];
                ddlCommissionSubCategoryName.DataTextField = "CommissionSubCategoryName";
                ddlCommissionSubCategoryName.DataBind();


                newCategoryName.DataSource = li.CategoryNameList().Tables[0];
                newCategoryName.DataTextField = "CategoryName";
                newCategoryName.DataBind();

                newCommissionSubCategoryName.DataSource = li.CommissionSubCategoryNameList().Tables[0];
                newCommissionSubCategoryName.DataTextField = "CommissionSubCategoryName";
                newCommissionSubCategoryName.DataBind();

                newCommissionCategoryName.DataSource = li.CommissionCategoryNameList().Tables[0];
                newCommissionCategoryName.DataTextField = "CommissionCategoryName";
                newCommissionCategoryName.DataBind();

                BindGridView();
            }
        }

        #region EventHandling

        protected void SubCategory_RowEditing(object sender, GridViewEditEventArgs e)
        {
            SubCategoryGridView.EditIndex = e.NewEditIndex;
            int index = e.NewEditIndex;
            GridViewRow row = SubCategoryGridView.Rows[e.NewEditIndex];

            BindGridView();
        }

        protected void SubCategory_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            SubCategoryGridView.EditIndex = -1;
            BindGridView();
        }


        protected void SubCategory_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            if (Page.IsValid)
            {
                SubCategoryReportingChild li = new SubCategoryReportingChild();
                GridViewRow row = SubCategoryGridView.Rows[e.RowIndex];
                string display = "";
                bool isFormFilled = true;
                try
                {
                    li.SubCategoryID = Convert.ToInt32(SubCategoryGridView.DataKeys[e.RowIndex].Values[0]);

                    if (((TextBox)row.FindControl("SubCategorySequence")).Text != string.Empty)
                    {
                        li.SubCategorySequence = Convert.ToInt32(((TextBox)row.FindControl("SubCategorySequence")).Text);
                    }
                    else
                    {
                        display = "Sub Category Sequence Code cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (((TextBox)row.FindControl("SubCategoryCode")).Text != string.Empty)
                    {
                        li.SubCategoryCode = Convert.ToInt32(((TextBox)row.FindControl("SubCategoryCode")).Text);
                    }
                    else
                    {
                        display = "Sub Category Code cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (((TextBox)row.FindControl("SubCategoryName")).Text != string.Empty)
                    {
                        li.SubCategoryName = Convert.ToString(((TextBox)row.FindControl("SubCategoryName")).Text);
                    }
                    else
                    {
                        display = "Sub Category Name cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (((DropDownList)row.FindControl("CategoryName")).SelectedValue != "Select One")
                    {
                        li.CommissionCategoryName = ((DropDownList)row.FindControl("CategoryName")).SelectedValue;
                    }
                    else
                    {
                        display = "Select Category Name from dropdown";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }


                    if (((TextBox)row.FindControl("CommissionSubCategoryCode")).Text != string.Empty)
                    {
                        li.CommissionSubCategoryCode = Convert.ToInt32(((TextBox)row.FindControl("CommissionSubCategoryCode")).Text);
                    }
                    else
                    {
                        display = "Commission Sub Category Code cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (((DropDownList)row.FindControl("CommissionSubCategoryName")).SelectedValue != "Select One")
                    {
                        li.CommissionSubCategoryName = ((DropDownList)row.FindControl("CommissionSubCategoryName")).SelectedValue;
                    }
                    else
                    {
                        display = "Select Commission Sub Category Name from dropdown";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }


                    if (((DropDownList)row.FindControl("CommissionCategoryName")).SelectedValue != "Select One")
                    {
                        li.CommissionCategoryName = ((DropDownList)row.FindControl("CommissionCategoryName")).SelectedValue;
                    }
                    else
                    {
                        display = "Select Commission Category Name from dropdown";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (!String.IsNullOrEmpty(Convert.ToString((Request.Form[row.FindControl("EffectiveDate").UniqueID]))))
                    {
                        li.EffectiveDate = Convert.ToDateTime((Request.Form[row.FindControl("EffectiveDate").UniqueID]));
                    }
                    else
                    {
                        display = "Effective Date cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (!String.IsNullOrEmpty(Convert.ToString((Request.Form[row.FindControl("ExpirationDate").UniqueID]))))
                    {
                        li.ExpirationDate = Convert.ToDateTime((Request.Form[row.FindControl("ExpirationDate").UniqueID]));
                    }
                    else
                    {
                        display = "Expiration Date cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (li.ExpirationDate < li.EffectiveDate)
                    {
                        display = "Expiration Date must be after Effective date";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (isFormFilled)
                    {
                        DataSet result = li.UpdateSKPickingBoard(li, memberships);

                        string res = Convert.ToString(result.Tables[0].Rows[0].ItemArray[0]);

                        if (res.Equals("Duplicate SubCategoryCode"))
                        {
                            display = "Sub Category Code already exists in the database";
                            ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        }
                        else if (res.Equals("Duplicate SubCategoryName"))
                        {
                            display = "Sub Category Name already exists in the database";
                            ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        }
                        else if (res.Equals("Duplicate CommissionSubCategoryCode"))
                        {
                            display = "Sub Commission Category Code already exists in the database";
                            ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        }
                        else if (res.Equals("Success"))
                        {
                        }
                    }
                    //if (memberships > 0)
                    //{
                    //    li.UpdateSKPickingBoard(li, memberships);
                    //}
                    //else
                    //{
                    //    string display = "You must be a member of SK_Picking _Operations or SK_Picking_Warehouse groups to make changes.";
                    //    ClientScript.RegisterStartupScript(this.GetType(), "yourMessage", "alert('" + display + "');", true);
                    //}

                }
                catch (Exception ex)
                {
                    throw ex;
                }

                SubCategoryGridView.EditIndex = -1;
                BindGridView();
            }
        }

        protected void SubCategory_SortData(object sender, GridViewSortEventArgs e)
        {
            if (SubCategoryGridView.EditIndex >= -1)
            {
                SubCategoryGridView.EditIndex = -1;
            }
            BindGridView();
            SortGrid(sender, e);
        }

        protected void SubCategory_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow && SubCategoryGridView.EditIndex == e.Row.RowIndex)
            {
                SubCategoryReportingChild li = new SubCategoryReportingChild();


                //Find the DropDownList in the Row
                DropDownList ddlCategoryNameList = (e.Row.FindControl("CategoryName") as DropDownList);
                ddlCategoryNameList.DataSource = li.CategoryNameList().Tables[0];
                ddlCategoryNameList.DataTextField = "CategoryName";
                ddlCategoryNameList.DataValueField = "CategoryName";
                ddlCategoryNameList.DataBind();

                //Add Default Item in the DropDownList
                ddlCategoryNameList.Items.Insert(0, new ListItem("Select One"));

                //Select the Country of Customer in DropDownList
                string categoryNames = (e.Row.FindControl("lblCategoryName") as Label).Text;
                ddlCategoryNameList.Items.FindByValue(categoryNames).Selected = true;


                //Find the DropDownList in the Row
                DropDownList ddlCommissionSubCategoryNameList = (e.Row.FindControl("CommissionSubCategoryName") as DropDownList);
                ddlCommissionSubCategoryNameList.DataSource = li.CommissionSubCategoryNameList().Tables[0];
                ddlCommissionSubCategoryNameList.DataTextField = "CommissionSubCategoryName";
                ddlCommissionSubCategoryNameList.DataValueField = "CommissionSubCategoryName";
                ddlCommissionSubCategoryNameList.DataBind();

                //Add Default Item in the DropDownList
                ddlCommissionSubCategoryNameList.Items.Insert(0, new ListItem("Select One"));

                //Select the Country of Customer in DropDownList
                string commissionSubCategoryNames = (e.Row.FindControl("lblCommissionSubCategoryName") as Label).Text;
                ddlCommissionSubCategoryNameList.Items.FindByValue(commissionSubCategoryNames).Selected = true;


                //Find the DropDownList in the Row
                DropDownList ddlCommissionCategoryNameList = (e.Row.FindControl("CommissionCategoryName") as DropDownList);
                ddlCommissionCategoryNameList.DataSource = li.CommissionCategoryNameList().Tables[0];
                ddlCommissionCategoryNameList.DataTextField = "CommissionCategoryName";
                ddlCommissionCategoryNameList.DataValueField = "CommissionCategoryName";
                ddlCommissionCategoryNameList.DataBind();

                //Add Default Item in the DropDownList
                ddlCommissionCategoryNameList.Items.Insert(0, new ListItem("Select One"));

                //Select the Country of Customer in DropDownList
                string commissionCategoryNames = (e.Row.FindControl("lblCommissionCategoryName") as Label).Text;
                ddlCommissionCategoryNameList.Items.FindByValue(commissionCategoryNames).Selected = true;


            }
        }

        protected void SubCategory_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            if (SubCategoryGridView.EditIndex >= -1)
            {
                SubCategoryGridView.EditIndex = -1;
            }
            BindGridView();
            PageGrid(sender, e);
        }

        protected void chkBoxResetCheckedChanged(object sender, EventArgs e)
        {
            if (SubCategoryGridView.EditIndex >= -1)
            {
                SubCategoryGridView.EditIndex = -1;
            }
            ddlCategoryName.SelectedIndex = 0;
            ddlCommissionCategoryName.SelectedIndex = 0;
            BindGridView();
        }

        #endregion
        protected void btnSaveNewSubCategory_Click(object sender, EventArgs e)
        {
            bool isFormFilled = true;
            string display = "";
            SubCategoryReportingChild li = new SubCategoryReportingChild();
            string subCategorySequence = newSubCategorySequence.Text;
            string subCategoryCode = newSubCategoryCode.Text;
            string subCategoryName = newSubCategoryName.Text;
            string categoryName = newCategoryName.Text;
            string commissionSubCategoryCode = newCommissionSubCategoryCode.Text;
            string commissionSubCategoryName = newCommissionSubCategoryName.SelectedValue.ToString();
            string commissionCategoryName = newCommissionCategoryName.SelectedValue.ToString();
            string effectiveDate = Request.Form[newEffectiveDate.UniqueID];


            if (String.IsNullOrEmpty(effectiveDate) || String.IsNullOrEmpty(subCategorySequence)
                || String.IsNullOrEmpty(subCategoryCode) || String.IsNullOrEmpty(categoryName) || String.IsNullOrEmpty(subCategoryName)
                || String.IsNullOrEmpty(commissionSubCategoryCode) || String.IsNullOrEmpty(commissionCategoryName) || String.IsNullOrEmpty(commissionSubCategoryName))
            {
                display = "Please select all the mandatory fields ";
                ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                isFormFilled = false;
            }


            if (isFormFilled)
            {
                DataSet result = li.AddNewSubCategory(subCategorySequence, subCategoryCode, subCategoryName, categoryName, commissionSubCategoryCode, commissionSubCategoryName, commissionCategoryName, effectiveDate);

                string res = Convert.ToString(result.Tables[0].Rows[0].ItemArray[0]);

                if (res.Equals("Duplicate SubCategoryCode"))
                {
                    display = "Sub Category Code already exists in the database";
                    ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                    isFormFilled = false;
                }
                else if (res.Equals("Duplicate SubCategoryName"))
                {
                    display = "Sub Category Name already exists in the database";
                    ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                    isFormFilled = false;
                }
                else if (res.Equals("Duplicate CommissionSubCategoryCode"))
                {
                    display = "Commission Sub Category Code already exists in the database";
                    ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                    isFormFilled = false;
                }
                else if (res.Equals("Success"))
                {
                    display = "A new Category is successfully added in the database";
                    ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                    isFormFilled = true;
                }
                if (isFormFilled)
                {
                    newSubCategorySequence.Text = "";
                    newSubCategoryCode.Text = "";
                    newSubCategoryName.Text = "";
                    newCategoryName.SelectedIndex = 0;
                    newCommissionSubCategoryCode.Text = "";
                    newCommissionSubCategoryName.SelectedIndex = 0;
                    newCommissionCategoryName.SelectedIndex = 0;
                    BindGridView();
                }
            }
        }

        protected void btnAddNewSubCategory_Click(object sender, EventArgs e)
        {
            ModalPopupExtender1.Show();
        }

        protected void ddl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (SubCategoryGridView.EditIndex >= -1)
            {
                SubCategoryGridView.EditIndex = -1;
            }
            BindGridView();
        }

        private void BindGridView()
        {
            int count;
            SubCategoryReportingChild obj = new SubCategoryReportingChild();

            string categoryName = ddlCategoryName.SelectedValue.ToString();
            string subCategoryName = ddlSubCategoryName.SelectedValue.ToString();
            string commissionCategoryName = ddlCommissionCategoryName.SelectedValue.ToString();
            string commissionSubCategoryName = ddlCommissionSubCategoryName.SelectedValue.ToString();
            DataSet ds = obj.GetSKPickingBoard2(categoryName, subCategoryName, commissionCategoryName,commissionSubCategoryName);
            SubCategoryGridView.DataSource = ds.Tables[0];
            SubCategoryGridView.DataBind();
            count = ds.Tables[0].Rows.Count;
            if (count > 1)
            {
                lblRecordCount.Text = "Record Count: " + count;
            }
            else
            {
                lblRecordCount.Text = "Record Count: " + count;
            }

        }

        protected void btnExportToExcel_Click(object sender, EventArgs e)
        {
            SubCategoryReportingChild obj = new SubCategoryReportingChild();
            DataSet ds = obj.GetSKPickingBoard2("Select One", "Select One", "Select One", "Select One");

            WorkbookEngine we = new WorkbookEngine();
            we.ExportDataSetToExcel(ds.Tables[0], "Sales Reporting");
        }
    }
}