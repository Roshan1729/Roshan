﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SalesReportingWebsite
{
    public partial class Company : PageBase
    {
        public int memberships;
        protected void Page_Load(object sender, EventArgs e)
        {

            //VBFunctions.ADFunctions obj = new VBFunctions.ADFunctions();
            //string userID = obj.GetUserName();
            //// string dirEntry = obj.GetDirectoryEntry();
            //memberships = obj.VerifyGroupMemberships("LDAP://192.168.100.3/ou=Cooper Network Users,dc=coopersurgical1,dc=com", "coopservice", "^CSIServ2016!", userID);

            if (!Page.IsPostBack)

            {
                CompanyReportingChild li = new CompanyReportingChild();

                DataTable table = new DataTable();



                ddlCompanyName.DataSource = li.CompanyNameList().Tables[0];
                ddlCompanyName.DataTextField = "CompanyName";
                ddlCompanyName.DataBind();

                ddlCompanyLocalCurrency.DataSource = li.CompanyLocalCurrencyNameList().Tables[0];
                ddlCompanyLocalCurrency.DataTextField = "CompanyLocalCurrency";
                ddlCompanyLocalCurrency.DataBind();


                ddlSubSegmentName.DataSource = li.SubSegmentNameList().Tables[0];
                ddlSubSegmentName.DataTextField = "SubSegmentName";
                ddlSubSegmentName.DataBind();


                newCompanyLocalCurrency.DataSource = li.CompanyLocalCurrencyNameList().Tables[0];
                newCompanyLocalCurrency.DataTextField = "CompanyLocalCurrency";
                newCompanyLocalCurrency.DataBind();

                newSubSegmentName.DataSource = li.SubSegmentNameList().Tables[0];
                newSubSegmentName.DataTextField = "SubSegmentName";
                newSubSegmentName.DataBind();

               
                BindGridView();
            }
        }

        #region EventHandling

        protected void Company_RowEditing(object sender, GridViewEditEventArgs e)
        {
            CompanyGridView.EditIndex = e.NewEditIndex;
            int index = e.NewEditIndex;
            GridViewRow row = CompanyGridView.Rows[e.NewEditIndex];

            BindGridView();
        }

        protected void Company_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            CompanyGridView.EditIndex = -1;
            BindGridView();
        }


        protected void Company_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            if (Page.IsValid)
            {
                CompanyReportingChild li = new CompanyReportingChild();
                GridViewRow row = CompanyGridView.Rows[e.RowIndex];
                string display = "";
                bool isFormFilled = true;
                try
                {
                    li.CompanyID = Convert.ToInt32(CompanyGridView.DataKeys[e.RowIndex].Values[0]);

                   
                    if (((TextBox)row.FindControl("CompanyKey")).Text != string.Empty)
                    {
                        li.CompanyKey = Convert.ToString(((TextBox)row.FindControl("CompanyKey")).Text);
                    }
                    else
                    {
                        display = "Company Key cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (((TextBox)row.FindControl("CompanyName")).Text != string.Empty)
                    {
                        li.CompanyName = Convert.ToString(((TextBox)row.FindControl("CompanyName")).Text);
                    }
                    else
                    {
                        display = "Company Name cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (((DropDownList)row.FindControl("CompanyLocalCurrency")).SelectedValue != "Select One")
                    {
                        li.CompanyLocalCurrency = ((DropDownList)row.FindControl("CompanyLocalCurrency")).SelectedValue;
                    }
                    else
                    {
                        display = "CompanyLocalCurrency from dropdown";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (((DropDownList)row.FindControl("SubSegmentName")).SelectedValue != "Select One")
                    {
                        li.SubSegmentName = ((DropDownList)row.FindControl("SubSegmentName")).SelectedValue;
                    }
                    else
                    {
                        display = "Select SubSegmentName from dropdown";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (!String.IsNullOrEmpty(Convert.ToString((Request.Form[row.FindControl("EffectiveDate").UniqueID]))))
                    {
                        li.EffectiveDate = Convert.ToDateTime((Request.Form[row.FindControl("EffectiveDate").UniqueID]));
                    }
                    else
                    {
                        display = "Effective Date cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (!String.IsNullOrEmpty(Convert.ToString((Request.Form[row.FindControl("ExpirationDate").UniqueID]))))
                    {
                        li.ExpirationDate = Convert.ToDateTime((Request.Form[row.FindControl("ExpirationDate").UniqueID]));
                    }
                    else
                    {
                        display = "Expiration Date cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (li.ExpirationDate < li.EffectiveDate)
                    {
                        display = "Expiration Date must be after Effective date";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (isFormFilled)
                    {
                        DataSet result = li.UpdateSKPickingBoard(li, memberships);

                        string res = Convert.ToString(result.Tables[0].Rows[0].ItemArray[0]);

                        if (res.Equals("Duplicate CompanyKey"))
                        {
                            display = "Company Key  already exists in the database";
                            ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        }
                        else if (res.Equals("Duplicate CompanyName"))
                        {
                            display = "Company Name already exists in the database";
                            ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        }
                       
                        else if (res.Equals("Success"))
                        {
                        }
                    }
                    //if (memberships > 0)
                    //{
                    //    li.UpdateSKPickingBoard(li, memberships);
                    //}
                    //else
                    //{
                    //    string display = "You must be a member of SK_Picking _Operations or SK_Picking_Warehouse groups to make changes.";
                    //    ClientScript.RegisterStartupScript(this.GetType(), "yourMessage", "alert('" + display + "');", true);
                    //}

                }
                catch (Exception ex)
                {
                    throw ex;
                }

                CompanyGridView.EditIndex = -1;
                BindGridView();
            }
        }

        protected void Company_SortData(object sender, GridViewSortEventArgs e)
        {
            if (CompanyGridView.EditIndex >= -1)
            {
                CompanyGridView.EditIndex = -1;
            }
            BindGridView();
            SortGrid(sender, e);
        }

        protected void Company_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow && CompanyGridView.EditIndex == e.Row.RowIndex)
            {
                CompanyReportingChild li = new CompanyReportingChild();


              
                //Find the DropDownList in the Row
                DropDownList ddlCompanyLocalCurrencyList = (e.Row.FindControl("CompanyLocalCurrency") as DropDownList);
                ddlCompanyLocalCurrencyList.DataSource = li.CompanyLocalCurrencyNameList().Tables[0];
                ddlCompanyLocalCurrencyList.DataTextField = "CompanyLocalCurrency";
                ddlCompanyLocalCurrencyList.DataValueField = "CompanyLocalCurrency";
                ddlCompanyLocalCurrencyList.DataBind();

                //Add Default Item in the DropDownList
                ddlCompanyLocalCurrencyList.Items.Insert(0, new ListItem("Select One"));

                //Select the Country of Customer in DropDownList
                string companyLocalCurrencys = (e.Row.FindControl("lblCompanyLocalCurrency") as Label).Text;
                ddlCompanyLocalCurrencyList.Items.FindByValue(companyLocalCurrencys).Selected = true;


                //Find the DropDownList in the Row
                DropDownList ddlSubSegmentNameList = (e.Row.FindControl("SubSegmentName") as DropDownList);
                ddlSubSegmentNameList.DataSource = li.SubSegmentNameList().Tables[0];
                ddlSubSegmentNameList.DataTextField = "SubSegmentName";
                ddlSubSegmentNameList.DataValueField = "SubSegmentName";
                ddlSubSegmentNameList.DataBind();

                //Add Default Item in the DropDownList
                ddlSubSegmentNameList.Items.Insert(0, new ListItem("Select One"));

                //Select the Country of Customer in DropDownList
                string subSegmentNames = (e.Row.FindControl("lblSubSegmentName") as Label).Text;
                ddlSubSegmentNameList.Items.FindByValue(subSegmentNames).Selected = true;


            }
        }

        protected void Company_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            if (CompanyGridView.EditIndex >= -1)
            {
                CompanyGridView.EditIndex = -1;
            }
            BindGridView();
            PageGrid(sender, e);
        }

        protected void chkBoxResetCheckedChanged(object sender, EventArgs e)
        {
            if (CompanyGridView.EditIndex >= -1)
            {
                CompanyGridView.EditIndex = -1;
            }
            ddlCompanyName.SelectedIndex = 0;
            ddlCompanyLocalCurrency.SelectedIndex = 0;
            ddlSubSegmentName.SelectedIndex = 0;
            BindGridView();
        }

        #endregion
        protected void btnSaveNewCompany_Click(object sender, EventArgs e)
        {
            bool isFormFilled = true;
            string display = "";
            CompanyReportingChild li = new CompanyReportingChild();
            string companyKey = newCompanyKey.Text;
            string companyName = newCompanyName.Text;
            string companyLocalCurrency = newCompanyLocalCurrency.Text;
            string subSegmentName = newSubSegmentName.SelectedValue.ToString();
            string effectiveDate = Request.Form[newEffectiveDate.UniqueID];


            if (String.IsNullOrEmpty(effectiveDate) || String.IsNullOrEmpty(companyKey)
                || String.IsNullOrEmpty(companyName) || String.IsNullOrEmpty(companyLocalCurrency) || String.IsNullOrEmpty(subSegmentName))
            {
                display = "Please select all the mandatory fields ";
                ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                isFormFilled = false;
            }


            if (isFormFilled)
            {
                DataSet result = li.AddNewCompany(companyKey, companyName, companyLocalCurrency, subSegmentName, effectiveDate);

                string res = Convert.ToString(result.Tables[0].Rows[0].ItemArray[0]);

                if (res.Equals("Duplicate CompanyKey"))
                {
                    display = "Company Key already exists in the database";
                    ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                    isFormFilled = false;
                }
                else if (res.Equals("Duplicate CompanyName"))
                {
                    display = "Company Name already exists in the database";
                    ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                    isFormFilled = false;
                }
               
                else if (res.Equals("Success"))
                {
                    display = "A new Company is successfully added in the database";
                    ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                    isFormFilled = true;
                }
                if (isFormFilled)
                {
                    newCompanyKey.Text = "";
                    newCompanyName.Text = "";
                    newCompanyLocalCurrency.SelectedIndex = 0;
                    newSubSegmentName.SelectedIndex = 0;
                    BindGridView();
                }
            }
        }

        protected void btnAddNewCompany_Click(object sender, EventArgs e)
        {
            ModalPopupExtender1.Show();
        }

        protected void ddl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (CompanyGridView.EditIndex >= -1)
            {
                CompanyGridView.EditIndex = -1;
            }
            BindGridView();
        }

        private void BindGridView()
        {
            int count;
            CompanyReportingChild obj = new CompanyReportingChild();

            string companyName = ddlCompanyName.SelectedValue.ToString();
            string subSegmentname = ddlSubSegmentName.SelectedValue.ToString();
            string companyLocalCurrency = ddlCompanyLocalCurrency.SelectedValue.ToString();
            DataSet ds = obj.GetSKPickingBoard2(companyName, subSegmentname, companyLocalCurrency);
            CompanyGridView.DataSource = ds.Tables[0];
            CompanyGridView.DataBind();
            count = ds.Tables[0].Rows.Count;
            if (count > 1)
            {
                lblRecordCount.Text = "Record Count: " + count;
            }
            else
            {
                lblRecordCount.Text = "Record Count: " + count;
            }

        }

        protected void btnExportToExcel_Click(object sender, EventArgs e)
        {
            CompanyReportingChild obj = new CompanyReportingChild();
            DataSet ds = obj.GetSKPickingBoard2("Select One", "Select One", "Select One");

            WorkbookEngine we = new WorkbookEngine();
            we.ExportDataSetToExcel(ds.Tables[0], "Sales Reporting");
        }
    }
}