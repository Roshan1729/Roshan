﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SalesReportingWebsite
{
    public partial class Region : PageBase
    {
        public int memberships;
        protected void Page_Load(object sender, EventArgs e)
        {

            VBFunctions.ADFunctions obj = new VBFunctions.ADFunctions();
            string userID = obj.GetUserName();
            // string dirEntry = obj.GetDirectoryEntry();
            memberships = obj.VerifyGroupMemberships("LDAP://192.168.100.3/ou=Cooper Network Users,dc=coopersurgical1,dc=com", "webapps", "Yankees#1", userID);

            if (!Page.IsPostBack)

            {
                if (memberships == 1 || memberships == 2 || memberships == 3)
                {
                    RegionReportingChild li = new RegionReportingChild();

                    DataTable table = new DataTable();



                    ddlCompanyName.DataSource = li.CompanyNameList().Tables[0];
                    ddlCompanyName.DataTextField = "CompanyName";
                    ddlCompanyName.DataBind();

                    ddlRegionName.DataSource = li.RegionNameList().Tables[0];
                    ddlRegionName.DataTextField = "RegionName";
                    ddlRegionName.DataBind();


                    ddlSubBusinessUnitName.DataSource = li.SubBusinessUnitNameList().Tables[0];
                    ddlSubBusinessUnitName.DataTextField = "SubBusinessUnitName";
                    ddlSubBusinessUnitName.DataBind();

                    //ddlRegionManagerName.DataSource = li.RegionManagerNameList().Tables[0];
                    //ddlRegionManagerName.DataTextField = "RegionManagerName";
                    //ddlRegionManagerName.DataBind();

                    newSubBusinessUnitName.DataSource = li.SubBusinessUnitNameList().Tables[0];
                    newSubBusinessUnitName.DataTextField = "SubBusinessUnitName";
                    newSubBusinessUnitName.DataBind();

                    newCompanyName.DataSource = li.CompanyNameList().Tables[0];
                    newCompanyName.DataTextField = "CompanyName";
                    newCompanyName.DataBind();

                    //newRegionManagerName.DataSource = li.RegionManagerNameList().Tables[0];
                    //newRegionManagerName.DataTextField = "RegionManagerName";
                    //newRegionManagerName.DataBind();

                    BindGridView();
                }
            }
        }

        #region EventHandling

        protected void Region_RowEditing(object sender, GridViewEditEventArgs e)
        {
            RegionGridView.EditIndex = e.NewEditIndex;
            int index = e.NewEditIndex;
            GridViewRow row = RegionGridView.Rows[e.NewEditIndex];

            BindGridView();
        }

        protected void Region_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            RegionGridView.EditIndex = -1;
            BindGridView();
        }


        protected void Region_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            if (Page.IsValid)
            {
                RegionReportingChild li = new RegionReportingChild();
                GridViewRow row = RegionGridView.Rows[e.RowIndex];
                string display = "";
                bool isFormFilled = true;
                try
                {
                    li.RegionID = Convert.ToInt32(RegionGridView.DataKeys[e.RowIndex].Values[0]);

                   
                    if (((TextBox)row.FindControl("CompanyKey")).Text != string.Empty)
                    {
                        li.RegionCode = Convert.ToInt32(((TextBox)row.FindControl("RegionCode")).Text);
                    }
                    else
                    {
                        display = "Region Code cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (((TextBox)row.FindControl("CompanyName")).Text != string.Empty)
                    {
                        li.CompanyName = Convert.ToString(((TextBox)row.FindControl("CompanyName")).Text);
                    }
                    else
                    {
                        display = "Company Name cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (((DropDownList)row.FindControl("RegionManagerName")).SelectedValue != "Select One")
                    {
                        li.RegionManagerName = ((DropDownList)row.FindControl("RegionManagerName")).SelectedValue;
                    }
                    else
                    {
                        display = "RegionManagerName from dropdown";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (((DropDownList)row.FindControl("SubBusinessUnitName")).SelectedValue != "Select One")
                    {
                        li.SubBusinessUnitName = ((DropDownList)row.FindControl("SubBusinessUnitName")).SelectedValue;
                    }
                    else
                    {
                        display = "Select SubBusinessUnitName from dropdown";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (!String.IsNullOrEmpty(Convert.ToString((Request.Form[row.FindControl("EffectiveDate").UniqueID]))))
                    {
                        li.EffectiveDate = Convert.ToDateTime((Request.Form[row.FindControl("EffectiveDate").UniqueID]));
                    }
                    else
                    {
                        display = "Effective Date cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (!String.IsNullOrEmpty(Convert.ToString((Request.Form[row.FindControl("ExpirationDate").UniqueID]))))
                    {
                        li.ExpirationDate = Convert.ToDateTime((Request.Form[row.FindControl("ExpirationDate").UniqueID]));
                    }
                    else
                    {
                        display = "Expiration Date cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (li.ExpirationDate < li.EffectiveDate)
                    {
                        display = "Expiration Date must be after Effective date";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (isFormFilled)
                    {
                        if (memberships == 1 || memberships == 2)
                        {
                            DataSet result = li.UpdateSKPickingBoard(li, memberships);

                            string res = Convert.ToString(result.Tables[0].Rows[0].ItemArray[0]);

                            if (res.Equals("Duplicate RegionCode"))
                            {
                                display = "Region Code  already exists in the database";
                                ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                            }
                            else if (res.Equals("Duplicate RegionName"))
                            {
                                display = "Region Name already exists in the database";
                                ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                            }

                            else if (res.Equals("Success"))
                            {
                            }
                        }
                        else
                        {
                            display = "You must be a member of Consolidated Sales Reporting – Admin or Consolidated Sales Reporting – Finance   groups to make changes.";
                            ClientScript.RegisterStartupScript(this.GetType(), "yourMessage", "alert('" + display + "');", true);
                        }
                    }
                    

                }
                catch (Exception ex)
                {
                    throw ex;
                }

                RegionGridView.EditIndex = -1;
                BindGridView();
            }
        }

        protected void Region_SortData(object sender, GridViewSortEventArgs e)
        {
            if (RegionGridView.EditIndex >= -1)
            {
                RegionGridView.EditIndex = -1;
            }
            BindGridView();
            SortGrid(sender, e);
        }

        protected void Region_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow && RegionGridView.EditIndex == e.Row.RowIndex)
            {
                RegionReportingChild li = new RegionReportingChild();


              
                //Find the DropDownList in the Row
                DropDownList ddlCompanyNameList = (e.Row.FindControl("CompanyName") as DropDownList);
                ddlCompanyNameList.DataSource = li.CompanyNameList().Tables[0];
                ddlCompanyNameList.DataTextField = "CompanyName";
                ddlCompanyNameList.DataValueField = "CompanyName";
                ddlCompanyNameList.DataBind();

                //Add Default Item in the DropDownList
                ddlCompanyNameList.Items.Insert(0, new ListItem("Select One"));

                //Select the Country of Customer in DropDownList
                string companyNames = (e.Row.FindControl("lblCompanyName") as Label).Text;
                ddlCompanyNameList.Items.FindByValue(companyNames).Selected = true;


                //Find the DropDownList in the Row
                DropDownList ddlSubBusinessUnitNameList = (e.Row.FindControl("SubBusinessUnitName") as DropDownList);
                ddlSubBusinessUnitNameList.DataSource = li.SubBusinessUnitNameList().Tables[0];
                ddlSubBusinessUnitNameList.DataTextField = "SubBusinessUnitName";
                ddlSubBusinessUnitNameList.DataValueField = "SubBusinessUnitName";
                ddlSubBusinessUnitNameList.DataBind();

                //Add Default Item in the DropDownList
                ddlSubBusinessUnitNameList.Items.Insert(0, new ListItem("Select One"));

                //Select the Country of Customer in DropDownList
                string subBusinessUnitNames = (e.Row.FindControl("lblSubBusinessUnitName") as Label).Text;
                ddlSubBusinessUnitNameList.Items.FindByValue(subBusinessUnitNames).Selected = true;


                //Find the DropDownList in the Row
                DropDownList ddlRegionManagerNameList = (e.Row.FindControl("RegionManagerName") as DropDownList);
                ddlRegionManagerNameList.DataSource = li.RegionManagerNameList().Tables[0];
                ddlRegionManagerNameList.DataTextField = "RegionManagerName";
                ddlRegionManagerNameList.DataValueField = "RegionManagerName";
                ddlRegionManagerNameList.DataBind();

                //Add Default Item in the DropDownList
                ddlRegionManagerNameList.Items.Insert(0, new ListItem("Select One"));

                //Select the Country of Customer in DropDownList
                string regionManagerNames = (e.Row.FindControl("lblRegionManagerName") as Label).Text;
                ddlRegionManagerNameList.Items.FindByValue(regionManagerNames).Selected = true;
            }
        }

        protected void Region_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            if (RegionGridView.EditIndex >= -1)
            {
                RegionGridView.EditIndex = -1;
            }
            BindGridView();
            PageGrid(sender, e);
        }

        protected void chkBoxResetCheckedChanged(object sender, EventArgs e)
        {
            if (RegionGridView.EditIndex >= -1)
            {
                RegionGridView.EditIndex = -1;
            }
            ddlCompanyName.SelectedIndex = 0;
            ddlRegionName.SelectedIndex = 0;
            ddlRegionManagerName.SelectedIndex = 0;
            ddlSubBusinessUnitName.SelectedIndex = 0;
            BindGridView();
        }

        #endregion
        protected void btnSaveNewRegion_Click(object sender, EventArgs e)
        {
            bool isFormFilled = true;
            string display = "";
            RegionReportingChild li = new RegionReportingChild();
            string regionCode = newRegionCode.Text;
            string regionName = newRegionName.Text;  
            string regionManagerName = newRegionManagerName.SelectedValue.ToString();
            string subBusinessUnitName = newSubBusinessUnitName.SelectedValue.ToString();
            string companyName = newCompanyName.SelectedValue.ToString();
            string effectiveDate = Request.Form[newEffectiveDate.UniqueID];


            if (String.IsNullOrEmpty(effectiveDate) || String.IsNullOrEmpty(regionCode)
                || String.IsNullOrEmpty(companyName) || String.IsNullOrEmpty(regionName) || String.IsNullOrEmpty(regionManagerName) || String.IsNullOrEmpty(subBusinessUnitName))
            {
                display = "Please select all the mandatory fields ";
                ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                isFormFilled = false;
            }


            if (isFormFilled)
            {
                if (memberships == 1 || memberships == 2)
                {
                    DataSet result = li.AddNewRegion(regionCode, regionName, regionManagerName, subBusinessUnitName, companyName, effectiveDate);

                    string res = Convert.ToString(result.Tables[0].Rows[0].ItemArray[0]);

                    if (res.Equals("Duplicate RegionCode"))
                    {
                        display = "Region Code already exists in the database";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }
                    else if (res.Equals("Duplicate RegionName"))
                    {
                        display = "Region Name already exists in the database";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    else if (res.Equals("Success"))
                    {
                        display = "A new Region is successfully added in the database";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = true;
                    }
                }
                else
                {
                    display = "You must be a member of Consolidated Sales Reporting – Admin or Consolidated Sales Reporting – Finance  groups to Add new Region.";
                    ClientScript.RegisterStartupScript(this.GetType(), "yourMessage", "alert('" + display + "');", true);
                }
                if (isFormFilled)
                {
                    newRegionCode.Text = "";
                    newRegionName.Text = "";
                    newRegionManagerName.SelectedIndex = 0;
                    newSubBusinessUnitName.SelectedIndex = 0;
                    newCompanyName.SelectedIndex = 0;
                    BindGridView();
                }
            }
        }

        protected void btnAddNewRegion_Click(object sender, EventArgs e)
        {
            ModalPopupExtender1.Show();
        }

        protected void ddl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (RegionGridView.EditIndex >= -1)
            {
                RegionGridView.EditIndex = -1;
            }
            BindGridView();
        }

        private void BindGridView()
        {
            int count;
            RegionReportingChild obj = new RegionReportingChild();

            string companyName = ddlCompanyName.SelectedValue.ToString();
            string regionName = ddlRegionName.SelectedValue.ToString();
            string regionManagerName = ddlRegionManagerName.SelectedValue.ToString();
            string subBusinessUnitName = ddlSubBusinessUnitName.SelectedValue.ToString();
            DataSet ds = obj.GetSKPickingBoard2(regionName, regionManagerName, subBusinessUnitName, companyName);
            RegionGridView.DataSource = ds.Tables[0];
            RegionGridView.DataBind();
            count = ds.Tables[0].Rows.Count;
            if (count > 1)
            {
                lblRecordCount.Text = "Record Count: " + count;
            }
            else
            {
                lblRecordCount.Text = "Record Count: " + count;
            }

        }

        protected void btnExportToExcel_Click(object sender, EventArgs e)
        {
            ModalPopupExtender2.Show();
            
        }

        protected void btnexcelDownloadAll_Click(object sender, EventArgs e)
        {
            ModalPopupExtender2.Hide();
            RegionReportingChild obj = new RegionReportingChild();
            DataSet ds = obj.GetSKPickingBoard2("Select One", "Select One", "Select One", "Select One");
            WorkbookEngine we = new WorkbookEngine();
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                if (dr.IsNull("ExpirationDate"))
                {
                    dr.Delete();
                }
                //DateTime expirationDate = Convert.ToDateTime(dr["ExpirationDate"].ToString());
            }
            we.ExportDataSetToExcel(ds.Tables[0], "Region Reporting");
        }

        protected void btnexcelDownload_Click(object sender, EventArgs e)
        {
            ModalPopupExtender2.Hide();
            RegionReportingChild obj = new RegionReportingChild();
            DataSet ds = obj.GetSKPickingBoard2("Select One", "Select One", "Select One", "Select One");
            WorkbookEngine we = new WorkbookEngine();
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                if (!dr.IsNull("ExpirationDate"))
                {
                    dr.Delete();
                }
                //DateTime expirationDate = Convert.ToDateTime(dr["ExpirationDate"].ToString());
            }
            we.ExportDataSetToExcel(ds.Tables[0], "Region Reporting");
        }
    }
}