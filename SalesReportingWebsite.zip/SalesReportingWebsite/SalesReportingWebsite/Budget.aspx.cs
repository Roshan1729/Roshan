﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SalesReportingWebsite
{
    public partial class Budget : PageBase
    {
        public int memberships;
        protected void Page_Load(object sender, EventArgs e)
        {

            //VBFunctions.ADFunctions obj = new VBFunctions.ADFunctions();
            //string userID = obj.GetUserName();
            //// string dirEntry = obj.GetDirectoryEntry();
            //memberships = obj.VerifyGroupMemberships("LDAP://192.168.100.3/ou=Cooper Network Users,dc=coopersurgical1,dc=com", "coopservice", "^CSIServ2016!", userID);

            if (!Page.IsPostBack)

            {
                BudgetReportingChild li = new BudgetReportingChild();

                DataTable table = new DataTable();

                ddlFiscalYear.DataSource = li.FiscalYearList().Tables[0];
                ddlFiscalYear.DataTextField = "FiscalYear";
                ddlFiscalYear.DataBind();


                ddlPeriod.DataSource = li.PeriodList().Tables[0];
                ddlPeriod.DataTextField = "Period";
                ddlPeriod.DataBind();

                ddlCompanyName.DataSource = li.CompanyNameList().Tables[0];
                ddlCompanyName.DataTextField = "CompanyName";
                ddlCompanyName.DataBind();

                ddlCurrencyCode.DataSource = li.CurrencyCodeList().Tables[0];
                ddlCurrencyCode.DataTextField = "CurrencyCode";
                ddlCurrencyCode.DataBind();

                ddlSubCategoryName.DataSource = li.SubCategoryNameList().Tables[0];
                ddlSubCategoryName.DataTextField = "SubCategoryName";
                ddlSubCategoryName.DataBind();


                ddlCountryName.DataSource = li.CountryNameList().Tables[0];
                ddlCountryName.DataTextField = "CountryName";
                ddlCountryName.DataBind();

                ddlSubBusinessUnitName.DataSource = li.SubBusinessUnitNameList().Tables[0];
                ddlSubBusinessUnitName.DataTextField = "SubBusinessUnitName";
                ddlSubBusinessUnitName.DataBind();



                BindGridView();
            }
        }

        #region EventHandling

        protected void Budget_RowEditing(object sender, GridViewEditEventArgs e)
        {
            BudgetGridView.EditIndex = e.NewEditIndex;
            int index = e.NewEditIndex;
            GridViewRow row = BudgetGridView.Rows[e.NewEditIndex];

            BindGridView();
        }

        protected void Budget_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            BudgetGridView.EditIndex = -1;
            BindGridView();
        }


        protected void Budget_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            if (Page.IsValid)
            {
                BudgetReportingChild li = new BudgetReportingChild();
                GridViewRow row = BudgetGridView.Rows[e.RowIndex];
                string display = "";
                bool isFormFilled = true;

                try
                {
                    li.BudgetID = Convert.ToInt32(BudgetGridView.DataKeys[e.RowIndex].Values[0]);
                    if (((TextBox)row.FindControl("BudgetDate")).Text != string.Empty)
                    {
                        li.Date = Convert.ToDateTime((Request.Form[row.FindControl("BudgetDate").UniqueID]));
                    }
                    else
                    {
                        li.Date = DateTime.MinValue;
                    }

                    if (((TextBox)row.FindControl("TargetQuantity")).Text != string.Empty)
                    {
                        li.Quantity = Convert.ToInt32(((TextBox)row.FindControl("TargetQuantity")).Text);
                    }
                    else
                    {
                        li.Quantity = 0;
                    }

                    if (((TextBox)row.FindControl("TargetAmountLCY")).Text != string.Empty)
                    {
                        li.AmountLCY = Convert.ToSingle(((TextBox)row.FindControl("TargetAmountLCY")).Text);
                    }
                    else
                    {
                        li.AmountLCY = 0;
                    }

                    if (((TextBox)row.FindControl("TargetAmountUSD")).Text != string.Empty)
                    {
                        li.AmountUSD = Convert.ToSingle(((TextBox)row.FindControl("TargetAmountUSD")).Text);
                    }
                    else
                    {
                        li.AmountUSD = 0;
                    }



                    if (((TextBox)row.FindControl("TargetCostLCY")).Text != string.Empty)
                    {
                        li.CostLCY = Convert.ToSingle(((TextBox)row.FindControl("TargetCostLCY")).Text);
                    }
                    else
                    {
                        li.CostLCY = 0;
                    }

                    if (((TextBox)row.FindControl("TargetCostUSD")).Text != string.Empty)
                    {
                        li.CostUSD = Convert.ToSingle(((TextBox)row.FindControl("TargetCostUSD")).Text);
                    }
                    else
                    {
                        li.CostUSD = 0;
                    }



                    if (((DropDownList)row.FindControl("ddlPeriods")).SelectedValue != "Select One")
                    {
                        li.Period = ((DropDownList)row.FindControl("ddlPeriods")).SelectedValue;
                    }
                    else
                    {
                        li.Period = String.Empty;
                    }


                    if (((DropDownList)row.FindControl("ddlCompanyNames")).SelectedValue != "Select One")
                    {
                        li.CompanyName = ((DropDownList)row.FindControl("ddlCompanyNames")).SelectedValue;
                    }
                    else
                    {
                        li.CompanyName = String.Empty;
                    }

                    if (((DropDownList)row.FindControl("ddlCurrencyCodes")).SelectedValue != "Select One")
                    {
                        li.CurrencyCode = ((DropDownList)row.FindControl("ddlCurrencyCodes")).SelectedValue;
                    }
                    else
                    {
                        li.CountryName = String.Empty;
                    }

                    if (((DropDownList)row.FindControl("ddlSubCategoryNames")).SelectedValue != "Select One")
                    {
                        li.SubCategoryName = ((DropDownList)row.FindControl("ddlSubCategoryNames")).SelectedValue;
                    }
                    else
                    {
                        li.SubCategoryName = String.Empty;
                    }

                    if (((DropDownList)row.FindControl("ddlCountryNames")).SelectedValue != "Select One")
                    {
                        li.CountryName = ((DropDownList)row.FindControl("ddlCountryNames")).SelectedValue;
                    }
                    else
                    {
                        li.CountryName = String.Empty;
                    }

                    if (((DropDownList)row.FindControl("ddlSubBusinessUnitNames")).SelectedValue != "Select One")
                    {
                        li.SubBusinessUnitName = ((DropDownList)row.FindControl("ddlSubBusinessUnitNames")).SelectedValue;
                    }
                    else
                    {
                        li.SubBusinessUnitName = String.Empty;
                    }


                    if (((TextBox)row.FindControl("FiscalYear")).Text != string.Empty)
                    {
                        li.FiscalYear = Convert.ToInt32(((TextBox)row.FindControl("FiscalYear")).Text);
                    }
                    else
                    {
                        display = "Fiscal Year cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (((TextBox)row.FindControl("TargetQuantity")).Text != string.Empty)
                    {
                        li.Quantity = Convert.ToInt32(((TextBox)row.FindControl("TargetQuantity")).Text);
                    }
                    else
                    {
                        display = "Quantity cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (((TextBox)row.FindControl("TargetAmountLCY")).Text != string.Empty)
                    {
                        li.AmountLCY = Convert.ToSingle(((TextBox)row.FindControl("TargetAmountLCY")).Text);
                    }
                    else
                    {
                        display = "AmountLCY cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }


                    if (((TextBox)row.FindControl("TargetAmountUSD")).Text != string.Empty)
                    {
                        li.AmountUSD = Convert.ToSingle(((TextBox)row.FindControl("TargetAmountUSD")).Text);
                    }
                    else
                    {
                        display = "AmountUSD cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }


                    if (((TextBox)row.FindControl("TargetCostUSD")).Text != string.Empty)
                    {
                        li.CostUSD = Convert.ToSingle(((TextBox)row.FindControl("TargetCostUSD")).Text);
                    }
                    else
                    {
                        display = "CostUSD cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }



                    if (((TextBox)row.FindControl("TargetCostLCY")).Text != string.Empty)
                    {
                        li.CostLCY = Convert.ToSingle(((TextBox)row.FindControl("TargetCostLCY")).Text);
                    }
                    else
                    {
                        display = "CostLCY cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }



                    if (((DropDownList)row.FindControl("CompanyName")).SelectedValue != "Select One")
                    {
                        li.CompanyName = ((DropDownList)row.FindControl("CompanyName")).SelectedValue;
                    }
                    else
                    {
                        display = "Select Company Name from dropdown";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }




                    if (((DropDownList)row.FindControl("CurrencyCode")).SelectedValue != "Select One")
                    {
                        li.CurrencyCode = ((DropDownList)row.FindControl("CurrencyCode")).SelectedValue;
                    }
                    else
                    {
                        display = "Select Currency Code from dropdown";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }


                    if (((DropDownList)row.FindControl("SubCategoryName")).SelectedValue != "Select One")
                    {
                        li.SubCategoryName = ((DropDownList)row.FindControl("SubCategoryName")).SelectedValue;
                    }
                    else
                    {
                        display = "Select Sub Category Name from dropdown";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }


                    if (((DropDownList)row.FindControl("CountryName")).SelectedValue != "Select One")
                    {
                        li.CountryName = ((DropDownList)row.FindControl("CountryName")).SelectedValue;
                    }
                    else
                    {
                        display = "Select Country Name from dropdown";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }




                    if (((DropDownList)row.FindControl("SubBusinessUnitName")).SelectedValue != "Select One")
                    {
                        li.SubBusinessUnitName = ((DropDownList)row.FindControl("SubBusinessUnitName")).SelectedValue;
                    }
                    else
                    {
                        display = "Select Sub Business Unit Name from dropdown";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }
                    if (!String.IsNullOrEmpty(Convert.ToString((Request.Form[row.FindControl("EffectiveDate").UniqueID]))))
                    {
                        li.EffectiveDate = Convert.ToDateTime((Request.Form[row.FindControl("EffectiveDate").UniqueID]));
                    }
                    else
                    {
                        display = "Effective Date cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (!String.IsNullOrEmpty(Convert.ToString((Request.Form[row.FindControl("ExpirationDate").UniqueID]))))
                    {
                        li.ExpirationDate = Convert.ToDateTime((Request.Form[row.FindControl("ExpirationDate").UniqueID]));
                    }
                    else
                    {
                        display = "Expiration Date cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (li.ExpirationDate < li.EffectiveDate)
                    {
                        display = "Expiration Date must be after Effective date";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    //if (isFormFilled)
                    //{
                    //    DataSet result = li.UpdateSKPickingBoard(li, memberships);

                    //    string res = Convert.ToString(result.Tables[0].Rows[0].ItemArray[0]);


                    //}



                    //li.UpdateSKPickingBoard(li, memberships);



                    //if (memberships > 0)
                    //{
                    //    li.UpdateSKPickingBoard(li, memberships);
                    //}
                    //else
                    //{
                    //    string display = "You must be a member of SK_Picking _Operations or SK_Picking_Warehouse groups to make changes.";
                    //    ClientScript.RegisterStartupScript(this.GetType(), "yourMessage", "alert('" + display + "');", true);
                    //}

                }

                catch (Exception ex)
                {
                    throw ex;
                }

                BudgetGridView.EditIndex = -1;
                BindGridView();
            }
        }

        protected void Budget_SortData(object sender, GridViewSortEventArgs e)
        {
            if (BudgetGridView.EditIndex >= -1)
            {
                BudgetGridView.EditIndex = -1;
            }
            BindGridView();
            SortGrid(sender, e);
        }

        protected void Budget_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow && BudgetGridView.EditIndex == e.Row.RowIndex)
            {
                BudgetReportingChild li = new BudgetReportingChild();



                //Find the DropDownList in the Row
                DropDownList ddlPeriodList = (DropDownList)e.Row.FindControl("ddlPeriods");
                ddlPeriodList.DataSource = li.PeriodList().Tables[0];
                //ddlPeriodList.DataSource = table;
                ddlPeriodList.DataTextField = "Period";
                ddlPeriodList.DataValueField = "Period";
                ddlPeriodList.DataBind();

                //Add Default Item in the DropDownList
                ddlPeriodList.Items.Insert(0, new ListItem("Select One"));

                //Select the Country of Customer in DropDownList
                string period = (e.Row.FindControl("lblPeriod") as Label).Text;
                ddlPeriodList.Items.FindByValue(period).Selected = true;

                //Find the DropDownList in the Row
                DropDownList ddlCurrencyCodeList = (e.Row.FindControl("ddlCurrencyCode") as DropDownList);
                ddlCurrencyCodeList.DataSource = li.CurrencyCodeList().Tables[0];
                ddlCurrencyCodeList.DataTextField = "CurrencyCode";
                ddlCurrencyCodeList.DataValueField = "CurrencyCode";
                ddlCurrencyCodeList.DataBind();

                //Add Default Item in the DropDownList
                ddlCurrencyCodeList.Items.Insert(0, new ListItem("Select One"));

                //Select the Country of Customer in DropDownList
                string currencyCodes = (e.Row.FindControl("lblCurrencyCode") as Label).Text;
                ddlCurrencyCodeList.Items.FindByValue(currencyCodes).Selected = true;


                //Find the DropDownList in the Row
                DropDownList ddlCountryNameList = (e.Row.FindControl("ddlCountryNames") as DropDownList);
                ddlCountryNameList.DataSource = li.CountryNameList().Tables[0];
                ddlCountryNameList.DataTextField = "CountryName";
                ddlCountryNameList.DataValueField = "CountryName";
                ddlCountryNameList.DataBind();

                //Add Default Item in the DropDownList
                ddlCountryNameList.Items.Insert(0, new ListItem("Select One"));

                //Select the Country of Customer in DropDownList
                string countryNames = (e.Row.FindControl("lblCountryName") as Label).Text;
                ddlCountryNameList.Items.FindByValue(countryNames).Selected = true;


                //Find the DropDownList in the Row
                DropDownList ddlSubBusinessUnitNameList = (e.Row.FindControl("ddlSubBusinessUnitNames") as DropDownList);
                ddlSubBusinessUnitNameList.DataSource = li.SubBusinessUnitNameList().Tables[0];
                ddlSubBusinessUnitNameList.DataTextField = "SubBusinessUnitName";
                ddlSubBusinessUnitNameList.DataValueField = "SubBusinessUnitName";
                ddlSubBusinessUnitNameList.DataBind();

                //Add Default Item in the DropDownList
                ddlSubBusinessUnitNameList.Items.Insert(0, new ListItem("Select One"));

                //Select the Country of Customer in DropDownList
                string subBusinessUnitNames = (e.Row.FindControl("lblSubBusinessUnitName") as Label).Text;
                ddlSubBusinessUnitNameList.Items.FindByValue(subBusinessUnitNames).Selected = true;


                //Find the DropDownList in the Row
                DropDownList ddlCompanyNameList = (e.Row.FindControl("ddlCompanyNames") as DropDownList);
                ddlCompanyNameList.DataSource = li.CompanyNameList().Tables[0];
                ddlCompanyNameList.DataTextField = "CompanyName";
                ddlCompanyNameList.DataValueField = "CompanyName";
                ddlCompanyNameList.DataBind();

                //Add Default Item in the DropDownList
                ddlCompanyNameList.Items.Insert(0, new ListItem("Select One"));

                //Select the Country of Customer in DropDownList
                string companyNames = (e.Row.FindControl("lblCompanyName") as Label).Text;
                ddlCompanyNameList.Items.FindByValue(companyNames).Selected = true;


                //Find the DropDownList in the Row
                DropDownList ddlSubCategoryNameList = (e.Row.FindControl("ddlSubCategoryNames") as DropDownList);
                ddlSubCategoryNameList.DataSource = li.SubCategoryNameList().Tables[0];
                ddlSubCategoryNameList.DataTextField = "SubCategoryName";
                ddlSubCategoryNameList.DataValueField = "SubCategoryName";
                ddlSubCategoryNameList.DataBind();

                //Add Default Item in the DropDownList
                ddlSubCategoryNameList.Items.Insert(0, new ListItem("Select One"));

                //Select the Country of Customer in DropDownList
                string subCategoryNames = (e.Row.FindControl("lblSubCategoryName") as Label).Text;
                ddlSubCategoryNameList.Items.FindByValue(subCategoryNames).Selected = true;

            }
        }

        protected void Budget_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            if (BudgetGridView.EditIndex >= -1)
            {
                BudgetGridView.EditIndex = -1;
            }
            BindGridView();
            PageGrid(sender, e);
        }

        protected void chkBoxResetCheckedChanged(object sender, EventArgs e)
        {
            if (BudgetGridView.EditIndex >= -1)
            {
                BudgetGridView.EditIndex = -1;
            }

            ddlFiscalYear.SelectedIndex = 0;
            txtFromDate.Text = "Select One";
            txtToDate.Text = "Select One";
            ddlPeriod.SelectedIndex = 0;
            txtFromQuantity.Text = "0";
            txtToQuantity.Text = "99999999";
            txtFromAmountUSD.Text = "0";
            txtToAmountUSD.Text = "99999999";
            txtFromCostUSD.Text = "0";
            txtToCostUSD.Text = "99999999";
            ddlCurrencyCode.SelectedIndex = 0;
            ddlCountryName.SelectedIndex = 0;
            ddlSubBusinessUnitName.SelectedIndex = 0;
            ddlCompanyName.SelectedIndex = 0;
            ddlSubCategoryName.SelectedIndex = 0;

            BindGridView();
        }


        protected void ddl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (BudgetGridView.EditIndex >= -1)
            {
                BudgetGridView.EditIndex = -1;
            }
            BindGridView();
        }

        private void BindGridView()
        {
            int count;
            BudgetReportingChild obj = new BudgetReportingChild();
            // BaseClass.LowInventoryChild obj = null;

            string fiscalYear = ddlFiscalYear.SelectedValue.ToString();
            string fromDate = Request.Form[txtFromDate.UniqueID];
            string toDate = Request.Form[txtToDate.UniqueID];
            string period = ddlPeriod.SelectedValue.ToString();
            string fromQuantity = txtFromQuantity.Text;
            string toQuantity = txtToQuantity.Text;
            string fromAmountUSD = txtFromAmountUSD.Text;
            string toAmountUSD = txtToAmountUSD.Text;
            string fromCostUSD = txtFromCostUSD.Text;
            string toCostUSD = txtToCostUSD.Text;
            string currencyCode = ddlCurrencyCode.SelectedValue.ToString();
            string countryName = ddlCountryName.SelectedValue.ToString();
            string subBusinessUnitName = ddlSubBusinessUnitName.SelectedValue.ToString();
            string companyName = ddlCompanyName.SelectedValue.ToString();
            // string subSegmentName = ddlSubSegmentName.SelectedValue.ToString();
            // string accountSubTypeName = ddlAccountSubTypeName.SelectedValue.ToString();
            string subCategoryName = ddlSubCategoryName.SelectedValue.ToString();

            DataSet ds = obj.GetSKPickingBoard(fiscalYear, fromDate, toDate, period, fromQuantity, toQuantity, fromAmountUSD, toAmountUSD, fromCostUSD, toCostUSD, companyName, currencyCode, subCategoryName, countryName, subBusinessUnitName);
            BudgetGridView.DataSource = ds.Tables[0];
            BudgetGridView.DataBind();
            count = ds.Tables[0].Rows.Count;
            if (count > 1)
            {
                lblRecordCount.Text = "Record Count: " + count;
            }
            else
            {
                lblRecordCount.Text = "Record Count: " + count;
            }
            txtFromDate.Text = fromDate;
            txtToDate.Text = toDate;
            txtFromQuantity.Text = fromQuantity;
            txtToQuantity.Text = toQuantity;
            txtFromAmountUSD.Text = fromAmountUSD;
            txtToAmountUSD.Text = toAmountUSD;
            txtFromCostUSD.Text = fromCostUSD;
            txtToCostUSD.Text = toCostUSD;
        }
        protected void btnExportToExcel_Click(object sender, EventArgs e)
        {
            BudgetReportingChild obj = new BudgetReportingChild();
            DataSet ds = obj.GetSKPickingBoard("Select One", "Select One", "Select One", "Select One", "Select One", "Select One", "Select One", "Select One", "Select One", "Select One", "Select One", "Select One", "Select One", "Select One", "Select One");

            WorkbookEngine we = new WorkbookEngine();
            we.ExportDataSetToExcel(ds.Tables[0], "Budget Reporting");
        }
    }
}

#endregion