﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SalesReportingWebsite
{
    public partial class AccountSubType : PageBase
    {
        public int memberships;
        protected void Page_Load(object sender, EventArgs e)
        {

            VBFunctions.ADFunctions obj = new VBFunctions.ADFunctions();
            string userID = obj.GetUserName();
            // string dirEntry = obj.GetDirectoryEntry();
            memberships = obj.VerifyGroupMemberships("LDAP://192.168.100.3/ou=Cooper Network Users,dc=coopersurgical1,dc=com", "webapps", "Yankees#1", userID);
            
            if (!Page.IsPostBack)
            {
                if (memberships == 1 || memberships == 2)
                {
                    AccountSubTypeReportingChild li = new AccountSubTypeReportingChild();

                    DataTable table = new DataTable();

                    ddlAccountSubTypeName.DataSource = li.AccountSubTypeNameList().Tables[0];
                    ddlAccountSubTypeName.DataTextField = "AccountSubTypeName";
                    ddlAccountSubTypeName.DataBind();

                    ddlAccountTypeName.DataSource = li.AccountTypeNameList().Tables[0];
                    ddlAccountTypeName.DataTextField = "AccountTypeName";
                    ddlAccountTypeName.DataBind();

                    newAccountTypeName.DataSource = li.AccountTypeNameList().Tables[0];
                    newAccountTypeName.DataTextField = "AccountTypeName";
                    newAccountTypeName.DataBind();

                    BindGridView();
                }
                else
                {
                    string display = "You must be a member of 'Consolidated Sales Reporting – Admin' or 'Consolidated Sales Reporting – Finance' groups to make changes.";
                    ClientScript.RegisterStartupScript(this.GetType(), "yourMessage", "alert('" + display + "');", true);
                }
            }
        }
        
        #region EventHandling
              
        protected void AccountSubType_RowEditing(object sender, GridViewEditEventArgs e)
        {
            AccountSubTypeGridView.EditIndex = e.NewEditIndex;
            int index = e.NewEditIndex;
            GridViewRow row = AccountSubTypeGridView.Rows[e.NewEditIndex];

            BindGridView();
        }
        
        protected void AccountSubType_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            AccountSubTypeGridView.EditIndex = -1;
            BindGridView();
        }


        protected void AccountSubType_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            if (Page.IsValid)
            {
                AccountSubTypeReportingChild li = new AccountSubTypeReportingChild();
                GridViewRow row = AccountSubTypeGridView.Rows[e.RowIndex];
                string display = "";
                bool isFormFilled = true;
                try
                {
                    li.AccountSubTypeID = Convert.ToInt32(AccountSubTypeGridView.DataKeys[e.RowIndex].Values[0]);

                    if (((TextBox)row.FindControl("AccountSubTypeCode")).Text != string.Empty)
                    {
                        li.AccountSubTypeCode = Convert.ToString(((TextBox)row.FindControl("AccountSubTypeCode")).Text);
                    }
                    else
                    {
                        display = "Account Sub Type Code cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (((TextBox)row.FindControl("AccountSubTypeName")).Text != string.Empty)
                    {
                        li.AccountSubTypeName = Convert.ToString(((TextBox)row.FindControl("AccountSubTypeName")).Text);
                    }
                    else
                    {
                        display = "Account Sub Type Name cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (((DropDownList)row.FindControl("AccountTypeName")).SelectedValue != "Select One")
                    {
                        li.AccountTypeName = ((DropDownList)row.FindControl("AccountTypeName")).SelectedValue;
                    }
                    else
                    {
                        display = "Select Account Type Name from dropdown";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }
                    if (!String.IsNullOrEmpty(Convert.ToString((Request.Form[row.FindControl("EffectiveDate").UniqueID]))))
                    {
                        li.EffectiveDate = Convert.ToDateTime((Request.Form[row.FindControl("EffectiveDate").UniqueID]));
                    }
                    else
                    {
                        display = "Effective Date cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }
                    if (!String.IsNullOrEmpty(Convert.ToString((Request.Form[row.FindControl("ExpirationDate").UniqueID]))))
                    {
                        li.ExpirationDate = Convert.ToDateTime((Request.Form[row.FindControl("ExpirationDate").UniqueID]));
                    }
                    else
                    {
                        display = "Expiration Date cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (li.ExpirationDate < li.EffectiveDate)
                    {
                        display = "Expiration Date must be after Effective date";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (isFormFilled)
                    {
                        if (memberships == 1 || memberships == 2)
                        {
                            DataSet result = li.UpdateSKPickingBoard(li, memberships);

                            string res = Convert.ToString(result.Tables[0].Rows[0].ItemArray[0]);

                            if (res.Equals("Duplicate AccountSubTypeName"))
                            {
                                display = "Account Sub Type Name already exists in the database";
                                ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                            }
                            else if (res.Equals("Duplicate AccountSubTypeCode"))
                            {
                                display = "Account Sub Type Code already exists in the database";
                                ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                            }
                            else if (res.Equals("Success"))
                            {
                            }
                        }
                        else
                        {
                            display = "You must be a member of 'Consolidated Sales Reporting – Admin' or 'Consolidated Sales Reporting – Finance' groups to make changes.";
                            ClientScript.RegisterStartupScript(this.GetType(), "yourMessage", "alert('" + display + "');", true);
                        }
                    }

                }
                catch (Exception ex)
                {
                    throw ex;
                }

                AccountSubTypeGridView.EditIndex = -1;
                BindGridView();
            }
        }

        protected void AccountSubType_SortData(object sender, GridViewSortEventArgs e)
        {
            if (AccountSubTypeGridView.EditIndex >= -1)
            {
                AccountSubTypeGridView.EditIndex = -1;
            }
            BindGridView();
            SortGrid(sender, e);
        }

        protected void AccountSubType_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow && AccountSubTypeGridView.EditIndex == e.Row.RowIndex)
            {
                AccountSubTypeReportingChild li = new AccountSubTypeReportingChild();

                //Find the DropDownList in the Row
                DropDownList ddlAccountTypeNameList = (e.Row.FindControl("AccountTypeName") as DropDownList);
                ddlAccountTypeNameList.DataSource = li.AccountTypeNameList().Tables[0];
                ddlAccountTypeNameList.DataTextField = "AccountTypeName";
                ddlAccountTypeNameList.DataValueField = "AccountTypeName";
                ddlAccountTypeNameList.DataBind();

                //Add Default Item in the DropDownList
                ddlAccountTypeNameList.Items.Insert(0, new ListItem("Select One"));

                //Select the Country of Customer in DropDownList
                string accountTypeNames = (e.Row.FindControl("lblAccountTypeName") as Label).Text;
                ddlAccountTypeNameList.Items.FindByValue(accountTypeNames).Selected = true;
            }
        }

        protected void AccountSubType_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            if (AccountSubTypeGridView.EditIndex >= -1)
            {
                AccountSubTypeGridView.EditIndex = -1;
            }
            BindGridView();
            PageGrid(sender, e);
        }
        
        protected void chkBoxResetCheckedChanged(object sender, EventArgs e)
        {
            if (AccountSubTypeGridView.EditIndex >= -1)
            {
                AccountSubTypeGridView.EditIndex = -1;
            }
            ddlAccountTypeName.SelectedIndex = 0;
            ddlAccountSubTypeName.SelectedIndex = 0;
            BindGridView();
        }

        #endregion
        protected void btnSaveNewAccountSubType_Click(object sender, EventArgs e)
        {
            bool isFormFilled = true;
            string display = "";
            AccountSubTypeReportingChild li = new AccountSubTypeReportingChild();
            string accountSubTypeName = newAccountSubTypeName.Text;
            string accountSubTypeCode = newAccountSubTypeCode.Text;
            string accountTypeName = newAccountTypeName.Text;
            string effectiveDate = Request.Form[newEffectiveDate.UniqueID];
            
          
            if (String.IsNullOrEmpty(effectiveDate) || String.IsNullOrEmpty(accountSubTypeName) 
                || String.IsNullOrEmpty(accountSubTypeCode) || String.IsNullOrEmpty(accountTypeName))
            {
                display = "Please select all the mandatory fields ";
                ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                isFormFilled = false;
            }


            if (isFormFilled)
            {
                if (memberships == 1 || memberships == 2)
                {
                    DataSet result = li.AddNewAccountSubType(accountSubTypeCode, accountSubTypeName, accountTypeName, effectiveDate);

                    string res = Convert.ToString(result.Tables[0].Rows[0].ItemArray[0]);

                    if (res.Equals("Duplicate AccountSubTypeName"))
                    {
                        display = "Account Sub Type Name already exists in the database";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }
                    else if (res.Equals("Duplicate AccountSubTypeCode"))
                    {
                        display = "Account Sub Type Code already exists in the database";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }
                    else if (res.Equals("Success"))
                    {
                        display = "A new Account Sub Type is successfully added in the database";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = true;
                    }
                }
                else
                {
                    display = "You must be a member of 'Consolidated Sales Reporting – Admin' or 'Consolidated Sales Reporting – Finance' groups to make changes.";
                    ClientScript.RegisterStartupScript(this.GetType(), "yourMessage", "alert('" + display + "');", true);
                }
                    if (isFormFilled)
                    {
                        newAccountSubTypeCode.Text = "";
                        newAccountSubTypeName.Text = "";
                        ddlAccountTypeName.DataSource = li.AccountTypeNameList().Tables[0];
                        ddlAccountTypeName.DataTextField = "AccountTypeName";
                        ddlAccountTypeName.DataBind();
                        ddlAccountSubTypeName.DataSource = li.AccountSubTypeNameList().Tables[0];
                        ddlAccountSubTypeName.DataTextField = "AccountSubTypeName";
                        ddlAccountSubTypeName.DataBind();
                        newEffectiveDate.Text = "";
                        BindGridView();
                    }
            }
        }

        protected void btnAddNewAccountSubType_Click(object sender, EventArgs e)
        {
            ModalPopupExtender1.Show();
        }

        protected void ddl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (AccountSubTypeGridView.EditIndex >= -1)
            {
                AccountSubTypeGridView.EditIndex = -1;
            }
            BindGridView();
        }

        private void BindGridView()
        {
            int count;
            AccountSubTypeReportingChild obj = new AccountSubTypeReportingChild();
           
            string accountTypeName = ddlAccountTypeName.SelectedValue.ToString();
            string accountSubTypeName = ddlAccountSubTypeName.SelectedValue.ToString();
            DataSet ds = obj.GetSKPickingBoard2(accountSubTypeName, accountTypeName);
            AccountSubTypeGridView.DataSource = ds.Tables[0];
            AccountSubTypeGridView.DataBind();
            count = ds.Tables[0].Rows.Count;
            if (count > 1)
            {
                lblRecordCount.Text = "Record Count: " + count;
            }
            else
            {
                lblRecordCount.Text = "Record Count: " + count;
            }
            
        }
                
        protected void btnExportToExcel_Click(object sender, EventArgs e)
        {

            ModalPopupExtender2.Show();
            
        }

        protected void btnexcelDownloadAll_Click(object sender, EventArgs e)
        {
            ModalPopupExtender2.Hide();
            AccountSubTypeReportingChild obj = new AccountSubTypeReportingChild();
            DataSet ds = obj.GetSKPickingBoard2("Select One", "Select One");
            WorkbookEngine we = new WorkbookEngine();
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                if (dr.IsNull("ExpirationDate"))
                {
                    dr.Delete();
                }
                //DateTime expirationDate = Convert.ToDateTime(dr["ExpirationDate"].ToString());
            }
            we.ExportDataSetToExcel(ds.Tables[0], "AccountSubType Reporting");
        }

        protected void btnexcelDownload_Click(object sender, EventArgs e)
        {
            ModalPopupExtender2.Hide();
            AccountSubTypeReportingChild obj = new AccountSubTypeReportingChild();
            DataSet ds = obj.GetSKPickingBoard2("Select One", "Select One");
            WorkbookEngine we = new WorkbookEngine();
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                if (!dr.IsNull("ExpirationDate"))
                {
                    dr.Delete();
                }
                //DateTime expirationDate = Convert.ToDateTime(dr["ExpirationDate"].ToString());
            }
            we.ExportDataSetToExcel(ds.Tables[0], "AccountSubType Reporting");
        }
    }
}