﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SalesReportingWebsite
{
    public partial class ItemException : PageBase
    {
        public int memberships;
        protected void Page_Load(object sender, EventArgs e)
        {

            VBFunctions.ADFunctions obj = new VBFunctions.ADFunctions();
            string userID = obj.GetUserName();
            // string dirEntry = obj.GetDirectoryEntry();
            memberships = obj.VerifyGroupMemberships("LDAP://192.168.100.3/ou=Cooper Network Users,dc=coopersurgical1,dc=com", "webapps", "Yankees#1", userID);

            if (!Page.IsPostBack)

            {
                if (memberships == 1 || memberships == 2)
                {
                    ItemExceptionReportingChild li = new ItemExceptionReportingChild();

                    DataTable table = new DataTable();



                    ddlItemDescription.DataSource = li.ItemDescriptionList().Tables[0];
                    ddlItemDescription.DataTextField = "ItemDescription";
                    ddlItemDescription.DataBind();

                    ddlSubCategoryName.DataSource = li.SubCategoryNameList().Tables[0];
                    ddlSubCategoryName.DataTextField = "SubCategoryName";
                    ddlSubCategoryName.DataBind();


                    ddlCommissionSubCategoryName.DataSource = li.CommissionSubCategoryNameList().Tables[0];
                    ddlCommissionSubCategoryName.DataTextField = "CommissionSubCategoryName";
                    ddlCommissionSubCategoryName.DataBind();


                    newItemDescription.DataSource = li.ItemDescriptionList().Tables[0];
                    newItemDescription.DataTextField = "ItemDescription";
                    newItemDescription.DataBind();

                    newSubCategoryName.DataSource = li.SubCategoryNameList().Tables[0];
                    newSubCategoryName.DataTextField = "SubCategoryName";
                    newSubCategoryName.DataBind();

                    newCommissionSubCategoryName.DataSource = li.CommissionSubCategoryNameList().Tables[0];
                    newCommissionSubCategoryName.DataTextField = "CommissionSubCategoryName";
                    newCommissionSubCategoryName.DataBind();


                    BindGridView();
                }
            }
        }

        #region EventHandling

        protected void ItemException_RowEditing(object sender, GridViewEditEventArgs e)
        {
            ItemExceptionGridView.EditIndex = e.NewEditIndex;
            int index = e.NewEditIndex;
            GridViewRow row = ItemExceptionGridView.Rows[e.NewEditIndex];

            BindGridView();
        }

        protected void ItemException_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            ItemExceptionGridView.EditIndex = -1;
            BindGridView();
        }


        protected void ItemException_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            if (Page.IsValid)
            {
                ItemExceptionReportingChild li = new ItemExceptionReportingChild();
                GridViewRow row = ItemExceptionGridView.Rows[e.RowIndex];
                string display = "";
                bool isFormFilled = true;
                try
                {
                    li.ItemExceptionID = Convert.ToInt32(ItemExceptionGridView.DataKeys[e.RowIndex].Values[0]);

                    if (((DropDownList)row.FindControl("ItemDescription")).SelectedValue != "Select One")
                    {
                        li.ItemDescription = ((DropDownList)row.FindControl("ItemDescription")).SelectedValue;
                    }
                    else
                    {
                        display = "Item Description from dropdown";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (((DropDownList)row.FindControl("SubCategoryName")).SelectedValue != "Select One")
                    {
                        li.SubCategoryName = ((DropDownList)row.FindControl("SubCategoryName")).SelectedValue;
                    }
                    else
                    {
                        display = "Select Sub Category Name from dropdown";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (((DropDownList)row.FindControl("CommissionSubCategoryName")).SelectedValue != "Select One")
                    {
                        li.CommissionSubCategoryName = ((DropDownList)row.FindControl("CommissionSubCategoryName")).SelectedValue;
                    }
                    else
                    {
                        display = "Select Commission Sub Category Name from dropdown";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (!String.IsNullOrEmpty(Convert.ToString((Request.Form[row.FindControl("EffectiveDate").UniqueID]))))
                    {
                        li.EffectiveDate = Convert.ToDateTime((Request.Form[row.FindControl("EffectiveDate").UniqueID]));
                    }
                    else
                    {
                        display = "Effective Date cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (!String.IsNullOrEmpty(Convert.ToString((Request.Form[row.FindControl("ExpirationDate").UniqueID]))))
                    {
                        li.ExpirationDate = Convert.ToDateTime((Request.Form[row.FindControl("ExpirationDate").UniqueID]));
                    }
                    else
                    {
                        display = "Expiration Date cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (li.ExpirationDate < li.EffectiveDate)
                    {
                        display = "Expiration Date must be after Effective date";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (isFormFilled)
                    {
                        if (memberships == 1 || memberships == 2)
                        {
                            DataSet result = li.UpdateSKPickingBoard(li, memberships);

                            string res = Convert.ToString(result.Tables[0].Rows[0].ItemArray[0]);

                            //if (res.Equals("Duplicate CompanyKey"))
                            //{
                            //    display = "Company Key  already exists in the database";
                            //    ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                            //}
                            //else if (res.Equals("Duplicate CompanyName"))
                            //{
                            //    display = "Company Name already exists in the database";
                            //    ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                            //}

                            //else if (res.Equals("Success"))
                            //{
                            //}
                        }
                        else
                        {
                            display = "You must be a member of Consolidated Sales Reporting – Admin or Consolidated Sales Reporting – Finance  to make changes.";
                            ClientScript.RegisterStartupScript(this.GetType(), "yourMessage", "alert('" + display + "');", true);
                        }
                    }
                    //if (memberships > 0)
                    //{
                    //    li.UpdateSKPickingBoard(li, memberships);
                    //}
                    //else
                    //{
                    //    string display = "You must be a member of SK_Picking _Operations or SK_Picking_Warehouse groups to make changes.";
                    //    ClientScript.RegisterStartupScript(this.GetType(), "yourMessage", "alert('" + display + "');", true);
                    //}

                }
                catch (Exception ex)
                {
                    throw ex;
                }

                ItemExceptionGridView.EditIndex = -1;
                BindGridView();
            }
        }

        protected void ItemException_SortData(object sender, GridViewSortEventArgs e)
        {
            if (ItemExceptionGridView.EditIndex >= -1)
            {
                ItemExceptionGridView.EditIndex = -1;
            }
            BindGridView();
            SortGrid(sender, e);
        }

        protected void ItemException_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow && ItemExceptionGridView.EditIndex == e.Row.RowIndex)
            {
                ItemExceptionReportingChild li = new ItemExceptionReportingChild();


              
                //Find the DropDownList in the Row
                DropDownList ddlItemDescriptionList = (e.Row.FindControl("ItemDescription") as DropDownList);
                ddlItemDescriptionList.DataSource = li.ItemDescriptionList().Tables[0];
                ddlItemDescriptionList.DataTextField = "ItemDescription";
                ddlItemDescriptionList.DataValueField = "ItemDescription";
                ddlItemDescriptionList.DataBind();

                //Add Default Item in the DropDownList
                ddlItemDescriptionList.Items.Insert(0, new ListItem("Select One"));

                //Select the Country of Customer in DropDownList
                string itemDescriptions = (e.Row.FindControl("lblItemDescription") as Label).Text;
                ddlItemDescriptionList.Items.FindByValue(itemDescriptions).Selected = true;


                //Find the DropDownList in the Row
                DropDownList ddlSubCategoryNameList = (e.Row.FindControl("SubCategoryName") as DropDownList);
                ddlSubCategoryNameList.DataSource = li.SubCategoryNameList().Tables[0];
                ddlSubCategoryNameList.DataTextField = "SubCategoryName";
                ddlSubCategoryNameList.DataValueField = "SubCategoryName";
                ddlSubCategoryNameList.DataBind();

                //Add Default Item in the DropDownList
                ddlSubCategoryNameList.Items.Insert(0, new ListItem("Select One"));

                //Select the Country of Customer in DropDownList
                string subCategoryNames = (e.Row.FindControl("lblSubCategoryName") as Label).Text;
                ddlSubCategoryNameList.Items.FindByValue(subCategoryNames).Selected = true;



                //Find the DropDownList in the Row
                DropDownList ddlCommissionSubCategoryNameList = (e.Row.FindControl("CommissionSubCategoryName") as DropDownList);
                ddlCommissionSubCategoryNameList.DataSource = li.CommissionSubCategoryNameList().Tables[0];
                ddlCommissionSubCategoryNameList.DataTextField = "CommissionSubCategoryName";
                ddlCommissionSubCategoryNameList.DataValueField = "CommissionSubCategoryName";
                ddlCommissionSubCategoryNameList.DataBind();

                //Add Default Item in the DropDownList
                ddlCommissionSubCategoryNameList.Items.Insert(0, new ListItem("Select One"));

                //Select the Country of Customer in DropDownList
                string commissionSubCategoryNames = (e.Row.FindControl("lblCommissionSubCategoryName") as Label).Text;
                ddlCommissionSubCategoryNameList.Items.FindByValue(commissionSubCategoryNames).Selected = true;


            }
        }

        protected void ItemException_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            if (ItemExceptionGridView.EditIndex >= -1)
            {
                ItemExceptionGridView.EditIndex = -1;
            }
            BindGridView();
            PageGrid(sender, e);
        }

        protected void chkBoxResetCheckedChanged(object sender, EventArgs e)
        {
            if (ItemExceptionGridView.EditIndex >= -1)
            {
                ItemExceptionGridView.EditIndex = -1;
            }
            ddlItemDescription.SelectedIndex = 0;
            ddlSubCategoryName.SelectedIndex = 0;
            ddlCommissionSubCategoryName.SelectedIndex = 0;
            BindGridView();
        }

        #endregion
        protected void btnSaveNewItemException_Click(object sender, EventArgs e)
        {
            bool isFormFilled = true;
            string display = "";
            ItemExceptionReportingChild li = new ItemExceptionReportingChild();
            
            string itemDescription = newItemDescription.SelectedValue.ToString();
            string subCategoryName = newSubCategoryName.SelectedValue.ToString();
            string commissionSubCategoryName = newCommissionSubCategoryName.SelectedValue.ToString();
            string effectiveDate = Request.Form[newEffectiveDate.UniqueID];


            if (String.IsNullOrEmpty(effectiveDate) || String.IsNullOrEmpty(itemDescription)
                || String.IsNullOrEmpty(subCategoryName) || String.IsNullOrEmpty(commissionSubCategoryName))
            {
                display = "Please select all the mandatory fields ";
                ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                isFormFilled = false;
            }


            if (isFormFilled)
            {
                if (memberships == 1 || memberships == 2)
                {
                    DataSet result = li.AddNewItemException(itemDescription, subCategoryName, commissionSubCategoryName, effectiveDate);

                    string res = Convert.ToString(result.Tables[0].Rows[0].ItemArray[0]);

                    //if (res.Equals("Duplicate CompanyKey"))
                    //{
                    //    display = "Company Key already exists in the database";
                    //    ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                    //    isFormFilled = false;
                    //}
                    //else if (res.Equals("Duplicate CompanyName"))
                    //{
                    //    display = "Company Name already exists in the database";
                    //    ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                    //    isFormFilled = false;
                    //}

                    //else if (res.Equals("Success"))
                    //{
                    //    display = "A new Company is successfully added in the database";
                    //    ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                    //    isFormFilled = true;
                    //}

                }
                else
                {
                    display = "You must be a member of Consolidated Sales Reporting – Admin or Consolidated Sales Reporting – Finance  groups to make changes.";
                    ClientScript.RegisterStartupScript(this.GetType(), "yourMessage", "alert('" + display + "');", true);
                }
                if (isFormFilled)
                {
                    
                    newItemDescription.SelectedIndex = 0;
                    newCommissionSubCategoryName.SelectedIndex = 0;
                    newSubCategoryName.SelectedIndex = 0;
                    BindGridView();
                }
            }
        }

        protected void btnAddNewItemException_Click(object sender, EventArgs e)
        {
            ModalPopupExtender1.Show();
        }

        protected void ddl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ItemExceptionGridView.EditIndex >= -1)
            {
                ItemExceptionGridView.EditIndex = -1;
            }
            BindGridView();
        }

        private void BindGridView()
        {
            int count;
            ItemExceptionReportingChild obj = new ItemExceptionReportingChild();

            string itemDescription = ddlItemDescription.SelectedValue.ToString();
            string subCategoryName = ddlSubCategoryName.SelectedValue.ToString();
            string commissionSubCategoryName = ddlCommissionSubCategoryName.SelectedValue.ToString();
            DataSet ds = obj.GetSKPickingBoard2(itemDescription, subCategoryName, commissionSubCategoryName);
            ItemExceptionGridView.DataSource = ds.Tables[0];
            ItemExceptionGridView.DataBind();
            count = ds.Tables[0].Rows.Count;
            if (count > 1)
            {
                lblRecordCount.Text = "Record Count: " + count;
            }
            else
            {
                lblRecordCount.Text = "Record Count: " + count;
            }

        }

        protected void btnExportToExcel_Click(object sender, EventArgs e)
        {

            ModalPopupExtender2.Show();
           
        }
        protected void btnexcelDownloadAll_Click(object sender, EventArgs e)
        {
            ModalPopupExtender2.Hide();
            ItemExceptionReportingChild obj = new ItemExceptionReportingChild();
            DataSet ds = obj.GetSKPickingBoard2("Select One", "Select One", "Select One");
            WorkbookEngine we = new WorkbookEngine();
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                if (dr.IsNull("ExpirationDate"))
                {
                    dr.Delete();
                }
                //DateTime expirationDate = Convert.ToDateTime(dr["ExpirationDate"].ToString());
            }
            we.ExportDataSetToExcel(ds.Tables[0], "ItemException Reporting");
        }

        protected void btnexcelDownload_Click(object sender, EventArgs e)
        {
            ModalPopupExtender2.Hide();
            ItemExceptionReportingChild obj = new ItemExceptionReportingChild();
            DataSet ds = obj.GetSKPickingBoard2("Select One", "Select One", "Select One");
            WorkbookEngine we = new WorkbookEngine();
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                if (!dr.IsNull("ExpirationDate"))
                {
                    dr.Delete();
                }
                //DateTime expirationDate = Convert.ToDateTime(dr["ExpirationDate"].ToString());
            }
            we.ExportDataSetToExcel(ds.Tables[0], "ItemException Reporting");
        }
    }
}