﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SalesReportingWebsite
{
    public partial class Category : PageBase
    {
        public int memberships;
        protected void Page_Load(object sender, EventArgs e)
        {

            //VBFunctions.ADFunctions obj = new VBFunctions.ADFunctions();
            //string userID = obj.GetUserName();
            //// string dirEntry = obj.GetDirectoryEntry();
            //memberships = obj.VerifyGroupMemberships("LDAP://192.168.100.3/ou=Cooper Network Users,dc=coopersurgical1,dc=com", "coopservice", "^CSIServ2016!", userID);

            if (!Page.IsPostBack)

            {
                CategoryReportingChild li = new CategoryReportingChild();

                DataTable table = new DataTable();



                ddlCategoryName.DataSource = li.CategoryNameList().Tables[0];
                ddlCategoryName.DataTextField = "CategoryName";
                ddlCategoryName.DataBind();

                ddlCommissionCategoryName.DataSource = li.CommissionCategoryNameList().Tables[0];
                ddlCommissionCategoryName.DataTextField = "CommissionCategoryName";
                ddlCommissionCategoryName.DataBind();

                newCommissionCategoryName.DataSource = li.CommissionCategoryNameList().Tables[0];
                newCommissionCategoryName.DataTextField = "CommissionCategoryName";
                newCommissionCategoryName.DataBind();


                BindGridView();
            }
        }

        #region EventHandling

        protected void Category_RowEditing(object sender, GridViewEditEventArgs e)
        {
            CategoryGridView.EditIndex = e.NewEditIndex;
            int index = e.NewEditIndex;
            GridViewRow row = CategoryGridView.Rows[e.NewEditIndex];

            BindGridView();
        }

        protected void Category_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            CategoryGridView.EditIndex = -1;
            BindGridView();
        }


        protected void Category_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            if (Page.IsValid)
            {
                CategoryReportingChild li = new CategoryReportingChild();
                GridViewRow row = CategoryGridView.Rows[e.RowIndex];
                string display = "";
                bool isFormFilled = true;
                try
                {
                    li.CategoryID = Convert.ToInt32(CategoryGridView.DataKeys[e.RowIndex].Values[0]);

                    if (((TextBox)row.FindControl("CategorySequence")).Text != string.Empty)
                    {
                        li.CategorySequence = Convert.ToInt32(((TextBox)row.FindControl("CategorySequence")).Text);
                    }
                    else
                    {
                        display = "Category Sequence Code cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (((TextBox)row.FindControl("CategoryCode")).Text != string.Empty)
                    {
                        li.CategoryCode = Convert.ToInt32(((TextBox)row.FindControl("CategoryCode")).Text);
                    }
                    else
                    {
                        display = "Category Code cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (((TextBox)row.FindControl("CategoryName")).Text != string.Empty)
                    {
                        li.CategoryName = Convert.ToString(((TextBox)row.FindControl("CategoryName")).Text);
                    }
                    else
                    {
                        display = "Category Name cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (((TextBox)row.FindControl("CommissionCategoryCode")).Text != string.Empty)
                    {
                        li.CommissionCategoryCode = Convert.ToInt32(((TextBox)row.FindControl("CommissionCategoryCode")).Text);
                    }
                    else
                    {
                        display = "Commission Category Code cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (((DropDownList)row.FindControl("CommissionCategoryName")).SelectedValue != "Select One")
                    {
                        li.CommissionCategoryName = ((DropDownList)row.FindControl("CommissionCategoryName")).SelectedValue;
                    }
                    else
                    {
                        display = "Select Commission Category Name from dropdown";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (!String.IsNullOrEmpty(Convert.ToString((Request.Form[row.FindControl("EffectiveDate").UniqueID]))))
                    {
                        li.EffectiveDate = Convert.ToDateTime((Request.Form[row.FindControl("EffectiveDate").UniqueID]));
                    }
                    else
                    {
                        display = "Effective Date cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (!String.IsNullOrEmpty(Convert.ToString((Request.Form[row.FindControl("ExpirationDate").UniqueID]))))
                    {
                        li.ExpirationDate = Convert.ToDateTime((Request.Form[row.FindControl("ExpirationDate").UniqueID]));
                    }
                    else
                    {
                        display = "Expiration Date cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (li.ExpirationDate < li.EffectiveDate)
                    {
                        display = "Expiration Date must be after Effective date";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (isFormFilled)
                    {
                        DataSet result = li.UpdateSKPickingBoard(li, memberships);

                        string res = Convert.ToString(result.Tables[0].Rows[0].ItemArray[0]);

                        if (res.Equals("Duplicate CategoryCode"))
                        {
                            display = "Category Code already exists in the database";
                            ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        }
                        else if (res.Equals("Duplicate CategoryName"))
                        {
                            display = "Category Name already exists in the database";
                            ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        }
                        else if (res.Equals("Duplicate CommissionCategoryCode"))
                        {
                            display = "Commission Category Code already exists in the database";
                            ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        }
                        else if (res.Equals("Success"))
                        {
                        }
                    }
                    //if (memberships > 0)
                    //{
                    //    li.UpdateSKPickingBoard(li, memberships);
                    //}
                    //else
                    //{
                    //    string display = "You must be a member of SK_Picking _Operations or SK_Picking_Warehouse groups to make changes.";
                    //    ClientScript.RegisterStartupScript(this.GetType(), "yourMessage", "alert('" + display + "');", true);
                    //}

                }
                catch (Exception ex)
                {
                    throw ex;
                }

                CategoryGridView.EditIndex = -1;
                BindGridView();
            }
        }

        protected void Category_SortData(object sender, GridViewSortEventArgs e)
        {
            if (CategoryGridView.EditIndex >= -1)
            {
                CategoryGridView.EditIndex = -1;
            }
            BindGridView();
            SortGrid(sender, e);
        }

        protected void Category_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow && CategoryGridView.EditIndex == e.Row.RowIndex)
            {
                CategoryReportingChild li = new CategoryReportingChild();

                //Find the DropDownList in the Row
                DropDownList ddlCommissionCategoryNameList = (e.Row.FindControl("CommissionCategoryName") as DropDownList);
                ddlCommissionCategoryNameList.DataSource = li.CommissionCategoryNameList().Tables[0];
                ddlCommissionCategoryNameList.DataTextField = "CommissionCategoryName";
                ddlCommissionCategoryNameList.DataValueField = "CommissionCategoryName";
                ddlCommissionCategoryNameList.DataBind();

                //Add Default Item in the DropDownList
                ddlCommissionCategoryNameList.Items.Insert(0, new ListItem("Select One"));

                //Select the Country of Customer in DropDownList
                string commissionCategoryNames = (e.Row.FindControl("lblCommissionCategoryName") as Label).Text;
                ddlCommissionCategoryNameList.Items.FindByValue(commissionCategoryNames).Selected = true;


            }
        }

        protected void Category_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            if (CategoryGridView.EditIndex >= -1)
            {
                CategoryGridView.EditIndex = -1;
            }
            BindGridView();
            PageGrid(sender, e);
        }

        protected void chkBoxResetCheckedChanged(object sender, EventArgs e)
        {
            if (CategoryGridView.EditIndex >= -1)
            {
                CategoryGridView.EditIndex = -1;
            }
            ddlCategoryName.SelectedIndex = 0;
            ddlCommissionCategoryName.SelectedIndex = 0;
            BindGridView();
        }

        #endregion
        protected void btnSaveNewCategory_Click(object sender, EventArgs e)
        {
            bool isFormFilled = true;
            string display = "";
            CategoryReportingChild li = new CategoryReportingChild();
            string categorySequence = newCategorySequence.Text;
            string categoryCode = newCategoryCode.Text;
            string categoryName = newCategoryName.Text;
            string commissionCategoryCode = newCommissionCategoryCode.Text;
            string commissionCategoryName = newCommissionCategoryName.SelectedValue.ToString();
            string effectiveDate = Request.Form[newEffectiveDate.UniqueID];


            if (String.IsNullOrEmpty(effectiveDate) || String.IsNullOrEmpty(categorySequence)
                || String.IsNullOrEmpty(categoryCode) || String.IsNullOrEmpty(categoryName)
                || String.IsNullOrEmpty(commissionCategoryCode) || String.IsNullOrEmpty(commissionCategoryName))
            {
                display = "Please select all the mandatory fields ";
                ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                isFormFilled = false;
            }


            if (isFormFilled)
            {
                DataSet result = li.AddNewCategory(categorySequence, categoryCode, categoryName, commissionCategoryCode, commissionCategoryName, effectiveDate);

                string res = Convert.ToString(result.Tables[0].Rows[0].ItemArray[0]);

                if (res.Equals("Duplicate CategoryCode"))
                {
                    display = "Category Code already exists in the database";
                    ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                    isFormFilled = false;
                }
                else if (res.Equals("Duplicate CategoryName"))
                {
                    display = "Category Name already exists in the database";
                    ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                    isFormFilled = false;
                }
                else if (res.Equals("Duplicate CommissionCategoryCode"))
                {
                    display = "Commission Category Code already exists in the database";
                    ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                    isFormFilled = false;
                }
                else if (res.Equals("Success"))
                {
                    display = "A new Category is successfully added in the database";
                    ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                    isFormFilled = true;
                }
                if (isFormFilled)
                {
                    newCategorySequence.Text = "";
                    newCategoryCode.Text = "";
                    newCategoryName.Text = "";
                    newCommissionCategoryCode.Text = "";
                    newCommissionCategoryName.SelectedIndex = 0;
                    newEffectiveDate.Text = "";
                    BindGridView();
                }
            }
        }

        protected void btnAddNewCategory_Click(object sender, EventArgs e)
        {
            ModalPopupExtender1.Show();
        }

        protected void ddl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (CategoryGridView.EditIndex >= -1)
            {
                CategoryGridView.EditIndex = -1;
            }
            BindGridView();
        }

        private void BindGridView()
        {
            int count;
            CategoryReportingChild obj = new CategoryReportingChild();

            string categoryName = ddlCategoryName.SelectedValue.ToString();
            string commissionCategoryName = ddlCommissionCategoryName.SelectedValue.ToString();
            DataSet ds = obj.GetSKPickingBoard2(categoryName, commissionCategoryName);
            CategoryGridView.DataSource = ds.Tables[0];
            CategoryGridView.DataBind();
            count = ds.Tables[0].Rows.Count;
            if (count > 1)
            {
                lblRecordCount.Text = "Record Count: " + count;
            }
            else
            {
                lblRecordCount.Text = "Record Count: " + count;
            }

        }

        protected void btnExportToExcel_Click(object sender, EventArgs e)
        {
            CategoryReportingChild obj = new CategoryReportingChild();
            DataSet ds = obj.GetSKPickingBoard2("Select One", "Select One");

            WorkbookEngine we = new WorkbookEngine();
            we.ExportDataSetToExcel(ds.Tables[0], "Sales Reporting");
        }
    }
}