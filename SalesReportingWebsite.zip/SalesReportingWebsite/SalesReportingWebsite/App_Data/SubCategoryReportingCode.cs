﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for LowInventory
/// </summary>
public abstract class SubCategoryReportingCode
{
    public SubCategoryReportingCode()
    {

        _SubCategoryID = 0;
        _SubCategoryCode = 0;
        _SubCategoryName = String.Empty;
        _CategoryID = 0;
        _CategoryName = String.Empty;
        _CommissionSubCategoryCode = 0;
        _CommissionSubCategoryName = String.Empty;
        _CommissionCategoryID = 0;
        _CommissionCategoryName = String.Empty;
        _SubCategorySequence = 0;
        _EffectiveDate = DateTime.MinValue;
        _ExpirationDate = DateTime.MinValue;

    }

    private int _SubCategoryID;
    private int _SubCategoryCode;
    private string _SubCategoryName;
    private int _CategoryID;
    private string _CategoryName;
    private int _CommissionSubCategoryCode;
    private string _CommissionSubCategoryName;
    private int _CommissionCategoryID;
    private string _CommissionCategoryName;
    private int _SubCategorySequence;
    private DateTime _EffectiveDate;
    private DateTime _ExpirationDate;


    public int SubCategoryID
    {
        get { return _SubCategoryID; }
        set { _SubCategoryID = value; }
    }
    public int SubCategoryCode
    {
        get { return _SubCategoryCode; }
        set { _SubCategoryCode = value; }
    }

    public string SubCategoryName
    {
        get { return _SubCategoryName; }
        set { _SubCategoryName = value; }
    }
    public int CategoryID
    {
        get { return _CategoryID; }
        set { _CategoryID = value; }
    }


    public string CategoryName
    {
        get { return _CategoryName; }
        set { _CategoryName = value; }
    }

    public int CommissionSubCategoryCode
    {
        get { return _CommissionSubCategoryCode; }
        set { _CommissionSubCategoryCode = value; }
    }
    public string CommissionSubCategoryName
    {
        get { return _CommissionSubCategoryName; }
        set { _CommissionSubCategoryName = value; }
    }

    public int CommissionCategoryID
    {
        get { return _CommissionCategoryID; }
        set { _CommissionCategoryID = value; }
    }


    public string CommissionCategoryName
    {
        get { return _CommissionCategoryName; }
        set { _CommissionCategoryName = value; }
    }

    public int SubCategorySequence
    {
        get { return _SubCategorySequence; }
        set { _SubCategorySequence = value; }
    }
    public DateTime EffectiveDate
    {
        get { return _EffectiveDate; }
        set { _EffectiveDate = value; }
    }

    public DateTime ExpirationDate
    {
        get { return _ExpirationDate; }
        set { _ExpirationDate = value; }
    }

    

    public DataSet GetSKPickingBoard2(string categoryName ,string subCategoryName, string commissionCategoryName, string commissionSubCategoryName)// string fromDate, string toDate, string period, string fromQuantity, string toQuantity, string fromAmount, string toAmount, string adjustmentType, string countryName, string subBusinessUnitName, string companyName, string subSegmentName, string accountSubTypeName, string subCategoryName, string rblMeasurementSystemText)
    {
        DataSet ds = new DataSet();

        using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString()))
            try
            {
                using (SqlCommand cmd = new SqlCommand("dbo.Web_SR_GetSubCategoryRecords", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    if (categoryName == "Select One" || String.IsNullOrEmpty(categoryName))
                    {
                        cmd.Parameters.AddWithValue("CategoryName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("CategoryName", categoryName);
                    }

                    if (subCategoryName == "Select One" || String.IsNullOrEmpty(subCategoryName))
                    {
                        cmd.Parameters.AddWithValue("SubCategoryName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("SubCategoryName", subCategoryName);
                    }

                    if (commissionCategoryName == "Select One" || String.IsNullOrEmpty(commissionCategoryName))
                    {
                        cmd.Parameters.AddWithValue("CommissionCategoryName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("commissionCategoryName", commissionCategoryName);
                    }

                    if (commissionSubCategoryName == "Select One" || String.IsNullOrEmpty(commissionSubCategoryName))
                    {
                        cmd.Parameters.AddWithValue("CommissionSubCategoryName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("commissionSubCategoryName", commissionSubCategoryName);
                    }


                    connection.Open();
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(ds);
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        return ds;
    }


    public DataSet UpdateSKPickingBoard(SubCategoryReportingChild li, int memberships)
    {
        DataSet ds = new DataSet();
        SqlConnection sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString());
        SqlCommand sqlCmd = new SqlCommand("dbo.Web_SR_UpdateSubCategorys", sqlConn);
        sqlCmd.CommandType = CommandType.StoredProcedure;

        //   if (memberships == 1 || memberships == 2)
        //   {

        sqlCmd.Parameters.Add("@SubCategoryID", SqlDbType.Int).Value = li.SubCategoryID;
        sqlCmd.Parameters.Add("@SubCategorySequence", SqlDbType.Int).Value = li.SubCategorySequence;
        sqlCmd.Parameters.Add("@SubCategoryCode", SqlDbType.Int).Value = li.SubCategoryCode;
        sqlCmd.Parameters.Add("@SubCategoryName", SqlDbType.NVarChar).Value = li.SubCategoryName;
        sqlCmd.Parameters.Add("@CategoryName", SqlDbType.NVarChar).Value = li.CategoryName;
        sqlCmd.Parameters.Add("@CommissionSubCategoryCode", SqlDbType.Int).Value = li.CommissionSubCategoryCode;
        sqlCmd.Parameters.Add("@CommissionSubCategoryName", SqlDbType.NVarChar).Value = li.CommissionSubCategoryName;
        sqlCmd.Parameters.Add("@CommissionCategoryName", SqlDbType.NVarChar).Value = li.CommissionCategoryName;
        sqlCmd.Parameters.Add("@EffectiveDate", SqlDbType.DateTime).Value = li.EffectiveDate;
        sqlCmd.Parameters.Add("@ExpirationDate", SqlDbType.DateTime).Value = li.ExpirationDate;
        
        
        if (String.IsNullOrEmpty(HttpContext.Current.User.Identity.Name))
        {
            sqlCmd.Parameters.Add("@UpdateUser", SqlDbType.VarChar).Value = "sysadmin";
        }
        else
        {
            sqlCmd.Parameters.Add("@UpdateUser", SqlDbType.VarChar).Value = HttpContext.Current.User.Identity.Name;
        }
        

        try
        {
            sqlConn.Open();
            using (SqlDataAdapter adapter = new SqlDataAdapter(sqlCmd))
            {
                adapter.Fill(ds);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return ds;
    }


    public DataSet AddNewSubCategory(string subCategorySequence, string subCategoryCode, string subCategoryName, string categoryName, string commissionSubCategoryCode, string commissionSubCategoryName, string commissionCategoryName, string effectiveDate)//string date, string period, string quantity, string amountLCY, string amountSpotUSD, string amountAverageUSD, string costLCY, string costSpotUSD, string costAverageUSD, string comment, string adjustmentType, string countryName, string subBusinessUnitName, string companyName, string subSegmentName, string accountSubTypeName, string subCategoryName, string currencyName)
    {
        DataSet ds = new DataSet();
        using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString()))
            try
            {
                using (SqlCommand cmd = new SqlCommand("dbo.Web_SR_AddNewSubCategory", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("EffectiveDate", Convert.ToDateTime(effectiveDate));
                    cmd.Parameters.AddWithValue("SubCategorySequence", subCategorySequence);
                    cmd.Parameters.AddWithValue("SubCategoryCode", subCategoryCode);
                    cmd.Parameters.AddWithValue("SubCategoryName", subCategoryName);
                    cmd.Parameters.AddWithValue("CategoryName", categoryName);
                    cmd.Parameters.AddWithValue("CommissionSubCategoryCode", commissionSubCategoryCode);
                    cmd.Parameters.AddWithValue("CommissionSubCategoryName", commissionSubCategoryName);
                    cmd.Parameters.AddWithValue("CommissionCategoryName", commissionCategoryName);


                    connection.Open();
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(ds);
                    }
                }            

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        return ds;
    }


    }
