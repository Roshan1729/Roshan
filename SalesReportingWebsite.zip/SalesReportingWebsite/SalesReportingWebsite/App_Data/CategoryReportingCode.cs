﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for LowInventory
/// </summary>
public abstract class CategoryReportingCode
{
    public CategoryReportingCode()
    {

        _CategoryID = 0;
        _CategoryCode = 0;
        _CategoryName = String.Empty;
        _CommissionCategoryCode = 0;
        _CommissionCategoryName = String.Empty;
        _CategorySequence = 0;
        _EffectiveDate = DateTime.MinValue;
        _ExpirationDate = DateTime.MinValue;

    }

    private int _CategoryID;
    private int _CategoryCode;
    private string _CategoryName;
    private int _CommissionCategoryCode;
    private string _CommissionCategoryName;
    private int _CategorySequence;
    private DateTime _EffectiveDate;
    private DateTime _ExpirationDate;
    
    public int CategoryID
    {
        get { return _CategoryID; }
        set { _CategoryID = value; }
    }


    public int CategoryCode
    {
        get { return _CategoryCode; }
        set { _CategoryCode = value; }
    }

    public string CategoryName
    {
        get { return _CategoryName; }
        set { _CategoryName = value; }
    }

    public int CommissionCategoryCode
    {
        get { return _CommissionCategoryCode; }
        set { _CommissionCategoryCode = value; }
    }
    public string CommissionCategoryName
    {
        get { return _CommissionCategoryName; }
        set { _CommissionCategoryName = value; }
    }

    public int CategorySequence
    {
        get { return _CategorySequence; }
        set { _CategorySequence = value; }
    }
    public DateTime EffectiveDate
    {
        get { return _EffectiveDate; }
        set { _EffectiveDate = value; }
    }

    public DateTime ExpirationDate
    {
        get { return _ExpirationDate; }
        set { _ExpirationDate = value; }
    }

    

    public DataSet GetSKPickingBoard2(string categoryName ,string commissionCategoryName)// string fromDate, string toDate, string period, string fromQuantity, string toQuantity, string fromAmount, string toAmount, string adjustmentType, string countryName, string subBusinessUnitName, string companyName, string subSegmentName, string accountSubTypeName, string subCategoryName, string rblMeasurementSystemText)
    {
        DataSet ds = new DataSet();

        using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString()))
            try
            {
                using (SqlCommand cmd = new SqlCommand("dbo.Web_SR_GetCategoryRecords", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    if (categoryName == "Select One" || String.IsNullOrEmpty(categoryName))
                    {
                        cmd.Parameters.AddWithValue("CategoryName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("CategoryName", categoryName);
                    }


                    if (commissionCategoryName == "Select One" || String.IsNullOrEmpty(commissionCategoryName))
                    {
                        cmd.Parameters.AddWithValue("CommissionCategoryName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("commissionCategoryName", commissionCategoryName);
                    }



                    connection.Open();
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(ds);
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        return ds;
    }


    public DataSet UpdateSKPickingBoard(CategoryReportingChild li, int memberships)
    {
        DataSet ds = new DataSet();
        SqlConnection sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString());
        SqlCommand sqlCmd = new SqlCommand("dbo.Web_SR_UpdateCategorys", sqlConn);
        sqlCmd.CommandType = CommandType.StoredProcedure;

        //   if (memberships == 1 || memberships == 2)
        //   {

        sqlCmd.Parameters.Add("@CategoryID", SqlDbType.Int).Value = li.CategoryID;
        sqlCmd.Parameters.Add("@CategorySequence", SqlDbType.Int).Value = li.CategorySequence;
        sqlCmd.Parameters.Add("@CategoryCode", SqlDbType.Int).Value = li.CategoryCode;
        sqlCmd.Parameters.Add("@CategoryName", SqlDbType.NVarChar).Value = li.CategoryName;
        sqlCmd.Parameters.Add("@CommissionCategoryCode", SqlDbType.Int).Value = li.CommissionCategoryCode;
        sqlCmd.Parameters.Add("@CommissionCategoryName", SqlDbType.NVarChar).Value = li.CommissionCategoryName;
        sqlCmd.Parameters.Add("@EffectiveDate", SqlDbType.DateTime).Value = li.EffectiveDate;
        sqlCmd.Parameters.Add("@ExpirationDate", SqlDbType.DateTime).Value = li.ExpirationDate;
        
        
        if (String.IsNullOrEmpty(HttpContext.Current.User.Identity.Name))
        {
            sqlCmd.Parameters.Add("@UpdateUser", SqlDbType.VarChar).Value = "sysadmin";
        }
        else
        {
            sqlCmd.Parameters.Add("@UpdateUser", SqlDbType.VarChar).Value = HttpContext.Current.User.Identity.Name;
        }
        

        try
        {
            sqlConn.Open();
            using (SqlDataAdapter adapter = new SqlDataAdapter(sqlCmd))
            {
                adapter.Fill(ds);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return ds;
    }


    public DataSet AddNewCategory(string categorySequence, string categoryCode, string categoryName, string commissionCategoryCode, string commissionCategoryName, string effectiveDate)//string date, string period, string quantity, string amountLCY, string amountSpotUSD, string amountAverageUSD, string costLCY, string costSpotUSD, string costAverageUSD, string comment, string adjustmentType, string countryName, string subBusinessUnitName, string companyName, string subSegmentName, string accountSubTypeName, string subCategoryName, string currencyName)
    {
        DataSet ds = new DataSet();
        using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString()))
            try
            {
                using (SqlCommand cmd = new SqlCommand("dbo.Web_SR_AddNewCategory", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("EffectiveDate", Convert.ToDateTime(effectiveDate));
                    cmd.Parameters.AddWithValue("CategorySequence",Convert.ToInt32(categorySequence));
                    cmd.Parameters.AddWithValue("CategoryCode", Convert.ToInt32(categoryCode));
                    cmd.Parameters.AddWithValue("CategoryName", categoryName);
                    cmd.Parameters.AddWithValue("CommissionCategoryCode", Convert.ToInt32(commissionCategoryCode));
                    cmd.Parameters.AddWithValue("CommissionCategoryName", commissionCategoryName);


                    connection.Open();
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(ds);
                    }
                }            

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        return ds;
    }


    }
