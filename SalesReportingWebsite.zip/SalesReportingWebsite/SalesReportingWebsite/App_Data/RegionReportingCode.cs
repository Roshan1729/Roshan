﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for LowInventory
/// </summary>
public abstract class RegionReportingCode
{
    public RegionReportingCode()
    {

        _RegionID = 0;
        _RegionCode = 0;
        _RegionName = String.Empty;
        _RegionManagerID = 0;
        _RegionManagerName = String.Empty;
        _SubBusinessUnitID = 0;
        _SubBusinessUnitName = String.Empty;
        _CompanyID = 0;
        _CompanyName = String.Empty;
        _EffectiveDate = DateTime.MinValue;
        _ExpirationDate = DateTime.MinValue;

    }

    private int _RegionID;
    private int _RegionCode;
    private string _RegionName;
    private int _RegionManagerID;
    public string _RegionManagerName;
    private int _SubBusinessUnitID;
    public string _SubBusinessUnitName;
    private int _CompanyID;
    private string _CompanyName;
    private DateTime _EffectiveDate;
    private DateTime _ExpirationDate;
    
    public int RegionID
    {
        get { return _RegionID; }
        set { _RegionID = value; }
    }


    public int RegionCode
    {
        get { return _RegionCode; }
        set { _RegionCode = value; }
    }

    public string RegionName
    {
        get { return _RegionName; }
        set { _RegionName = value; }
    }

    public int RegionManagerID
    {
        get { return _RegionManagerID; }
        set { _RegionManagerID = value; }
    }

    public string RegionManagerName
    {
        get { return _RegionManagerName; }
        set { _RegionManagerName = value; }
    }
    public int SubBusinessUnitID
    {
        get { return _SubBusinessUnitID; }
        set { _SubBusinessUnitID = value; }
    }

    public string SubBusinessUnitName
    {
        get { return _SubBusinessUnitName; }
        set { _SubBusinessUnitName = value; }
    }

    public int CompanyID
    {
        get { return _CompanyID; }
        set { _CompanyID = value; }
    }

    public string CompanyName
    {
        get { return _CompanyName; }
        set { _CompanyName = value; }
    }
    public DateTime EffectiveDate
    {
        get { return _EffectiveDate; }
        set { _EffectiveDate = value; }
    }

    public DateTime ExpirationDate
    {
        get { return _ExpirationDate; }
        set { _ExpirationDate = value; }
    }

    

    public DataSet GetSKPickingBoard2(string companyName,string regionName,string subBusinessUnitName, string regionManagerName)// string fromDate, string toDate, string period, string fromQuantity, string toQuantity, string fromAmount, string toAmount, string adjustmentType, string countryName, string subBusinessUnitName, string companyName, string subSegmentName, string accountSubTypeName, string subCategoryName, string rblMeasurementSystemText)
    {
        DataSet ds = new DataSet();

        using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString()))
            try
            {
                using (SqlCommand cmd = new SqlCommand("dbo.Web_SR_GetRegionRecords", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    if (companyName == "Select One" || String.IsNullOrEmpty(companyName))
                    {
                        cmd.Parameters.AddWithValue("CompanyName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("CompanyName", companyName);
                    }

                    if (regionName == "Select One" || String.IsNullOrEmpty(regionName))
                    {
                        cmd.Parameters.AddWithValue("RegionName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("RegionName", regionName);
                    }

                    if (subBusinessUnitName == "Select One" || String.IsNullOrEmpty(subBusinessUnitName))
                    {
                        cmd.Parameters.AddWithValue("SubBusinessUnitName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("SubBusinessUnitName", subBusinessUnitName);
                    }

                    if (regionManagerName == "Select One" || String.IsNullOrEmpty(regionManagerName))
                    {
                        cmd.Parameters.AddWithValue("RegionManagerName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("RegionManagerName", regionManagerName);
                    }


                    connection.Open();
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(ds);
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        return ds;
    }


    public DataSet UpdateSKPickingBoard(RegionReportingChild li, int memberships)
    {
        DataSet ds = new DataSet();
        SqlConnection sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString());
        SqlCommand sqlCmd = new SqlCommand("dbo.Web_SR_UpdateRegions", sqlConn);
        sqlCmd.CommandType = CommandType.StoredProcedure;

        //   if (memberships == 1 || memberships == 2)
        //   {

        sqlCmd.Parameters.Add("@RegionID", SqlDbType.Int).Value = li.RegionID;
        sqlCmd.Parameters.Add("@EffectiveDate", SqlDbType.DateTime).Value = li.EffectiveDate;
        sqlCmd.Parameters.Add("@ExpirationDate", SqlDbType.DateTime).Value = li.ExpirationDate;
        sqlCmd.Parameters.Add("@RegionCode", SqlDbType.NVarChar).Value = li.RegionCode;
        sqlCmd.Parameters.Add("@RegionName", SqlDbType.NVarChar).Value = li.RegionName;
        sqlCmd.Parameters.Add("@RegionManagerName", SqlDbType.NVarChar).Value = li.RegionManagerName;
        sqlCmd.Parameters.Add("@SubBusinessUnitName", SqlDbType.NVarChar).Value = li.SubBusinessUnitName;

        //if (li.SegmentName == string.Empty)
        //{
        //    sqlCmd.Parameters.Add("@SegmentName", SqlDbType.VarChar).Value = DBNull.Value;
        //}
        //else
        //{
        //    sqlCmd.Parameters.Add("@SegmentName", SqlDbType.VarChar).Value = li.SegmentName;
        //}
        if (String.IsNullOrEmpty(HttpContext.Current.User.Identity.Name))
        {
            sqlCmd.Parameters.Add("@UpdateUser", SqlDbType.VarChar).Value = "sysadmin";
        }
        else
        {
            sqlCmd.Parameters.Add("@UpdateUser", SqlDbType.VarChar).Value = HttpContext.Current.User.Identity.Name;
        }
        //  }

        try
        {
            sqlConn.Open();
            using (SqlDataAdapter adapter = new SqlDataAdapter(sqlCmd))
            {
                adapter.Fill(ds);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return ds;
    }
    
   
    public DataSet AddNewRegion(string regionCode, string regionName, string regionManagerName, string subBusinessUnitName, string companyName, string effectiveDate)//string date, string period, string quantity, string amountLCY, string amountSpotUSD, string amountAverageUSD, string costLCY, string costSpotUSD, string costAverageUSD, string comment, string adjustmentType, string countryName, string subBusinessUnitName, string companyName, string subSegmentName, string accountSubTypeName, string subCategoryName, string currencyName)
    {
        DataSet ds = new DataSet();
        using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString()))
            try
            {
                using (SqlCommand cmd = new SqlCommand("dbo.Web_SR_AddNewCompany", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("EffectiveDate", Convert.ToDateTime(effectiveDate));
                    cmd.Parameters.AddWithValue("RegionCode", regionCode);
                    cmd.Parameters.AddWithValue("RegionName", regionName);
                    cmd.Parameters.AddWithValue("RegionManagerName", regionManagerName);
                    cmd.Parameters.AddWithValue("SubBusinessUnitName", subBusinessUnitName);
                    cmd.Parameters.AddWithValue("CompanyName", companyName);

                    connection.Open();
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(ds);
                    }
                }            

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        return ds;
    }


    }
