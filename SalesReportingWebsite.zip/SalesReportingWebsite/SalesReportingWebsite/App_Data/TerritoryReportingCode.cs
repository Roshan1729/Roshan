﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for LowInventory
/// </summary>
public abstract class TerritoryReportingCode
{
    public TerritoryReportingCode()
    {

        _TerritoryID = 0;
        _TerritoryCode = 0;
        _TerritoryName = String.Empty;
        _TerritoryManagerID = 0;
        _TerritoryManagerName = String.Empty;
        _RegionID = 0;
        _RegionName = String.Empty;
        _CompanyID = 0;
        _CompanyName = String.Empty;
        _EffectiveDate = DateTime.MinValue;
        _ExpirationDate = DateTime.MinValue;

    }

    private int _TerritoryID;
    private int _TerritoryCode;
    private string _TerritoryName;
    private int _TerritoryManagerID;
    private string _TerritoryManagerName;
    private int _RegionID;
    private string _RegionName;
    private int _CompanyID;
    private string _CompanyName;
    private DateTime _EffectiveDate;
    private DateTime _ExpirationDate;


    public int TerritoryID
    {
        get { return _TerritoryID; }
        set { _TerritoryID = value; }
    }
    public int TerritoryCode
    {
        get { return _TerritoryCode; }
        set { _TerritoryCode = value; }
    }

    public string TerritoryName
    {
        get { return _TerritoryName; }
        set { _TerritoryName = value; }
    }
    public int TerritoryManagerID
    {
        get { return _TerritoryManagerID; }
        set { _TerritoryManagerID = value; }
    }

    public string TerritoryManagerName
    {
        get { return _TerritoryManagerName; }
        set { _TerritoryManagerName = value; }
    }
    public int RegionID
    {
        get { return _RegionID; }
        set { _RegionID = value; }
    }
    public string RegionName
    {
        get { return _RegionName; }
        set { _RegionName = value; }
    }

    public int CompanyID
    {
        get { return _CompanyID; }
        set { _CompanyID = value; }
    }


    public string CompanyName
    {
        get { return _CompanyName; }
        set { _CompanyName = value; }
    }

    public DateTime EffectiveDate
    {
        get { return _EffectiveDate; }
        set { _EffectiveDate = value; }
    }

    public DateTime ExpirationDate
    {
        get { return _ExpirationDate; }
        set { _ExpirationDate = value; }
    }

    

    public DataSet GetSKPickingBoard2(string territoryName ,string territoryManagername, string regionName, string companyName)// string fromDate, string toDate, string period, string fromQuantity, string toQuantity, string fromAmount, string toAmount, string adjustmentType, string countryName, string subBusinessUnitName, string companyName, string subSegmentName, string accountSubTypeName, string subCategoryName, string rblMeasurementSystemText)
    {
        DataSet ds = new DataSet();

        using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString()))
            try
            {
                using (SqlCommand cmd = new SqlCommand("dbo.Web_SR_GetTerritoryRecords", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    if (territoryName == "Select One" || String.IsNullOrEmpty(territoryName))
                    {
                        cmd.Parameters.AddWithValue("TerritoryName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("TerritoryName", territoryName);
                    }

                    if (territoryManagername == "Select One" || String.IsNullOrEmpty(territoryManagername))
                    {
                        cmd.Parameters.AddWithValue("TerritoryManagerName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("TerritoryManagerName", territoryManagername);
                    }

                    if (regionName == "Select One" || String.IsNullOrEmpty(regionName))
                    {
                        cmd.Parameters.AddWithValue("RegionName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("RegionName", regionName);
                    }

                    if (companyName == "Select One" || String.IsNullOrEmpty(companyName))
                    {
                        cmd.Parameters.AddWithValue("CompanyName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("CompanyName", companyName);
                    }


                    connection.Open();
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(ds);
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        return ds;
    }


    public DataSet UpdateSKPickingBoard(TerritoryReportingChild li, int memberships)
    {
        DataSet ds = new DataSet();
        SqlConnection sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString());
        SqlCommand sqlCmd = new SqlCommand("dbo.Web_SR_UpdateTerritorys", sqlConn);
        sqlCmd.CommandType = CommandType.StoredProcedure;

        //   if (memberships == 1 || memberships == 2)
        //   {

        sqlCmd.Parameters.Add("@TerritoryID", SqlDbType.Int).Value = li.TerritoryID;
        sqlCmd.Parameters.Add("@TerritoryCode", SqlDbType.Int).Value = li.TerritoryCode;
        sqlCmd.Parameters.Add("@TerritoryName", SqlDbType.NVarChar).Value = li.TerritoryName;
        sqlCmd.Parameters.Add("@TerritoryManagerName", SqlDbType.Int).Value = li.TerritoryManagerName;
        sqlCmd.Parameters.Add("@RegionName", SqlDbType.NVarChar).Value = li.RegionName;
        sqlCmd.Parameters.Add("@CompanyName", SqlDbType.NVarChar).Value = li.CompanyName;
        sqlCmd.Parameters.Add("@EffectiveDate", SqlDbType.DateTime).Value = li.EffectiveDate;
        sqlCmd.Parameters.Add("@ExpirationDate", SqlDbType.DateTime).Value = li.ExpirationDate;
        
        
        if (String.IsNullOrEmpty(HttpContext.Current.User.Identity.Name))
        {
            sqlCmd.Parameters.Add("@UpdateUser", SqlDbType.VarChar).Value = "sysadmin";
        }
        else
        {
            sqlCmd.Parameters.Add("@UpdateUser", SqlDbType.VarChar).Value = HttpContext.Current.User.Identity.Name;
        }
        

        try
        {
            sqlConn.Open();
            using (SqlDataAdapter adapter = new SqlDataAdapter(sqlCmd))
            {
                adapter.Fill(ds);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return ds;
    }


    public DataSet AddNewTerritory(string territoryCode, string territoryName, string territoryManagerName, string regionName, string companyName, string effectiveDate)//string date, string period, string quantity, string amountLCY, string amountSpotUSD, string amountAverageUSD, string costLCY, string costSpotUSD, string costAverageUSD, string comment, string adjustmentType, string countryName, string subBusinessUnitName, string companyName, string subSegmentName, string accountSubTypeName, string subCategoryName, string currencyName)
    {
        DataSet ds = new DataSet();
        using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString()))
            try
            {
                using (SqlCommand cmd = new SqlCommand("dbo.Web_SR_AddNewTerritory", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("EffectiveDate", Convert.ToDateTime(effectiveDate));
                    cmd.Parameters.AddWithValue("TerritoryCode", territoryCode);
                    cmd.Parameters.AddWithValue("TerritoryName", territoryName);
                    cmd.Parameters.AddWithValue("TerritoryManagerName", territoryManagerName);
                    cmd.Parameters.AddWithValue("RegionName", regionName);
                    cmd.Parameters.AddWithValue("CompanyName", companyName);
                    


                    connection.Open();
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(ds);
                    }
                }            

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        return ds;
    }


    }
