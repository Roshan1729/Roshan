﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for LowInventory
/// </summary>
public abstract class ProductReportingCode
{
    public ProductReportingCode()
    {

        _ProductID = 0;
        _ProductCode = 0;
        _ProductName = String.Empty;
        _SubCategoryName = String.Empty;
        _SubCategoryID = 0;
        _CommissionSubCategoryName = String.Empty;
        _CommissionSubCategoryID = 0;
        _CompanyName = String.Empty;
        _CompanyID = 0;
        _EffectiveDate = DateTime.MinValue;
        _ExpirationDate = DateTime.MinValue;

    }

    private int _ProductID;
    private int _ProductCode;
    private string _ProductName;
    private string _SubCategoryName;
    private int _SubCategoryID;
    public string _CommissionSubCategoryName;
    private int _CommissionSubCategoryID;
    public string _CompanyName;
    private int _CompanyID;
    private DateTime _EffectiveDate;
    private DateTime _ExpirationDate;
    
    public int ProductID
    {
        get { return _ProductID; }
        set { _ProductID = value; }
    }

    public int ProductCode
    {
        get { return _ProductCode; }
        set { _ProductCode = value; }
    }
    public string ProductName
    {
        get { return _ProductName; }
        set { _ProductName = value; }
    }

    public string SubCategoryName
    {
        get { return _SubCategoryName; }
        set { _SubCategoryName = value; }
    }

    public int SubCategoryID
    {
        get { return _SubCategoryID; }
        set { _SubCategoryID = value; }
    }
    public string CommissionSubCategoryName
    {
        get { return _CommissionSubCategoryName; }
        set { _CommissionSubCategoryName = value; }
    }
    public int CommissionSubCategoryID
    {
        get { return _CommissionSubCategoryID; }
        set { _CommissionSubCategoryID = value; }
    }


    public string CompanyName
    {
        get { return _CompanyName; }
        set { _CompanyName = value; }
    }
    public int CompanyID
    {
        get { return _CompanyID; }
        set { _CompanyID = value; }
    }


    public DateTime EffectiveDate
    {
        get { return _EffectiveDate; }
        set { _EffectiveDate = value; }
    }

    public DateTime ExpirationDate
    {
        get { return _ExpirationDate; }
        set { _ExpirationDate = value; }
    }

    

    public DataSet GetSKPickingBoard2(string productCode,string productName, string subCategoryName, string commissionSubCategoryName, string companyName)// string fromDate, string toDate, string period, string fromQuantity, string toQuantity, string fromAmount, string toAmount, string adjustmentType, string countryName, string subBusinessUnitName, string companyName, string subSegmentName, string accountSubTypeName, string subCategoryName, string rblMeasurementSystemText)
    {
        DataSet ds = new DataSet();

        using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString()))
            try
            {
                using (SqlCommand cmd = new SqlCommand("dbo.Web_SR_GetProductRecords", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    if (productCode == "Select One" || String.IsNullOrEmpty(productCode))
                    {
                        cmd.Parameters.AddWithValue("ProductCode", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("ProductCode", productCode);
                    }


                    if (productName == "Select One" || String.IsNullOrEmpty(productName))
                    {
                        cmd.Parameters.AddWithValue("ProductName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("ProductName", productName);
                    }

                    if (subCategoryName == "Select One" || String.IsNullOrEmpty(subCategoryName))
                    {
                        cmd.Parameters.AddWithValue("SubCategoryName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("SubCategoryName", subCategoryName);
                    }

                    if (commissionSubCategoryName == "Select One" || String.IsNullOrEmpty(commissionSubCategoryName))
                    {
                        cmd.Parameters.AddWithValue("CommissionSubCategoryName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("CommissionSubCategoryName", commissionSubCategoryName);
                    }

                    if (companyName == "Select One" || String.IsNullOrEmpty(companyName))
                    {
                        cmd.Parameters.AddWithValue("CompanyName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("CompanyName", companyName);
                    }


                    connection.Open();
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(ds);
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        return ds;
    }


    public DataSet UpdateSKPickingBoard(ProductReportingChild li, int memberships)
    {
        DataSet ds = new DataSet();
        SqlConnection sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString());
        SqlCommand sqlCmd = new SqlCommand("dbo.Web_SR_UpdateProduct", sqlConn);
        sqlCmd.CommandType = CommandType.StoredProcedure;

        //   if (memberships == 1 || memberships == 2)
        //   {

        sqlCmd.Parameters.Add("@ProductID", SqlDbType.Int).Value = li.ProductID;
        sqlCmd.Parameters.Add("@EffectiveDate", SqlDbType.DateTime).Value = li.EffectiveDate;
        sqlCmd.Parameters.Add("@ExpirationDate", SqlDbType.DateTime).Value = li.ExpirationDate;
        sqlCmd.Parameters.Add("@ProductCode", SqlDbType.Int).Value = li.ProductCode;
        sqlCmd.Parameters.Add("@ProductName", SqlDbType.NVarChar).Value = li.ProductName;
        sqlCmd.Parameters.Add("@SubCategoryName", SqlDbType.NVarChar).Value = li.SubCategoryName;
        sqlCmd.Parameters.Add("@CommissionSubCategoryName", SqlDbType.NVarChar).Value = li.CommissionSubCategoryName;
        sqlCmd.Parameters.Add("@CompanyName", SqlDbType.NVarChar).Value = li.CompanyName;

        if (String.IsNullOrEmpty(HttpContext.Current.User.Identity.Name))
        {
            sqlCmd.Parameters.Add("@UpdateUser", SqlDbType.VarChar).Value = "sysadmin";
        }
        else
        {
            sqlCmd.Parameters.Add("@UpdateUser", SqlDbType.VarChar).Value = HttpContext.Current.User.Identity.Name;
        }

        try
        {
            sqlConn.Open();
            using (SqlDataAdapter adapter = new SqlDataAdapter(sqlCmd))
            {
                adapter.Fill(ds);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return ds;
    }
    
   
    public DataSet AddNewProduct(string productCode, string productName, string subCategoryName, string commissionSubCategoryName, string companyName, string effectiveDate)//string date, string period, string quantity, string amountLCY, string amountSpotUSD, string amountAverageUSD, string costLCY, string costSpotUSD, string costAverageUSD, string comment, string adjustmentType, string countryName, string subBusinessUnitName, string companyName, string subSegmentName, string accountSubTypeName, string subCategoryName, string currencyName)
    {
        DataSet ds = new DataSet();
        using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString()))
            try
            {
                using (SqlCommand cmd = new SqlCommand("dbo.Web_SR_AddNewProduct", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("EffectiveDate", Convert.ToDateTime(effectiveDate));
                    cmd.Parameters.AddWithValue("ProductCode", productCode);
                    cmd.Parameters.AddWithValue("ProductName", productName);
                    cmd.Parameters.AddWithValue("SubCategoryName", subCategoryName);
                    cmd.Parameters.AddWithValue("CommissionSubCategoryName", commissionSubCategoryName);
                    cmd.Parameters.AddWithValue("CompanyName", companyName);


                    connection.Open();
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(ds);
                    }
                }            

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        return ds;
    }


    }
