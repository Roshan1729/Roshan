﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for LowInventory
/// </summary>
public abstract class ItemExceptionReportingCode
{
    public ItemExceptionReportingCode()
    {

        _ItemExceptionID = 0;
        _ItemID = 0;
        _ItemDescription = String.Empty;
        _SubCategoryID = 0;
        _SubCategoryName = String.Empty;
        _CommissionSubCategoryID = 0;
        _CommissionSubCategoryName = String.Empty;
        _EffectiveDate = DateTime.MinValue;
        _ExpirationDate = DateTime.MinValue;

    }

    private int _ItemExceptionID;
    private int _ItemID;
    private string _ItemDescription;
    private int _SubCategoryID;
    public string _SubCategoryName;
    private int _CommissionSubCategoryID;
    private string _CommissionSubCategoryName;
    private DateTime _EffectiveDate;
    private DateTime _ExpirationDate;
    
    public int ItemExceptionID
    {
        get { return _ItemExceptionID; }
        set { _ItemExceptionID = value; }
    }


    public int ItemID
    {
        get { return _ItemID; }
        set { _ItemID = value; }
    }


    public string ItemDescription
    {
        get { return _ItemDescription; }
        set { _ItemDescription = value; }
    }

    public int SubCategoryID
    {
        get { return _SubCategoryID; }
        set { _SubCategoryID = value; }
    }
    public string SubCategoryName
    {
        get { return _SubCategoryName; }
        set { _SubCategoryName = value; }
    }

   

    public string CommissionSubCategoryName
    {
        get { return _CommissionSubCategoryName; }
        set { _CommissionSubCategoryName = value; }
    }
    public int CommissionSubCategoryID
    {
        get { return _CommissionSubCategoryID; }
        set { _CommissionSubCategoryID = value; }
    }
    public DateTime EffectiveDate
    {
        get { return _EffectiveDate; }
        set { _EffectiveDate = value; }
    }

    public DateTime ExpirationDate
    {
        get { return _ExpirationDate; }
        set { _ExpirationDate = value; }
    }

    

    public DataSet GetSKPickingBoard2(string itemDescription,string subCategoryName,string commissionSubCategoryName)// string fromDate, string toDate, string period, string fromQuantity, string toQuantity, string fromAmount, string toAmount, string adjustmentType, string countryName, string subBusinessUnitName, string companyName, string subSegmentName, string accountSubTypeName, string subCategoryName, string rblMeasurementSystemText)
    {
        DataSet ds = new DataSet();

        using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString()))
            try
            {
                using (SqlCommand cmd = new SqlCommand("dbo.Web_SR_GetItemExceptionRecords", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    if (itemDescription == "Select One" || String.IsNullOrEmpty(itemDescription))
                    {
                        cmd.Parameters.AddWithValue("ItemDescription", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("ItemDescription", itemDescription);
                    }

                    if (subCategoryName == "Select One" || String.IsNullOrEmpty(subCategoryName))
                    {
                        cmd.Parameters.AddWithValue("SubCategoryName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("SubCategoryName", subCategoryName);
                    }

                    if (commissionSubCategoryName == "Select One" || String.IsNullOrEmpty(commissionSubCategoryName))
                    {
                        cmd.Parameters.AddWithValue("CommissionSubCategoryName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("CommissionSubCategoryName", commissionSubCategoryName);
                    }




                    connection.Open();
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(ds);
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        return ds;
    }


    public DataSet UpdateSKPickingBoard(ItemExceptionReportingChild li, int memberships)
    {
        DataSet ds = new DataSet();
        SqlConnection sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString());
        SqlCommand sqlCmd = new SqlCommand("dbo.Web_SR_UpdateItemExceptions", sqlConn);
        sqlCmd.CommandType = CommandType.StoredProcedure;

        //   if (memberships == 1 || memberships == 2)
        //   {

        sqlCmd.Parameters.Add("@ItemExceptionID", SqlDbType.Int).Value = li.ItemExceptionID;
        sqlCmd.Parameters.Add("@EffectiveDate", SqlDbType.DateTime).Value = li.EffectiveDate;
        sqlCmd.Parameters.Add("@ExpirationDate", SqlDbType.DateTime).Value = li.ExpirationDate;
        sqlCmd.Parameters.Add("@ItemDescription", SqlDbType.NVarChar).Value = li.ItemDescription;
        sqlCmd.Parameters.Add("@SubCategoryName", SqlDbType.NVarChar).Value = li.SubCategoryName;
        sqlCmd.Parameters.Add("@CommissionSubCategoryName", SqlDbType.NVarChar).Value = li.CommissionSubCategoryName;
       
        if (String.IsNullOrEmpty(HttpContext.Current.User.Identity.Name))
        {
            sqlCmd.Parameters.Add("@UpdateUser", SqlDbType.VarChar).Value = "sysadmin";
        }
        else
        {
            sqlCmd.Parameters.Add("@UpdateUser", SqlDbType.VarChar).Value = HttpContext.Current.User.Identity.Name;
        }
        //  }

        try
        {
            sqlConn.Open();
            using (SqlDataAdapter adapter = new SqlDataAdapter(sqlCmd))
            {
                adapter.Fill(ds);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return ds;
    }
    
   
    public DataSet AddNewItemException(string itemDescription, string subCategoryName, string commissionSubCategoryName,  string effectiveDate)//string date, string period, string quantity, string amountLCY, string amountSpotUSD, string amountAverageUSD, string costLCY, string costSpotUSD, string costAverageUSD, string comment, string adjustmentType, string countryName, string subBusinessUnitName, string companyName, string subSegmentName, string accountSubTypeName, string subCategoryName, string currencyName)
    {
        DataSet ds = new DataSet();
        using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString()))
            try
            {
                using (SqlCommand cmd = new SqlCommand("dbo.Web_SR_AddNewItemException", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("EffectiveDate", Convert.ToDateTime(effectiveDate));
                    cmd.Parameters.AddWithValue("ItemDescription", itemDescription);
                    cmd.Parameters.AddWithValue("SubCategoryName", subCategoryName);
                    cmd.Parameters.AddWithValue("CommissionSubCategoryName", commissionSubCategoryName);
                   
                    connection.Open();
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(ds);
                    }
                }            

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        return ds;
    }


    }
