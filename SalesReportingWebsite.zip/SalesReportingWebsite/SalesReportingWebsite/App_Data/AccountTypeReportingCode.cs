﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for LowInventory
/// </summary>
public abstract class AccountTypeReportingCode
{
    public AccountTypeReportingCode()
    {

        _AccountTypeID = 0;
        _AccountTypeCode = String.Empty;
        _AccountTypeName = String.Empty;
        _EffectiveDate = DateTime.MinValue;
        _ExpirationDate = DateTime.MinValue;

    }

    private int _AccountTypeID;
    private string _AccountTypeCode;
    private string _AccountTypeName;
    private DateTime _EffectiveDate;
    private DateTime _ExpirationDate;
    
    public int AccountTypeID
    {
        get { return _AccountTypeID; }
        set { _AccountTypeID = value; }
    }

    
    public string AccountTypeCode
    {
        get { return _AccountTypeCode; }
        set { _AccountTypeCode = value; }
    }

    public string AccountTypeName
    {
        get { return _AccountTypeName; }
        set { _AccountTypeName = value; }
    }

    public DateTime EffectiveDate
    {
        get { return _EffectiveDate; }
        set { _EffectiveDate = value; }
    }

    public DateTime ExpirationDate
    {
        get { return _ExpirationDate; }
        set { _ExpirationDate = value; }
    }

    

    public DataSet GetSKPickingBoard1(string accountTypeName)// string fromDate, string toDate, string period, string fromQuantity, string toQuantity, string fromAmount, string toAmount, string adjustmentType, string countryName, string subBusinessUnitName, string companyName, string subSegmentName, string accountSubTypeName, string subCategoryName, string rblMeasurementSystemText)
    {
        DataSet ds = new DataSet();

        using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString()))
            try
            {
                using (SqlCommand cmd = new SqlCommand("dbo.Web_SR_GetAccountTypeRecords", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    if (accountTypeName == "Select One" || String.IsNullOrEmpty(accountTypeName))
                    {
                        cmd.Parameters.AddWithValue("AccountTypeName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("AccountTypeName", accountTypeName);
                    }



                    connection.Open();
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(ds);
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        return ds;
    }


    public DataSet UpdateSKPickingBoard(AccountTypeReportingChild li, int memberships)
    {
        DataSet ds = new DataSet();
        
        SqlConnection sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString());
        SqlCommand sqlCmd = new SqlCommand("dbo.Web_SR_UpdateAccountTypes", sqlConn);
        sqlCmd.CommandType = CommandType.StoredProcedure;

        //   if (memberships == 1 || memberships == 2)
        //   {

        sqlCmd.Parameters.Add("@AccountTypeID", SqlDbType.Int).Value = li.AccountTypeID;
        sqlCmd.Parameters.Add("@EffectiveDate", SqlDbType.DateTime).Value = li.EffectiveDate;
        sqlCmd.Parameters.Add("@ExpirationDate", SqlDbType.DateTime).Value = li.ExpirationDate;
        sqlCmd.Parameters.Add("@AccountTypeCode", SqlDbType.NVarChar).Value = li.AccountTypeCode;
        sqlCmd.Parameters.Add("@AccountTypeName", SqlDbType.NVarChar).Value = li.AccountTypeName;

        if (String.IsNullOrEmpty(HttpContext.Current.User.Identity.Name))
        {
            sqlCmd.Parameters.Add("@UpdateUser", SqlDbType.VarChar).Value = "sysadmin";
        }
        else
        {
            sqlCmd.Parameters.Add("@UpdateUser", SqlDbType.VarChar).Value = HttpContext.Current.User.Identity.Name;
        }
        //  }

        try
        {
            sqlConn.Open();
            using (SqlDataAdapter adapter = new SqlDataAdapter(sqlCmd))
            {
                adapter.Fill(ds);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return ds;
    }
    
   
    public DataSet AddNewAccountType(string accountTypeCode, string accountTypeName, string effectiveDate)//string date, string period, string quantity, string amountLCY, string amountSpotUSD, string amountAverageUSD, string costLCY, string costSpotUSD, string costAverageUSD, string comment, string adjustmentType, string countryName, string subBusinessUnitName, string companyName, string subSegmentName, string accountSubTypeName, string subCategoryName, string currencyName)
    {
        bool isSuccessful = true;
        DataSet ds = new DataSet();
        using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString()))
            try
            {
                using (SqlCommand cmd = new SqlCommand("dbo.Web_SR_AddNewAccountType", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("EffectiveDate", Convert.ToDateTime(effectiveDate));


                    if (String.IsNullOrEmpty(accountTypeCode))
                    {
                        cmd.Parameters.AddWithValue("AccountTypeCode", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("AccountTypeCode", accountTypeCode);
                    }

                    if (String.IsNullOrEmpty(accountTypeName))
                    {
                        cmd.Parameters.AddWithValue("AccountTypeName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("AccountTypeName", accountTypeName);
                    }
                    

                    connection.Open();
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(ds);
                    }
                }

            }
            catch (Exception ex)
            {
                isSuccessful = false;
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        return ds;
    }


    }
