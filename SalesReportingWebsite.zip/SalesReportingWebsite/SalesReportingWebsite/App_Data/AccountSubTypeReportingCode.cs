﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for LowInventory
/// </summary>
public abstract class AccountSubTypeReportingCode
{
    public AccountSubTypeReportingCode()
    {

        _AccountSubTypeID = 0;
        _AccountSubTypeCode = String.Empty;
        _AccountSubTypeName = String.Empty;
        _AccountTypeName = String.Empty;
        _AccountTypeID = 0;
        _EffectiveDate = DateTime.MinValue;
        _ExpirationDate = DateTime.MinValue;

    }

    private int _AccountSubTypeID;
    private string _AccountSubTypeCode;
    private string _AccountSubTypeName;
    public string _AccountTypeName;
    private int _AccountTypeID;
    private DateTime _EffectiveDate;
    private DateTime _ExpirationDate;
    
    public int AccountSubTypeID
    {
        get { return _AccountSubTypeID; }
        set { _AccountSubTypeID = value; }
    }


    public string AccountSubTypeCode
    {
        get { return _AccountSubTypeCode; }
        set { _AccountSubTypeCode = value; }
    }

    public string AccountSubTypeName
    {
        get { return _AccountSubTypeName; }
        set { _AccountSubTypeName = value; }
    }

    public string AccountTypeName
    {
        get { return _AccountTypeName; }
        set { _AccountTypeName = value; }
    }
    public int AccountTypeID
    {
        get { return _AccountTypeID; }
        set { _AccountTypeID = value; }
    }
    public DateTime EffectiveDate
    {
        get { return _EffectiveDate; }
        set { _EffectiveDate = value; }
    }

    public DateTime ExpirationDate
    {
        get { return _ExpirationDate; }
        set { _ExpirationDate = value; }
    }

    

    public DataSet GetSKPickingBoard2(string accountSubTypeName, string accountTypeName)// string fromDate, string toDate, string period, string fromQuantity, string toQuantity, string fromAmount, string toAmount, string adjustmentType, string countryName, string subBusinessUnitName, string companyName, string subSegmentName, string accountSubTypeName, string subCategoryName, string rblMeasurementSystemText)
    {
        DataSet ds = new DataSet();

        using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString()))
            try
            {
                using (SqlCommand cmd = new SqlCommand("dbo.Web_SR_GetAccountSubTypeRecords", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;


                    if (accountSubTypeName == "Select One" || String.IsNullOrEmpty(accountSubTypeName))
                    {
                        cmd.Parameters.AddWithValue("AccountSubTypeName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("AccountSubTypeName", accountSubTypeName);
                    }


                    if (accountTypeName == "Select One" || String.IsNullOrEmpty(accountTypeName))
                    {
                        cmd.Parameters.AddWithValue("AccountTypeName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("AccountTypeName", accountTypeName);
                    }


                    //if (accountSubTypeName == "Select One" || String.IsNullOrEmpty(accountSubTypeName))
                    //{
                    //    cmd.Parameters.AddWithValue("AccountSubTypeName", DBNull.Value);
                    //}
                    //else
                    //{
                    //    cmd.Parameters.AddWithValue("AccountSubTypeBName", accountSubTypeName);
                    //}



                    connection.Open();
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(ds);
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        return ds;
    }


    public DataSet UpdateSKPickingBoard(AccountSubTypeReportingChild li, int memberships)
    {
        DataSet ds = new DataSet();
        SqlConnection sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString());
        SqlCommand sqlCmd = new SqlCommand("dbo.Web_SR_UpdateAccountSubTypes", sqlConn);
        sqlCmd.CommandType = CommandType.StoredProcedure;

        //   if (memberships == 1 || memberships == 2)
        //   {

        sqlCmd.Parameters.Add("@AccountSubTypeID", SqlDbType.Int).Value = li.AccountSubTypeID;
        sqlCmd.Parameters.Add("@EffectiveDate", SqlDbType.DateTime).Value = li.EffectiveDate;
        sqlCmd.Parameters.Add("@ExpirationDate", SqlDbType.DateTime).Value = li.ExpirationDate;
        sqlCmd.Parameters.Add("@AccountSubTypeCode", SqlDbType.NVarChar).Value = li.AccountSubTypeCode;
        sqlCmd.Parameters.Add("@AccountSubTypeName", SqlDbType.NVarChar).Value = li.AccountSubTypeName;
        sqlCmd.Parameters.Add("@AccountTypeName", SqlDbType.NVarChar).Value = li.AccountTypeName;

      
        if (String.IsNullOrEmpty(HttpContext.Current.User.Identity.Name))
        {
            sqlCmd.Parameters.Add("@UpdateUser", SqlDbType.VarChar).Value = "sysadmin";
        }
        else
        {
            sqlCmd.Parameters.Add("@UpdateUser", SqlDbType.VarChar).Value = HttpContext.Current.User.Identity.Name;
        }
        //  }

        try
        {
            sqlConn.Open();
            using (SqlDataAdapter adapter = new SqlDataAdapter(sqlCmd))
            {
                adapter.Fill(ds);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return ds;
    }
    
   
    public DataSet AddNewAccountSubType(string accountSubTypeCode, string accountSubTypeName, string accountTypeName, string effectiveDate)//string date, string period, string quantity, string amountLCY, string amountSpotUSD, string amountAverageUSD, string costLCY, string costSpotUSD, string costAverageUSD, string comment, string adjustmentType, string countryName, string subBusinessUnitName, string companyName, string subSegmentName, string accountSubTypeName, string subCategoryName, string currencyName)
    {
        DataSet ds = new DataSet();
        using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString()))
            try
            {
                using (SqlCommand cmd = new SqlCommand("dbo.Web_SR_AddNewAccountSubType", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("EffectiveDate", Convert.ToDateTime(effectiveDate));
                    cmd.Parameters.AddWithValue("AccountSubTypeCode", accountSubTypeCode);
                    cmd.Parameters.AddWithValue("AccountSubTypeName", accountSubTypeName);
                    cmd.Parameters.AddWithValue("AccountTypeName", accountTypeName);
                                       

                    connection.Open();
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(ds);
                    }
                }            

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        return ds;
    }


    }
