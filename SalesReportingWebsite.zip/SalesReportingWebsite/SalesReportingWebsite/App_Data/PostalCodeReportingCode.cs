﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for LowInventory
/// </summary>
public abstract class PostalCodeReportingCode
{
    public  PostalCodeReportingCode()
    {

        _PostalCodeID = 0;
        _PostalCode = 0;
        _PostalCodeCityName = String.Empty;
        _StateProvinceID = 0;
        _StateProvinceName = String.Empty;
        _CountryID = 0;
        _CountryName = String.Empty;
        _TerritoryID = 0;
        _TerritoryName = String.Empty;
        _CompanyID = 0;
        _CompanyName = String.Empty;
        _DistributionRegionID = 0;
        _DistributionRegionName = String.Empty;
        _EffectiveDate = DateTime.MinValue;
        _ExpirationDate = DateTime.MinValue;

    }

    private int _PostalCodeID;
    private int _PostalCode;
    private string _PostalCodeCityName;
    private int _StateProvinceID;
    private string _StateProvinceName;
    private int _CountryID;
    private string _CountryName;
    private int _TerritoryID;
    private string _TerritoryName;
    private int _CompanyID;
    private string _CompanyName;
    private int _DistributionRegionID;
    private string _DistributionRegionName;
    private DateTime _EffectiveDate;
    private DateTime _ExpirationDate;


    public int PostalCodeID
    {
        get { return _PostalCodeID; }
        set { _PostalCodeID = value; }
    }
    public int PostalCode
    {
        get { return _PostalCode; }
        set { _PostalCode = value; }
    }

    public string PostalCodeCityName
    {
        get { return _PostalCodeCityName; }
        set { _PostalCodeCityName = value; }
    }
    public int StateProvinceID
    {
        get { return _StateProvinceID; }
        set { _StateProvinceID = value; }
    }


    public string StateProvinceName
    {
        get { return _StateProvinceName; }
        set { _StateProvinceName = value; }
    }

    public int CountryID
    {
        get { return _CountryID; }
        set { _CountryID = value; }
    }
    public string CountryName
    {
        get { return _CountryName; }
        set { _CountryName = value; }
    }

    public int TerritoryID
    {
        get { return _TerritoryID; }
        set { _TerritoryID = value; }
    }


    public string TerritoryName
    {
        get { return _TerritoryName; }
        set { _TerritoryName = value; }
    }

    public int CompanyID
    {
        get { return _CompanyID; }
        set { _CompanyID = value; }
    }

    public string CompanyName
    {
        get { return _CompanyName; }
        set { _CompanyName = value; }
    }

    public int DistributionRegionID
    {
        get { return _DistributionRegionID; }
        set { _DistributionRegionID = value; }
    }

    public string DistributionRegionName
    {
        get { return _DistributionRegionName; }
        set { _DistributionRegionName = value; }
    }

    public DateTime EffectiveDate
    {
        get { return _EffectiveDate; }
        set { _EffectiveDate = value; }
    }

    public DateTime ExpirationDate
    {
        get { return _ExpirationDate; }
        set { _ExpirationDate = value; }
    }

    

    public DataSet GetSKPickingBoard2(string postalCodeCityName, string stateProvinceName, string countryName, string territoryName, string companyName, string distributionRegionName)// string fromDate, string toDate, string period, string fromQuantity, string toQuantity, string fromAmount, string toAmount, string adjustmentType, string countryName, string subBusinessUnitName, string companyName, string subSegmentName, string accountSubTypeName, string subCategoryName, string rblMeasurementSystemText)
    {
        DataSet ds = new DataSet();

        using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString()))
            try
            {
                using (SqlCommand cmd = new SqlCommand("dbo.Web_SR_GetPostalCodeRecords", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    if (postalCodeCityName == "Select One" || String.IsNullOrEmpty(postalCodeCityName))
                    {
                        cmd.Parameters.AddWithValue("PostalCodeCityName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("PostalCodeCityName", postalCodeCityName);
                    }

                    if (stateProvinceName == "Select One" || String.IsNullOrEmpty(stateProvinceName))
                    {
                        cmd.Parameters.AddWithValue("StateProvinceName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("StateProvinceName", stateProvinceName);
                    }

                    if (countryName == "Select One" || String.IsNullOrEmpty(countryName))
                    {
                        cmd.Parameters.AddWithValue("CountryName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("CountryName", countryName);
                    }

                    if (territoryName == "Select One" || String.IsNullOrEmpty(territoryName))
                    {
                        cmd.Parameters.AddWithValue("TerritoryName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("TerritoryName", territoryName);
                    }
                    if (companyName == "Select One" || String.IsNullOrEmpty(companyName))
                    {
                        cmd.Parameters.AddWithValue("CompanyName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("CompanyName", companyName);
                    }

                    if (distributionRegionName == "Select One" || String.IsNullOrEmpty(distributionRegionName))
                    {
                        cmd.Parameters.AddWithValue("DistributionRegionName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("DistributionRegionName", distributionRegionName);
                    }

                    connection.Open();
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(ds);
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        return ds;
    }


    public DataSet UpdateSKPickingBoard(PostalCodeReportingChild li, int memberships)
    {
        DataSet ds = new DataSet();
        SqlConnection sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString());
        SqlCommand sqlCmd = new SqlCommand("dbo.Web_SR_UpdatePostalCodes", sqlConn);
        sqlCmd.CommandType = CommandType.StoredProcedure;

        //   if (memberships == 1 || memberships == 2)
        //   {

        sqlCmd.Parameters.Add("@PostalCodeID", SqlDbType.Int).Value = li.PostalCodeID;
        //sqlCmd.Parameters.Add("@SubCategorySequence", SqlDbType.Int).Value = li.SubCategorySequence;
        sqlCmd.Parameters.Add("@PostalCode", SqlDbType.Int).Value = li.PostalCode;
        sqlCmd.Parameters.Add("@PostalCodeCityName", SqlDbType.NVarChar).Value = li.PostalCodeCityName;
        sqlCmd.Parameters.Add("@StateProvinceName", SqlDbType.NVarChar).Value = li.StateProvinceName;
        sqlCmd.Parameters.Add("@CountryName", SqlDbType.NVarChar).Value = li.CountryName;
        sqlCmd.Parameters.Add("@TerritoryName", SqlDbType.NVarChar).Value = li.TerritoryName;
        sqlCmd.Parameters.Add("@CompanyName", SqlDbType.NVarChar).Value = li.CompanyName;
        sqlCmd.Parameters.Add("@DistributionRegionName", SqlDbType.NVarChar).Value = li.DistributionRegionName;
        sqlCmd.Parameters.Add("@EffectiveDate", SqlDbType.DateTime).Value = li.EffectiveDate;
        sqlCmd.Parameters.Add("@ExpirationDate", SqlDbType.DateTime).Value = li.ExpirationDate;
        
        
        if (String.IsNullOrEmpty(HttpContext.Current.User.Identity.Name))
        {
            sqlCmd.Parameters.Add("@UpdateUser", SqlDbType.VarChar).Value = "sysadmin";
        }
        else
        {
            sqlCmd.Parameters.Add("@UpdateUser", SqlDbType.VarChar).Value = HttpContext.Current.User.Identity.Name;
        }
        

        try
        {
            sqlConn.Open();
            using (SqlDataAdapter adapter = new SqlDataAdapter(sqlCmd))
            {
                adapter.Fill(ds);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return ds;
    }



    }
