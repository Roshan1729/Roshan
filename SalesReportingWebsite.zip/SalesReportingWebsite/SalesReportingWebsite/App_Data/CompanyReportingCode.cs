﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for LowInventory
/// </summary>
public abstract class CompanyReportingCode
{
    public CompanyReportingCode()
    {

        _CompanyID = 0;
        _CompanyKey = String.Empty;
        _CompanyName = String.Empty;
        _CompanyLocalCurrency = String.Empty;
        _SubSegmentID = 0;
        _SubSegmentName = String.Empty;
        _EffectiveDate = DateTime.MinValue;
        _ExpirationDate = DateTime.MinValue;

    }

    private int _CompanyID;
    private string _CompanyKey;
    private string _CompanyName;
    public string _CompanyLocalCurrency;
    private int _SubSegmentID;
    public string _SubSegmentName;
    private DateTime _EffectiveDate;
    private DateTime _ExpirationDate;
    
    public int CompanyID
    {
        get { return _CompanyID; }
        set { _CompanyID = value; }
    }


    public string CompanyKey
    {
        get { return _CompanyKey; }
        set { _CompanyKey = value; }
    }

    public string CompanyName
    {
        get { return _CompanyName; }
        set { _CompanyName = value; }
    }

    public string CompanyLocalCurrency
    {
        get { return _CompanyLocalCurrency; }
        set { _CompanyLocalCurrency = value; }
    }

    public string SubSegmentName
    {
        get { return _SubSegmentName; }
        set { _SubSegmentName = value; }
    }
    public int SubSegmentID
    {
        get { return _SubSegmentID; }
        set { _SubSegmentID = value; }
    }
    public DateTime EffectiveDate
    {
        get { return _EffectiveDate; }
        set { _EffectiveDate = value; }
    }

    public DateTime ExpirationDate
    {
        get { return _ExpirationDate; }
        set { _ExpirationDate = value; }
    }

    

    public DataSet GetSKPickingBoard2(string companyName,string subSegmentname,string companyLocalCurrency)// string fromDate, string toDate, string period, string fromQuantity, string toQuantity, string fromAmount, string toAmount, string adjustmentType, string countryName, string subBusinessUnitName, string companyName, string subSegmentName, string accountSubTypeName, string subCategoryName, string rblMeasurementSystemText)
    {
        DataSet ds = new DataSet();

        using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString()))
            try
            {
                using (SqlCommand cmd = new SqlCommand("dbo.Web_SR_GetCompanyRecords", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    if (companyName == "Select One" || String.IsNullOrEmpty(companyName))
                    {
                        cmd.Parameters.AddWithValue("CompanyName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("CompanyName", companyName);
                    }

                    if (subSegmentname == "Select One" || String.IsNullOrEmpty(subSegmentname))
                    {
                        cmd.Parameters.AddWithValue("SubSegmentName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("SubSegmentName", subSegmentname);
                    }

                    if (companyLocalCurrency == "Select One" || String.IsNullOrEmpty(companyLocalCurrency))
                    {
                        cmd.Parameters.AddWithValue("CompanyLocalCurrency", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("CompanyLocalCurrency", companyLocalCurrency);
                    }




                    connection.Open();
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(ds);
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        return ds;
    }


    public DataSet UpdateSKPickingBoard(CompanyReportingChild li, int memberships)
    {
        DataSet ds = new DataSet();
        SqlConnection sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString());
        SqlCommand sqlCmd = new SqlCommand("dbo.Web_SR_UpdateCompanys", sqlConn);
        sqlCmd.CommandType = CommandType.StoredProcedure;

        //   if (memberships == 1 || memberships == 2)
        //   {

        sqlCmd.Parameters.Add("@CompanyID", SqlDbType.Int).Value = li.CompanyID;
        sqlCmd.Parameters.Add("@EffectiveDate", SqlDbType.DateTime).Value = li.EffectiveDate;
        sqlCmd.Parameters.Add("@ExpirationDate", SqlDbType.DateTime).Value = li.ExpirationDate;
        sqlCmd.Parameters.Add("@CompanyKey", SqlDbType.NVarChar).Value = li.CompanyKey;
        sqlCmd.Parameters.Add("@CompanyName", SqlDbType.NVarChar).Value = li.CompanyName;
        sqlCmd.Parameters.Add("@CompanyLocalCurrency", SqlDbType.NVarChar).Value = li.CompanyLocalCurrency;
        sqlCmd.Parameters.Add("@SubSegmentName", SqlDbType.NVarChar).Value = li.SubSegmentName;

        //if (li.SegmentName == string.Empty)
        //{
        //    sqlCmd.Parameters.Add("@SegmentName", SqlDbType.VarChar).Value = DBNull.Value;
        //}
        //else
        //{
        //    sqlCmd.Parameters.Add("@SegmentName", SqlDbType.VarChar).Value = li.SegmentName;
        //}
        if (String.IsNullOrEmpty(HttpContext.Current.User.Identity.Name))
        {
            sqlCmd.Parameters.Add("@UpdateUser", SqlDbType.VarChar).Value = "sysadmin";
        }
        else
        {
            sqlCmd.Parameters.Add("@UpdateUser", SqlDbType.VarChar).Value = HttpContext.Current.User.Identity.Name;
        }
        //  }

        try
        {
            sqlConn.Open();
            using (SqlDataAdapter adapter = new SqlDataAdapter(sqlCmd))
            {
                adapter.Fill(ds);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return ds;
    }
    
   
    public DataSet AddNewCompany(string companyKey, string companyName, string companyLocalCurrency, string subSegmentName, string effectiveDate)//string date, string period, string quantity, string amountLCY, string amountSpotUSD, string amountAverageUSD, string costLCY, string costSpotUSD, string costAverageUSD, string comment, string adjustmentType, string countryName, string subBusinessUnitName, string companyName, string subSegmentName, string accountSubTypeName, string subCategoryName, string currencyName)
    {
        DataSet ds = new DataSet();
        using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString()))
            try
            {
                using (SqlCommand cmd = new SqlCommand("dbo.Web_SR_AddNewCompany", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("EffectiveDate", Convert.ToDateTime(effectiveDate));
                    cmd.Parameters.AddWithValue("CompanyKey", companyKey);
                    cmd.Parameters.AddWithValue("CompanyName", companyName);
                    cmd.Parameters.AddWithValue("CompanyLocalCurrency", companyLocalCurrency);
                    cmd.Parameters.AddWithValue("SubSegmentName", subSegmentName);


                    connection.Open();
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(ds);
                    }
                }            

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        return ds;
    }


    }
