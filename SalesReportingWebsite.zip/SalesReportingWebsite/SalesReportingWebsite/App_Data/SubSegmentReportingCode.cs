﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for LowInventory
/// </summary>
public abstract class SubSegmentReportingCode
{
    public SubSegmentReportingCode()
    {

        _SubSegmentID = 0;
        _SubSegmentCode = String.Empty;
        _SubSegmentName = String.Empty;
        _SegmentName = String.Empty;
        _SegmentID = 0;
        _EffectiveDate = DateTime.MinValue;
        _ExpirationDate = DateTime.MinValue;

    }

    private int _SubSegmentID;
    private string _SubSegmentCode;
    private string _SubSegmentName;
    public string _SegmentName;
    private int _SegmentID;
    private DateTime _EffectiveDate;
    private DateTime _ExpirationDate;
    
    public int SubSegmentID
    {
        get { return _SubSegmentID; }
        set { _SubSegmentID = value; }
    }


    public string SubSegmentCode
    {
        get { return _SubSegmentCode; }
        set { _SubSegmentCode = value; }
    }

    public string SubSegmentName
    {
        get { return _SubSegmentName; }
        set { _SubSegmentName = value; }
    }

    public string SegmentName
    {
        get { return _SegmentName; }
        set { _SegmentName = value; }
    }
    public int SegmentID
    {
        get { return _SegmentID; }
        set { _SegmentID = value; }
    }
    public DateTime EffectiveDate
    {
        get { return _EffectiveDate; }
        set { _EffectiveDate = value; }
    }

    public DateTime ExpirationDate
    {
        get { return _ExpirationDate; }
        set { _ExpirationDate = value; }
    }

    

    public DataSet GetSKPickingBoard2(string segmentName,string subSegmentname)// string fromDate, string toDate, string period, string fromQuantity, string toQuantity, string fromAmount, string toAmount, string adjustmentType, string countryName, string subBusinessUnitName, string companyName, string subSegmentName, string accountSubTypeName, string subCategoryName, string rblMeasurementSystemText)
    {
        DataSet ds = new DataSet();

        using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString()))
            try
            {
                using (SqlCommand cmd = new SqlCommand("dbo.Web_SR_GetSubSegmentRecords", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    if (subSegmentname == "Select One" || String.IsNullOrEmpty(subSegmentname))
                    {
                        cmd.Parameters.AddWithValue("SubSegmentName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("SubSegmentName", subSegmentname);
                    }


                    if (segmentName == "Select One" || String.IsNullOrEmpty(segmentName))
                    {
                        cmd.Parameters.AddWithValue("SegmentName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("SegmentName", segmentName);
                    }



                    connection.Open();
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(ds);
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        return ds;
    }


    public DataSet UpdateSKPickingBoard(SubSegmentReportingChild li, int memberships)
    {
        DataSet ds = new DataSet();
        SqlConnection sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString());
        SqlCommand sqlCmd = new SqlCommand("dbo.Web_SR_UpdateSubSegments", sqlConn);
        sqlCmd.CommandType = CommandType.StoredProcedure;

        //   if (memberships == 1 || memberships == 2)
        //   {

        sqlCmd.Parameters.Add("@SubSegmentID", SqlDbType.Int).Value = li.SubSegmentID;
        sqlCmd.Parameters.Add("@EffectiveDate", SqlDbType.DateTime).Value = li.EffectiveDate;
        sqlCmd.Parameters.Add("@ExpirationDate", SqlDbType.DateTime).Value = li.ExpirationDate;
        sqlCmd.Parameters.Add("@SubSegmentCode", SqlDbType.NVarChar).Value = li.SubSegmentCode;
        sqlCmd.Parameters.Add("@SubSegmentName", SqlDbType.NVarChar).Value = li.SubSegmentName;
        sqlCmd.Parameters.Add("@SegmentName", SqlDbType.NVarChar).Value = li.SegmentName;

        //if (li.SegmentName == string.Empty)
        //{
        //    sqlCmd.Parameters.Add("@SegmentName", SqlDbType.VarChar).Value = DBNull.Value;
        //}
        //else
        //{
        //    sqlCmd.Parameters.Add("@SegmentName", SqlDbType.VarChar).Value = li.SegmentName;
        //}
        if (String.IsNullOrEmpty(HttpContext.Current.User.Identity.Name))
        {
            sqlCmd.Parameters.Add("@UpdateUser", SqlDbType.VarChar).Value = "sysadmin";
        }
        else
        {
            sqlCmd.Parameters.Add("@UpdateUser", SqlDbType.VarChar).Value = HttpContext.Current.User.Identity.Name;
        }
        //  }

        try
        {
            sqlConn.Open();
            using (SqlDataAdapter adapter = new SqlDataAdapter(sqlCmd))
            {
                adapter.Fill(ds);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return ds;
    }
    
   
    public DataSet AddNewSubSegment(string subSegmentCode, string subSegmentName, string segmentName, string effectiveDate)//string date, string period, string quantity, string amountLCY, string amountSpotUSD, string amountAverageUSD, string costLCY, string costSpotUSD, string costAverageUSD, string comment, string adjustmentType, string countryName, string subBusinessUnitName, string companyName, string subSegmentName, string accountSubTypeName, string subCategoryName, string currencyName)
    {
        DataSet ds = new DataSet();
        using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString()))
            try
            {
                using (SqlCommand cmd = new SqlCommand("dbo.Web_SR_AddNewSubSegment", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("EffectiveDate", Convert.ToDateTime(effectiveDate));
                    cmd.Parameters.AddWithValue("SubSegmentCode", subSegmentCode);
                    cmd.Parameters.AddWithValue("SubSegmentName", subSegmentName);
                    cmd.Parameters.AddWithValue("SegmentName",segmentName);
                                       

                    connection.Open();
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(ds);
                    }
                }            

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        return ds;
    }


    }
