﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SalesReportingWebsite
{
    public partial class Product : PageBase
    {
        public int memberships;
        protected void Page_Load(object sender, EventArgs e)
        {

            //VBFunctions.ADFunctions obj = new VBFunctions.ADFunctions();
            //string userID = obj.GetUserName();
            //// string dirEntry = obj.GetDirectoryEntry();
            //memberships = obj.VerifyGroupMemberships("LDAP://192.168.100.3/ou=Cooper Network Users,dc=coopersurgical1,dc=com", "coopservice", "^CSIServ2016!", userID);

            if (!Page.IsPostBack)

            {
                ProductReportingChild li = new ProductReportingChild();

                DataTable table = new DataTable();


         

                ddlProductCodeName.DataSource = li.ProductCodeNameList().Tables[0];
                ddlProductCodeName.DataTextField = "ProductCode";
                ddlProductCodeName.DataBind();

                ddlProductName.DataSource = li.ProductNameList().Tables[0];
                ddlProductName.DataTextField = "ProductName";
                ddlProductName.DataBind();

                ddlSubCategoryName.DataSource = li.SubCategoryNameList().Tables[0];
                ddlSubCategoryName.DataTextField = "SubCategoryName";
                ddlSubCategoryName.DataBind();

                ddlCommissionSubCategoryName.DataSource = li.CommissionSubCategoryNameList().Tables[0];
                ddlCommissionSubCategoryName.DataTextField = "CommissionSubCategoryName";
                ddlCommissionSubCategoryName.DataBind();

                ddlCompanyName.DataSource = li.CompanyNameList().Tables[0];
                ddlCompanyName.DataTextField = "CompanyName";
                ddlCompanyName.DataBind();


                newSubCategoryName.DataSource = li.SubCategoryNameList().Tables[0];
                newSubCategoryName.DataTextField = "SubCategoryName";
                newSubCategoryName.DataBind();

                newCommissionSubCategoryName.DataSource = li.CommissionSubCategoryNameList().Tables[0];
                newCommissionSubCategoryName.DataTextField = "CommissionSubCategoryName";
                newCommissionSubCategoryName.DataBind();

                newCompanyName.DataSource = li.CompanyNameList().Tables[0];
                newCompanyName.DataTextField = "CompanyName";
                newCompanyName.DataBind();



                BindGridView();
            }
        }
        
        #region EventHandling
              
        protected void Product_RowEditing(object sender, GridViewEditEventArgs e)
        {
            ProductGridView.EditIndex = e.NewEditIndex;
            int index = e.NewEditIndex;
            GridViewRow row = ProductGridView.Rows[e.NewEditIndex];

            BindGridView();
        }
        
        protected void Product_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            ProductGridView.EditIndex = -1;
            BindGridView();
        }


        protected void Product_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            if (Page.IsValid)
            {
                ProductReportingChild li = new ProductReportingChild();
                GridViewRow row = ProductGridView.Rows[e.RowIndex];
                string display = "";
                bool isFormFilled = true;
                try
                {
                    li.ProductID = Convert.ToInt32(ProductGridView.DataKeys[e.RowIndex].Values[0]);

                    if (((TextBox)row.FindControl("ProductCode")).Text != string.Empty)
                    {
                        li.ProductCode = Convert.ToInt32(((TextBox)row.FindControl("ProductCode")).Text);
                    }
                    else
                    {
                        display = "Product Code cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (((TextBox)row.FindControl("ProductName")).Text != string.Empty)
                    {
                        li.ProductName = Convert.ToString(((TextBox)row.FindControl("ProductName")).Text);
                    }
                    else
                    {
                        display = "Product Name cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (((DropDownList)row.FindControl("SubCategoryName")).SelectedValue != "Select One")
                    {
                        li.SubCategoryName = ((DropDownList)row.FindControl("SubCategoryName")).SelectedValue;
                    }
                    else
                    {
                        display = "Select SubCategory Name from dropdown";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (((DropDownList)row.FindControl("CommissionSubCategoryName")).SelectedValue != "Select One")
                    {
                        li.CommissionSubCategoryName = ((DropDownList)row.FindControl("CommissionSubCategoryName")).SelectedValue;
                    }
                    else
                    {
                        display = "Select CommissionSubCategory Name from dropdown";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }


                    if (((DropDownList)row.FindControl("CompanyName")).SelectedValue != "Select One")
                    {
                        li.CompanyName = ((DropDownList)row.FindControl("CompanyName")).SelectedValue;
                    }
                    else
                    {
                        display = "Select Company Name from dropdown";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }



                    if (!String.IsNullOrEmpty(Convert.ToString((Request.Form[row.FindControl("EffectiveDate").UniqueID]))))
                    {
                        li.EffectiveDate = Convert.ToDateTime((Request.Form[row.FindControl("EffectiveDate").UniqueID]));
                    }
                    else
                    {
                        display = "Effective Date cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }
                    if (!String.IsNullOrEmpty(Convert.ToString((Request.Form[row.FindControl("ExpirationDate").UniqueID]))))
                    {
                        li.ExpirationDate = Convert.ToDateTime((Request.Form[row.FindControl("ExpirationDate").UniqueID]));
                    }
                    else
                    {
                        display = "Expiration Date cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (li.ExpirationDate < li.EffectiveDate)
                    {
                        display = "Expiration Date must be after Effective date";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (isFormFilled)
                    {
                        DataSet result = li.UpdateSKPickingBoard(li, memberships);

                        string res = Convert.ToString(result.Tables[0].Rows[0].ItemArray[0]);

                        if (res.Equals("Duplicate ProductName"))
                        {
                            display = "Product Name already exists in the database";
                            ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        }
                        else if (res.Equals("Duplicate ProductCode"))
                        {
                            display = "Product Code already exists in the database";
                            ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        }
                        else if (res.Equals("Success"))
                        {
                        }
                    }
                    //if (memberships > 0)
                    //{
                    //    li.UpdateSKPickingBoard(li, memberships);
                    //}
                    //else
                    //{
                    //    string display = "You must be a member of SK_Picking _Operations or SK_Picking_Warehouse groups to make changes.";
                    //    ClientScript.RegisterStartupScript(this.GetType(), "yourMessage", "alert('" + display + "');", true);
                    //}

                }
                catch (Exception ex)
                {
                    throw ex;
                }

                ProductGridView.EditIndex = -1;
                BindGridView();
            }
        }

        protected void Product_SortData(object sender, GridViewSortEventArgs e)
        {
            if (ProductGridView.EditIndex >= -1)
            {
                ProductGridView.EditIndex = -1;
            }
            BindGridView();
            SortGrid(sender, e);
        }

        protected void Product_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow && ProductGridView.EditIndex == e.Row.RowIndex)
            {
                ProductReportingChild li = new ProductReportingChild();

                //Find the DropDownList in the Row
                DropDownList ddlSubCategoryNameList = (e.Row.FindControl("SubCategoryName") as DropDownList);
                ddlSubCategoryNameList.DataSource = li.SubCategoryNameList().Tables[0];
                ddlSubCategoryNameList.DataTextField = "SubCategoryName";
                ddlSubCategoryNameList.DataValueField = "SubCategoryName";
                ddlSubCategoryNameList.DataBind();

                //Add Default Item in the DropDownList
                ddlSubCategoryNameList.Items.Insert(0, new ListItem("Select One"));

                //Select the Country of Customer in DropDownList
                string subCategoryNames = (e.Row.FindControl("lblSubCategoryName") as Label).Text;
                ddlSubCategoryNameList.Items.FindByValue(subCategoryNames).Selected = true;



                //Find the DropDownList in the Row
                DropDownList ddlCommissionSubCategoryNameList = (e.Row.FindControl("CommissionSubCategoryName") as DropDownList);
                ddlCommissionSubCategoryNameList.DataSource = li.CommissionSubCategoryNameList().Tables[0];
                ddlCommissionSubCategoryNameList.DataTextField = "CommissionSubCategoryName";
                ddlCommissionSubCategoryNameList.DataValueField = "CommissionSubCategoryName";
                ddlCommissionSubCategoryNameList.DataBind();

                //Add Default Item in the DropDownList
                ddlCommissionSubCategoryNameList.Items.Insert(0, new ListItem("Select One"));

                //Select the Country of Customer in DropDownList
                string commissionSubCategoryNames = (e.Row.FindControl("lblCommissionSubCategoryName") as Label).Text;
                ddlCommissionSubCategoryNameList.Items.FindByValue(commissionSubCategoryNames).Selected = true;


                //Find the DropDownList in the Row
                DropDownList ddlCompanyNameList = (e.Row.FindControl("CompanyName") as DropDownList);
                ddlCompanyNameList.DataSource = li.CompanyNameList().Tables[0];
                ddlCompanyNameList.DataTextField = "CompanyName";
                ddlCompanyNameList.DataValueField = "CompanyName";
                ddlCompanyNameList.DataBind();

                //Add Default Item in the DropDownList
                ddlCompanyNameList.Items.Insert(0, new ListItem("Select One"));

                //Select the Country of Customer in DropDownList
                string companyNames = (e.Row.FindControl("lblCompanyName") as Label).Text;
                ddlCompanyNameList.Items.FindByValue(companyNames).Selected = true;
            }
        }

        protected void Product_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            if (ProductGridView.EditIndex >= -1)
            {
                ProductGridView.EditIndex = -1;
            }
            BindGridView();
            PageGrid(sender, e);
        }
        
        protected void chkBoxResetCheckedChanged(object sender, EventArgs e)
        {
            if (ProductGridView.EditIndex >= -1)
            {
                ProductGridView.EditIndex = -1;
            }
            ddlProductCodeName.SelectedIndex = 0;
            ddlProductName.SelectedIndex = 0;
            ddlSubCategoryName.SelectedIndex = 0;
            ddlCommissionSubCategoryName.SelectedIndex = 0;
            ddlCompanyName.SelectedIndex = 0;
            BindGridView();
        }

        #endregion
  protected void btnSaveNewProduct_Click(object sender, EventArgs e)
        {
            bool isFormFilled = true;
            string display = "";
            ProductReportingChild li = new ProductReportingChild();
            string productCode = newProductCode.Text;
            string productName = newProductName.Text;
            string subCategoryName = newSubCategoryName.Text;
            string commissionSubCategoryName = newCommissionSubCategoryName.Text;
            string companyName = newCompanyName.Text;
            string effectiveDate = Request.Form[newEffectiveDate.UniqueID];
            
          
            if (String.IsNullOrEmpty(effectiveDate) || String.IsNullOrEmpty(productCode) 
                || String.IsNullOrEmpty(productName) || String.IsNullOrEmpty(subCategoryName)
                || String.IsNullOrEmpty(commissionSubCategoryName) || String.IsNullOrEmpty(companyName))
            {
                display = "Please select all the mandatory fields ";
                ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                isFormFilled = false;
            }
            

            if (isFormFilled)
            {
                DataSet result = li.AddNewProduct(productCode, productName, subCategoryName, commissionSubCategoryName, companyName, effectiveDate);
                
                string res = Convert.ToString(result.Tables[0].Rows[0].ItemArray[0]);

                if (res.Equals("Duplicate ProductCode"))
                {
                    display = "Product Code already exists in the database";
                    ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                    isFormFilled = false;
                }
                else if (res.Equals("Duplicate ProductName"))
                {
                    display = "Product Name already exists in the database";
                    ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                    isFormFilled = false;
                }
                else if (res.Equals("Success"))
                {
                    display = "A new Product is successfully added in the database";
                    ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                    isFormFilled = true;
                }
                if (isFormFilled)
                {
                    newProductCode.Text = "";
                    newProductName.Text = "";
                    ddlSubCategoryName.DataSource = li.SubCategoryNameList().Tables[0];
                    ddlSubCategoryName.DataTextField = "SubCategoryName";
                    ddlSubCategoryName.DataBind();
                    ddlCommissionSubCategoryName.DataSource = li.CommissionSubCategoryNameList().Tables[0];
                    ddlCommissionSubCategoryName.DataTextField = "CommissionSubCategoryName";
                    ddlCommissionSubCategoryName.DataBind();
                    ddlCompanyName.DataSource = li.CompanyNameList().Tables[0];
                    ddlCompanyName.DataTextField = "CompanyName";
                    ddlCompanyName.DataBind();
                    BindGridView();
                }         
            }
        }

        protected void btnAddNewProduct_Click(object sender, EventArgs e)
        {
            ModalPopupExtender1.Show();
        }

        protected void ddl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ProductGridView.EditIndex >= -1)
            {
                ProductGridView.EditIndex = -1;
            }
            BindGridView();
        }

        private void BindGridView()
        {
            int count;
            ProductReportingChild obj = new ProductReportingChild();
           
            string productCode = ddlProductCodeName.SelectedValue.ToString();
            string productName = ddlProductName.SelectedValue.ToString();
            string subCategoryName = ddlSubCategoryName.SelectedValue.ToString();
            string commissionSubCategoryName = ddlCommissionSubCategoryName.SelectedValue.ToString();
            string companyName = ddlProductName.SelectedValue.ToString();
            DataSet ds = obj.GetSKPickingBoard2(productCode, productName, subCategoryName, commissionSubCategoryName, companyName);
            ProductGridView.DataSource = ds.Tables[0];
            ProductGridView.DataBind();
            count = ds.Tables[0].Rows.Count;
            if (count > 1)
            {
                lblRecordCount.Text = "Record Count: " + count;
            }
            else
            {
                lblRecordCount.Text = "Record Count: " + count;
            }
            
        }
                
        protected void btnExportToExcel_Click(object sender, EventArgs e)
        {
            ProductReportingChild obj = new ProductReportingChild();
            DataSet ds = obj.GetSKPickingBoard2("Select One", "Select One", "Select One", "Select One", "Select One");//, "Select One", "Select One", "Select One", "Select One", "Select One", "Select One", "Select One", "Select One", "Select One", "Select One", "Select One");

            WorkbookEngine we = new WorkbookEngine();
            we.ExportDataSetToExcel(ds.Tables[0], "Product Sales Reporting");
        }
    }
}