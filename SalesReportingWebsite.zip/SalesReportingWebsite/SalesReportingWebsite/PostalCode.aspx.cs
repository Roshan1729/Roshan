﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SalesReportingWebsite
{
    public partial class PostalCode : PageBase
    {
        public int memberships;
        protected void Page_Load(object sender, EventArgs e)
        {

            //VBFunctions.ADFunctions obj = new VBFunctions.ADFunctions();
            //string userID = obj.GetUserName();
            //// string dirEntry = obj.GetDirectoryEntry();
            //memberships = obj.VerifyGroupMemberships("LDAP://192.168.100.3/ou=Cooper Network Users,dc=coopersurgical1,dc=com", "coopservice", "^CSIServ2016!", userID);

            if (!Page.IsPostBack)

            {
                PostalCodeReportingChild li = new PostalCodeReportingChild();

                DataTable table = new DataTable();



                ddlPostalCodeCityName.DataSource = li.PostalCodeCityNameList().Tables[0];
                ddlPostalCodeCityName.DataTextField = "PostalCodeCityName";
                ddlPostalCodeCityName.DataBind();

                ddlStateProvinceName.DataSource = li.StateProvinceNameList().Tables[0];
                ddlStateProvinceName.DataTextField = "StateProvinceName";
                ddlStateProvinceName.DataBind();


                ddlCountryName.DataSource = li.CountryNameList().Tables[0];
                ddlCountryName.DataTextField = "CountryName";
                ddlCountryName.DataBind();

                ddlTerritoryName.DataSource = li.TerritoryNameList().Tables[0];
                ddlTerritoryName.DataTextField = "TerritoryName";
                ddlTerritoryName.DataBind();

                ddlCompanyName.DataSource = li.CompanyNameList().Tables[0];
                ddlCompanyName.DataTextField = "CompanyName";
                ddlCompanyName.DataBind();

                ddlDistributionRegionName.DataSource = li.DistributionRegionNameList().Tables[0];
                ddlDistributionRegionName.DataTextField = "DistributionRegionName";
                ddlDistributionRegionName.DataBind();


                //newCategoryName.DataSource = li.CategoryNameList().Tables[0];
                //newCategoryName.DataTextField = "CategoryName";
                //newCategoryName.DataBind();

                //newCommissionSubCategoryName.DataSource = li.CommissionSubCategoryNameList().Tables[0];
                //newCommissionSubCategoryName.DataTextField = "CommissionSubCategoryName";
                //newCommissionSubCategoryName.DataBind();

                //newCommissionCategoryName.DataSource = li.CommissionCategoryNameList().Tables[0];
                //newCommissionCategoryName.DataTextField = "CommissionCategoryName";
                //newCommissionCategoryName.DataBind();

                BindGridView();
            }
        }

        #region EventHandling

        protected void PostalCode_RowEditing(object sender, GridViewEditEventArgs e)
        {
            PostalCodeGridView.EditIndex = e.NewEditIndex;
            int index = e.NewEditIndex;
            GridViewRow row = PostalCodeGridView.Rows[e.NewEditIndex];

            BindGridView();
        }

        protected void PostalCode_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            PostalCodeGridView.EditIndex = -1;
            BindGridView();
        }


        protected void PostalCode_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            if (Page.IsValid)
            {
                PostalCodeReportingChild li = new PostalCodeReportingChild();
                GridViewRow row = PostalCodeGridView.Rows[e.RowIndex];
                string display = "";
                bool isFormFilled = true;
                try
                {
                    li.PostalCodeID = Convert.ToInt32(PostalCodeGridView.DataKeys[e.RowIndex].Values[0]);

                    if (((TextBox)row.FindControl("PostalCode")).Text != string.Empty)
                    {
                        li.PostalCode = Convert.ToInt32(((TextBox)row.FindControl("PostalCode")).Text);
                    }
                    else
                    {
                        display = "Postal Code cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    

                    if (((TextBox)row.FindControl("PostalCodeCityName")).Text != string.Empty)
                    {
                        li.PostalCodeCityName = Convert.ToString(((TextBox)row.FindControl("PostalCodeCityName")).Text);
                    }
                    else
                    {
                        display = "Postal Code City Name cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (((DropDownList)row.FindControl("StateProvinceName")).SelectedValue != "Select One")
                    {
                        li.StateProvinceName = ((DropDownList)row.FindControl("StateProvinceName")).SelectedValue;
                    }
                    else
                    {
                        display = "Select State Province Name from dropdown";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }


                    if (((DropDownList)row.FindControl("CountryName")).SelectedValue != "Select One")
                    {
                        li.CountryName = ((DropDownList)row.FindControl("CountryName")).SelectedValue;
                    }
                    else
                    {
                        display = "Select Country Name from dropdown";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }


                    if (((DropDownList)row.FindControl("TerritoryName")).SelectedValue != "Select One")
                    {
                        li.TerritoryName = ((DropDownList)row.FindControl("TerritoryName")).SelectedValue;
                    }
                    else
                    {
                        display = "Select Territory Name from dropdown";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (((DropDownList)row.FindControl("CompanyName")).SelectedValue != "Select One")
                    {
                        li.CompanyName = ((DropDownList)row.FindControl("CompanyName")).SelectedValue;
                    }
                    else
                    {
                        display = "Select Company Name from dropdown";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (((DropDownList)row.FindControl("DistributionRegionName")).SelectedValue != "Select One")
                    {
                        li.DistributionRegionName = ((DropDownList)row.FindControl("DistributionRegionName")).SelectedValue;
                    }
                    else
                    {
                        display = "Select Distribution Region Name from dropdown";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }
                    if (!String.IsNullOrEmpty(Convert.ToString((Request.Form[row.FindControl("EffectiveDate").UniqueID]))))
                    {
                        li.EffectiveDate = Convert.ToDateTime((Request.Form[row.FindControl("EffectiveDate").UniqueID]));
                    }
                    else
                    {
                        display = "Effective Date cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (!String.IsNullOrEmpty(Convert.ToString((Request.Form[row.FindControl("ExpirationDate").UniqueID]))))
                    {
                        li.ExpirationDate = Convert.ToDateTime((Request.Form[row.FindControl("ExpirationDate").UniqueID]));
                    }
                    else
                    {
                        display = "Expiration Date cannot be empty";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (li.ExpirationDate < li.EffectiveDate)
                    {
                        display = "Expiration Date must be after Effective date";
                        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        isFormFilled = false;
                    }

                    if (isFormFilled)
                    {
                        DataSet result = li.UpdateSKPickingBoard(li, memberships);

                        string res = Convert.ToString(result.Tables[0].Rows[0].ItemArray[0]);

                        if (res.Equals("Duplicate PostalCode"))
                        {
                            display = "Sub Postal Code already exists in the database";
                            ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        }
                        else if (res.Equals("Duplicate PostalCityName"))
                        {
                            display = "Sub Postal City Name already exists in the database";
                            ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
                        }
                       
                        else if (res.Equals("Success"))
                        {
                        }
                    }
                    //if (memberships > 0)
                    //{
                    //    li.UpdateSKPickingBoard(li, memberships);
                    //}
                    //else
                    //{
                    //    string display = "You must be a member of SK_Picking _Operations or SK_Picking_Warehouse groups to make changes.";
                    //    ClientScript.RegisterStartupScript(this.GetType(), "yourMessage", "alert('" + display + "');", true);
                    //}

                }
                catch (Exception ex)
                {
                    throw ex;
                }

                PostalCodeGridView.EditIndex = -1;
                BindGridView();
            }
        }

        protected void PostalCode_SortData(object sender, GridViewSortEventArgs e)
        {
            if (PostalCodeGridView.EditIndex >= -1)
            {
                PostalCodeGridView.EditIndex = -1;
            }
            BindGridView();
            SortGrid(sender, e);
        }

        protected void PostalCode_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow && PostalCodeGridView.EditIndex == e.Row.RowIndex)
            {
                PostalCodeReportingChild li = new PostalCodeReportingChild();


                //Find the DropDownList in the Row
                DropDownList ddlStateProvinceNameList = (e.Row.FindControl("StateProvinceName") as DropDownList);
                ddlStateProvinceNameList.DataSource = li.StateProvinceNameList().Tables[0];
                ddlStateProvinceNameList.DataTextField = "StateProvinceName";
                ddlStateProvinceNameList.DataValueField = "StateProvinceName";
                ddlStateProvinceNameList.DataBind();

                //Add Default Item in the DropDownList
                ddlStateProvinceNameList.Items.Insert(0, new ListItem("Select One"));

                //Select the Country of Customer in DropDownList
                string stateProvinceNames = (e.Row.FindControl("lblStateProvinceName") as Label).Text;
                ddlStateProvinceNameList.Items.FindByValue(stateProvinceNames).Selected = true;


                //Find the DropDownList in the Row
                DropDownList ddlCountryNameList = (e.Row.FindControl("CountryName") as DropDownList);
                ddlCountryNameList.DataSource = li.CountryNameList().Tables[0];
                ddlCountryNameList.DataTextField = "CountryName";
                ddlCountryNameList.DataValueField = "CountryName";
                ddlCountryNameList.DataBind();

                //Add Default Item in the DropDownList
                ddlCountryNameList.Items.Insert(0, new ListItem("Select One"));

                //Select the Country of Customer in DropDownList
                string countryNames = (e.Row.FindControl("lblCountryName") as Label).Text;
                ddlCountryNameList.Items.FindByValue(countryNames).Selected = true;


                //Find the DropDownList in the Row
                DropDownList ddlTerritoryNameList = (e.Row.FindControl("TerritoryName") as DropDownList);
                ddlTerritoryNameList.DataSource = li.TerritoryNameList().Tables[0];
                ddlTerritoryNameList.DataTextField = "TerritoryName";
                ddlTerritoryNameList.DataValueField = "TerritoryName";
                ddlTerritoryNameList.DataBind();

                //Add Default Item in the DropDownList
                ddlTerritoryNameList.Items.Insert(0, new ListItem("Select One"));

                //Select the Country of Customer in DropDownList
                string territoryNames = (e.Row.FindControl("lblTerritoryName") as Label).Text;
                ddlTerritoryNameList.Items.FindByValue(territoryNames).Selected = true;

                //Find the DropDownList in the Row
                DropDownList ddlCompanyNameList = (e.Row.FindControl("CompanyName") as DropDownList);
                ddlCompanyNameList.DataSource = li.CompanyNameList().Tables[0];
                ddlCompanyNameList.DataTextField = "CompanyName";
                ddlCompanyNameList.DataValueField = "CompanyName";
                ddlCompanyNameList.DataBind();

                //Add Default Item in the DropDownList
                ddlCompanyNameList.Items.Insert(0, new ListItem("Select One"));

                //Select the Country of Customer in DropDownList
                string companyNames = (e.Row.FindControl("lblCompanyName") as Label).Text;
                ddlCompanyNameList.Items.FindByValue(companyNames).Selected = true;

                //Find the DropDownList in the Row
                DropDownList ddlDistributionRegionNameList = (e.Row.FindControl("DistributionRegionName") as DropDownList);
                ddlDistributionRegionNameList.DataSource = li.DistributionRegionNameList().Tables[0];
                ddlDistributionRegionNameList.DataTextField = "DistributionRegionName";
                ddlDistributionRegionNameList.DataValueField = "DistributionRegionName";
                ddlDistributionRegionNameList.DataBind();

                //Add Default Item in the DropDownList
                ddlDistributionRegionNameList.Items.Insert(0, new ListItem("Select One"));

                //Select the Country of Customer in DropDownList
                string distributionRegionNames = (e.Row.FindControl("lblDistributionRegionName") as Label).Text;
                ddlDistributionRegionNameList.Items.FindByValue(distributionRegionNames).Selected = true;


            }
        }

        protected void PostalCode_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            if (PostalCodeGridView.EditIndex >= -1)
            {
                PostalCodeGridView.EditIndex = -1;
            }
            BindGridView();
            PageGrid(sender, e);
        }

        protected void chkBoxResetCheckedChanged(object sender, EventArgs e)
        {
            if (PostalCodeGridView.EditIndex >= -1)
            {
                PostalCodeGridView.EditIndex = -1;
            }
            //ddlCategoryName.SelectedIndex = 0;
            //ddlCommissionCategoryName.SelectedIndex = 0;
            BindGridView();
        }

        #endregion
        //protected void btnSaveNewSubCategory_Click(object sender, EventArgs e)
        //{
        //    bool isFormFilled = true;
        //    string display = "";
        //    SubCategoryReportingChild li = new SubCategoryReportingChild();
        //    string subCategorySequence = newSubCategorySequence.Text;
        //    string subCategoryCode = newSubCategoryCode.Text;
        //    string subCategoryName = newSubCategoryName.Text;
        //    string categoryName = newCategoryName.Text;
        //    string commissionSubCategoryCode = newCommissionSubCategoryCode.Text;
        //    string commissionSubCategoryName = newCommissionSubCategoryName.SelectedValue.ToString();
        //    string commissionCategoryName = newCommissionCategoryName.SelectedValue.ToString();
        //    string effectiveDate = Request.Form[newEffectiveDate.UniqueID];


        //    if (String.IsNullOrEmpty(effectiveDate) || String.IsNullOrEmpty(subCategorySequence)
        //        || String.IsNullOrEmpty(subCategoryCode) || String.IsNullOrEmpty(categoryName) || String.IsNullOrEmpty(subCategoryName)
        //        || String.IsNullOrEmpty(commissionSubCategoryCode) || String.IsNullOrEmpty(commissionCategoryName) || String.IsNullOrEmpty(commissionSubCategoryName))
        //    {
        //        display = "Please select all the mandatory fields ";
        //        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
        //        isFormFilled = false;
        //    }


        //    if (isFormFilled)
        //    {
        //        DataSet result = li.AddNewSubCategory(subCategorySequence, subCategoryCode, subCategoryName, categoryName, commissionSubCategoryCode, commissionSubCategoryName, commissionCategoryName, effectiveDate);

        //        string res = Convert.ToString(result.Tables[0].Rows[0].ItemArray[0]);

        //        if (res.Equals("Duplicate SubCategoryCode"))
        //        {
        //            display = "Sub Category Code already exists in the database";
        //            ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
        //            isFormFilled = false;
        //        }
        //        else if (res.Equals("Duplicate SubCategoryName"))
        //        {
        //            display = "Sub Category Name already exists in the database";
        //            ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
        //            isFormFilled = false;
        //        }
        //        else if (res.Equals("Duplicate CommissionSubCategoryCode"))
        //        {
        //            display = "Commission Sub Category Code already exists in the database";
        //            ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
        //            isFormFilled = false;
        //        }
        //        else if (res.Equals("Success"))
        //        {
        //            display = "A new Category is successfully added in the database";
        //            ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('" + display + "');", true);
        //            isFormFilled = true;
        //        }
        //        if (isFormFilled)
        //        {
        //            newSubCategorySequence.Text = "";
        //            newSubCategoryCode.Text = "";
        //            newSubCategoryName.Text = "";
        //            newCategoryName.SelectedIndex = 0;
        //            newCommissionSubCategoryCode.Text = "";
        //            newCommissionSubCategoryName.SelectedIndex = 0;
        //            newCommissionCategoryName.SelectedIndex = 0;
        //            BindGridView();
        //        }
        //    }
        //}

        //protected void btnAddNewSubCategory_Click(object sender, EventArgs e)
        //{
        //    ModalPopupExtender1.Show();
        //}

        protected void ddl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (PostalCodeGridView.EditIndex >= -1)
            {
                PostalCodeGridView.EditIndex = -1;
            }
            BindGridView();
        }

        private void BindGridView()
        {
            int count;
            PostalCodeReportingChild obj = new PostalCodeReportingChild();

            string postalCodeCityName = ddlPostalCodeCityName.SelectedValue.ToString();
            string stateProvinceName = ddlStateProvinceName.SelectedValue.ToString();
            string countryName = ddlCountryName.SelectedValue.ToString();
            string territoryName = ddlTerritoryName.SelectedValue.ToString();
            string companyName = ddlCompanyName.SelectedValue.ToString();
            string distributionRegionName = ddlDistributionRegionName.SelectedValue.ToString();
            DataSet ds = obj.GetSKPickingBoard2(postalCodeCityName, stateProvinceName, countryName, territoryName, companyName, distributionRegionName);
            PostalCodeGridView.DataSource = ds.Tables[0];
            PostalCodeGridView.DataBind();
            count = ds.Tables[0].Rows.Count;
            if (count > 1)
            {
                lblRecordCount.Text = "Record Count: " + count;
            }
            else
            {
                lblRecordCount.Text = "Record Count: " + count;
            }

        }

        protected void btnExportToExcel_Click(object sender, EventArgs e)
        {
            PostalCodeReportingChild obj = new PostalCodeReportingChild();
            DataSet ds = obj.GetSKPickingBoard2("Select One", "Select One", "Select One", "Select One", "Select One", "Select One");

            WorkbookEngine we = new WorkbookEngine();
            we.ExportDataSetToExcel(ds.Tables[0], "Sales Reporting");
        }
    }
}