﻿Imports Microsoft.VisualBasic
Imports System.DirectoryServices

Public Class ADFunctions
    Function GetUserName() As String
        'If TypeOf My.User.CurrentPrincipal Is 
        'Security.Principal.WindowsPrincipal Then
        'The application is using Windows authentication
        'The name format is DOMAIN\USERNAME.
        Dim parts() As String = Split(My.User.Name, "\")
        Dim userName As String = parts(1)
        'MsgBox(userName)
        Return userName
        'Else
        'The application is using custom authentication
        'Return My.User.Name
        'End If
    End Function

    'Function GetDirectoryEntry(path As String, userName As String, password As String) As DirectoryEntry
    'Dim dirEntry As DirectoryEntry = New DirectoryEntry()
    'dirEntry.Path = path
    'dirEntry.Username = userName
    'dirEntry.Password = password
    'Return dirEntry
    'End Function

    Function VerifyGroupMemberships(ByVal _path As String, ByVal username As String, ByVal password As String, ByVal userid As String) As Integer
        Dim result As Integer '0 = No Access, 1 = SK_Picking_Operations, 2 = SK_Picking_Warehouse, 3 = Both
        'Dim Groups As New Collection
        Dim dirEntry As New System.DirectoryServices.DirectoryEntry(_path, username, password)
        Dim dirSearcher As New DirectorySearcher(dirEntry)
        dirSearcher.Filter = String.Format("(&(objectClass=User)(sAMAccountName={0}))", userid)
        dirSearcher.PropertiesToLoad.Add("memberOf")
        Dim propCount As Integer
        Dim groupID As Integer = 0
        Try
            Dim dirSearchResults As SearchResult = dirSearcher.FindOne()
            propCount = dirSearchResults.Properties("memberOf").Count
            Dim dn As String
            Dim equalsIndex As String
            Dim commaIndex As String

            For i As Integer = 0 To propCount - 1
                dn = dirSearchResults.Properties("memberOf")(i)
                'MsgBox(dn)
                If (dn.Contains("Consolidated Sales Reporting – Admin")) Then
                    groupID = 1
                End If

                If (dn.Contains("Consolidated Sales Reporting – Finance")) Then
                    groupID = 2
                End If

                If (dn.Contains("Consolidated Sales Reporting – Commission")) Then
                    groupID = 3
                End If

                If (dn.Contains("Consolidated Sales Reporting – Sales")) Then
                    groupID = 4
                End If

                equalsIndex = dn.IndexOf("=", 1)
                commaIndex = dn.IndexOf(",", 1)
                If equalsIndex = -1 Then
                    Return Nothing
                End If
                'If Not Groups.Contains(dn.Substring((equalsIndex + 1), (commaIndex - equalsIndex) - 1)) Then
                'Groups.Add(dn.Substring((equalsIndex + 1), (commaIndex - equalsIndex) - 1))
                'End If
            Next
            Return groupID

        Catch ex As Exception
            If ex.GetType Is GetType(System.NullReferenceException) Then
                MsgBox("Selected user isn't a member of any groups at this time.", "No groups listed")
                'they are still a good user just does not
                'have a "memberOf" attribute so it errors out.
                'code to do something else here if you want
            Else
            End If
            'MsgBox(ex.Message.ToString)
        End Try
        Return result
    End Function

    'Function MyInStr(myString As String, array() As String) As Boolean
    'For Each elem As String In array
    'If myString.Contains(elem) Then Return True
    'Next
    'Return False
    'End Function
End Class



