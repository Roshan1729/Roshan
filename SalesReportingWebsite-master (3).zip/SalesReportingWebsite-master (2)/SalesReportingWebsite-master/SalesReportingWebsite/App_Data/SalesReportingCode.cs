﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for LowInventory
/// </summary>
public abstract class SalesReportingCode
{
    public SalesReportingCode()
    {
        _part_Number = string.Empty;
        _work_order = string.Empty;
        _notes = string.Empty;
        _picked_Complete = false;
        _date_Requested = DateTime.MinValue;
        _assigned_To = string.Empty;
        _inv_Status_ID = string.Empty;
    }

    private string _part_Number;
    private string _work_order;
    private string _notes;
    private Boolean _picked_Complete;
    private DateTime _date_Requested;
    private string _assigned_To;
    private string _inv_Status_ID;

    public string Part_Number
    {
        get { return _part_Number; }
        set { _part_Number = value; }
    }

    public string Work_Order
    {
        get { return _work_order; }
        set { _work_order = value; }
    }
    public string Notes
    {
        get { return _notes; }
        set { _notes = value; }
    }

    public Boolean Picked_Complete
    {
        get { return _picked_Complete; }
        set { _picked_Complete = value; }
    }

    public DateTime Date_Requested
    {
        get { return _date_Requested; }
        set { _date_Requested = value; }
    }

    public string Assigned_To
    {
        get { return _assigned_To; }
        set { _assigned_To = value; }
    }

    public string Inventory_Status
    {
        get { return _inv_Status_ID; }
        set { _inv_Status_ID = value; }
    }

    public DataSet GetSKPickingBoard(string fromDate, string toDate, string period, string fromQuantity, string toQuantity, string fromAmount, string toAmount, string adjustmentType, string countryName, string subBusinessUnitName, string companyName, string subSegmentName, string accountSubTypeName, string subCategoryName, string rblMeasurementSystemText)
    {
        DataSet ds = new DataSet();

        using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString()))
            try
            {
                using (SqlCommand cmd = new SqlCommand("dbo.Web_SR_GetAdjustmentRecords", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    if (fromDate == "Select One" || fromDate == string.Empty || String.IsNullOrEmpty(fromDate))
                    {
                        cmd.Parameters.AddWithValue("FromDate", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("FromDate", Convert.ToDateTime(fromDate));
                    }

                    if (toDate == "Select One" || toDate == string.Empty|| String.IsNullOrEmpty(toDate))
                    {
                        cmd.Parameters.AddWithValue("ToDate", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("ToDate", Convert.ToDateTime(toDate));
                    }

                    if (period == "Select One")
                    {
                        cmd.Parameters.AddWithValue("Period", DBNull.Value);
                    }
                    else if (period == string.Empty)
                    {
                        cmd.Parameters.AddWithValue("Period", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("Period", period);
                    }

                    if (fromQuantity == "Select One" || fromQuantity == string.Empty)
                    {
                        cmd.Parameters.AddWithValue("FromQuantity", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("FromQuantity", Convert.ToInt32(fromQuantity));
                    }

                    if (toQuantity == "Select One" || toQuantity == string.Empty)
                    {
                        cmd.Parameters.AddWithValue("ToQuantity", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("ToQuantity", Convert.ToInt32(toQuantity));
                    }

                    if (fromAmount == "Select One" || fromAmount == string.Empty)
                    {
                        cmd.Parameters.AddWithValue("FromAmount", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("FromAmount", Convert.ToInt32(fromAmount));
                    }

                    if (toAmount == "Select One" || toAmount == string.Empty)
                    {                        
                        cmd.Parameters.AddWithValue("ToAmount", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("ToAmount", Convert.ToInt32(toAmount));
                    }

                    if (adjustmentType == "Select One")
                    {
                        cmd.Parameters.AddWithValue("AdjustmentTypeName", DBNull.Value);
                    }
                    else if (adjustmentType == string.Empty)
                    {
                        cmd.Parameters.AddWithValue("AdjustmentTypeName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("AdjustmentTypeName", adjustmentType);
                    }

                    if (countryName == "Select One")
                    {
                        cmd.Parameters.AddWithValue("CountryName", DBNull.Value);
                    }
                    else if (countryName == string.Empty)
                    {
                        cmd.Parameters.AddWithValue("CountryName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("CountryName", countryName);
                    }

                    if (subBusinessUnitName == "Select One")
                    {
                        cmd.Parameters.AddWithValue("SubBusinessUnitName", DBNull.Value);
                    }
                    else if (subBusinessUnitName == string.Empty)
                    {
                        cmd.Parameters.AddWithValue("SubBusinessUnitName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("SubBusinessUnitName", subBusinessUnitName);
                    }

                    if (companyName == "Select One")
                    {
                        cmd.Parameters.AddWithValue("CompanyName", DBNull.Value);
                    }
                    else if (companyName == string.Empty)
                    {
                        cmd.Parameters.AddWithValue("CompanyName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("CompanyName", companyName);
                    }

                    if (subSegmentName == "Select One")
                    {
                        cmd.Parameters.AddWithValue("SubSegmentName", DBNull.Value);
                    }
                    else if (subSegmentName == string.Empty)
                    {
                        cmd.Parameters.AddWithValue("SubSegmentName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("SubSegmentName", subSegmentName);
                    }

                    if (accountSubTypeName == "Select One")
                    {
                        cmd.Parameters.AddWithValue("AccountSubTypeName", DBNull.Value);
                    }
                    else if (accountSubTypeName == string.Empty)
                    {
                        cmd.Parameters.AddWithValue("AccountSubTypeName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("AccountSubTypeName", accountSubTypeName);
                    }

                    if (subCategoryName == "Select One")
                    {
                        cmd.Parameters.AddWithValue("SubCategoryName", DBNull.Value);
                    }
                    else if (subCategoryName == string.Empty)
                    {
                        cmd.Parameters.AddWithValue("SubCategoryName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("SubCategoryName", subCategoryName);
                    }

                    if (rblMeasurementSystemText == "Select One")
                    {
                        cmd.Parameters.AddWithValue("AdjustmentPeriod", DBNull.Value);
                    }
                    else if (rblMeasurementSystemText == string.Empty)
                    {
                        cmd.Parameters.AddWithValue("AdjustmentPeriod", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("AdjustmentPeriod", rblMeasurementSystemText);
                    }

                    connection.Open();
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(ds);
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        return ds;
    }
    
    public void UpdateSKPickingBoard(SalesReportingChild li, int memberships)
    {
        SqlConnection sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString());
        string spName = "";
        if (memberships == 3)
        {
            spName = "web_SKPB_UpdateSKPickBoardAll";
        }
        else if (memberships == 2)
        {
            spName = "web_SKPB_UpdateSKPickBoardWarehouse";
        }
        else if (memberships == 1)
        {
            spName = "web_SKPB_UpdateSKPickBoardOperations";
        }
        SqlCommand sqlCmd = new SqlCommand(spName, sqlConn);
        sqlCmd.CommandType = CommandType.StoredProcedure;

        if (memberships == 3)
        {

            sqlCmd.Parameters.Add("@partNum", SqlDbType.VarChar).Value = li._part_Number;
            sqlCmd.Parameters.Add("@WorkOrder", SqlDbType.VarChar).Value = li._work_order;
            if (li.Date_Requested == DateTime.MinValue)
            {
                sqlCmd.Parameters.Add("@Date_Requested", SqlDbType.DateTime).Value = DBNull.Value;
            }
            else
            {
                sqlCmd.Parameters.Add("@Date_Requested", SqlDbType.DateTime).Value = li._date_Requested;
            }
            sqlCmd.Parameters.Add("@Notes", SqlDbType.VarChar).Value = li._notes;
            sqlCmd.Parameters.Add("@Picked_Complete", SqlDbType.Bit).Value = li._picked_Complete;
            sqlCmd.Parameters.Add("@Assigned_To", SqlDbType.VarChar).Value = li._assigned_To;

            if (li._inv_Status_ID == "")
            {
                sqlCmd.Parameters.Add("@Inventory_Status_ID", SqlDbType.Int).Value = DBNull.Value;
            }
            else
            {
                sqlCmd.Parameters.Add("@Inventory_Status_ID", SqlDbType.Int).Value = li._inv_Status_ID;
            }
        }

        if (memberships == 1)
        {
            sqlCmd.Parameters.Add("@partNum", SqlDbType.VarChar).Value = li._part_Number;
            sqlCmd.Parameters.Add("@WorkOrder", SqlDbType.VarChar).Value = li._work_order;

            if (li.Date_Requested == DateTime.MinValue)
            {
                sqlCmd.Parameters.Add("@Date_Requested", SqlDbType.DateTime).Value = DBNull.Value;
            }
            else
            {
                sqlCmd.Parameters.Add("@Date_Requested", SqlDbType.DateTime).Value = li._date_Requested;
            }
            sqlCmd.Parameters.Add("@Notes", SqlDbType.VarChar).Value = li._notes;

            if (li._inv_Status_ID == "")
            {
                sqlCmd.Parameters.Add("@Inventory_Status_ID", SqlDbType.Int).Value = DBNull.Value;
            }
            else
            {
                sqlCmd.Parameters.Add("@Inventory_Status_ID", SqlDbType.Int).Value = li._inv_Status_ID;
            }
        }

        if (memberships == 2)
        {
            sqlCmd.Parameters.Add("@partNum", SqlDbType.VarChar).Value = li._part_Number;
            sqlCmd.Parameters.Add("@WorkOrder", SqlDbType.VarChar).Value = li._work_order;
            sqlCmd.Parameters.Add("@Notes", SqlDbType.VarChar).Value = li._notes;
            sqlCmd.Parameters.Add("@Picked_Complete", SqlDbType.Bit).Value = li._picked_Complete;
            sqlCmd.Parameters.Add("@Assigned_To", SqlDbType.VarChar).Value = li._assigned_To;

            if (li._inv_Status_ID == "")
            {
                sqlCmd.Parameters.Add("@Inventory_Status_ID", SqlDbType.Int).Value = DBNull.Value;
            }
            else
            {
                sqlCmd.Parameters.Add("@Inventory_Status_ID", SqlDbType.Int).Value = li._inv_Status_ID;
            }
        }

        try
        {
            sqlConn.Open();
            sqlCmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public DataSet GetSKPickingBoardWithParameters(string partNum, string Planner, string CommCode)
    {
        DataSet ds = new DataSet();
        SqlConnection sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString());

        try
        {
            // SqlCommand sqlCmd = new SqlCommand("Web_GetLowInventory", sqlConn);
            // sqlCmd.CommandType = CommandType.StoredProcedure;
            sqlConn.Open();
            SqlDataAdapter da = new SqlDataAdapter("Web_SKPB_GetSKPickBoard", sqlConn);
            da.Fill(ds);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            sqlConn.Close();
        }
        return ds;
    }
}
