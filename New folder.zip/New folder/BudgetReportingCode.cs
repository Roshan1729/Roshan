﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for LowInventory
/// </summary>
public abstract class BudgetReportingCode
{
    public  BudgetReportingCode()
    {

        _BudgetID = 0;
        
        _Date = DateTime.MinValue;
        _FiscalYear = 0;
        _Period = String.Empty;
        _Quantity = 0;
        _AmountLCY = 0;
        _AmountUSD = 0;
        _CostLCY = 0;
        _CostUSD = 0;
        _CurrencyID = 0;
        _CurrencyCode = String.Empty;
        _CountryID = 0;
        _CountryName = String.Empty;
        _SubCategoryID = 0;
        _SubCategoryName = String.Empty;
        _CompanyID = 0;
        _CompanyName = String.Empty;
        _SubBusinessUnitID = 0;
        _SubBusinessUnitName = String.Empty;
        _EffectiveDate = DateTime.MinValue;
        _ExpirationDate = DateTime.MinValue;

    }

    private int _BudgetID;
    private int _FiscalYear;
    private DateTime _Date;
    private string _Period;
    private float _Quantity;
    private float _AmountLCY;
    private float _AmountUSD;
    private float _CostLCY;
    private float _CostUSD;
    private int _CurrencyID;
    private string _CurrencyCode;
    private int _CountryID;
    private string _CountryName;
    private int _SubCategoryID;
    private string _SubCategoryName;
    private int _CompanyID;
    private string _CompanyName;
    private int _SubBusinessUnitID;
    private string _SubBusinessUnitName;
    private DateTime _EffectiveDate;
    private DateTime _ExpirationDate;


    public int BudgetID
    {
        get { return _BudgetID; }
        set { _BudgetID = value; }
    }

   

    public DateTime Date
    {
        get { return _Date; }
        set { _Date = value; }
    }

    public int FiscalYear
    {
        get { return _FiscalYear; }
        set { _FiscalYear = value; }
    }

    public string Period
    {
        get { return _Period; }
        set { _Period = value; }
    }
    public float Quantity
    {
        get { return _Quantity; }
        set { _Quantity = value; }
    }
    public float AmountLCY
    {
        get { return _AmountLCY; }
        set { _AmountLCY = value; }
    }
    public float AmountUSD
    {
        get { return _AmountUSD; }
        set { _AmountUSD = value; }
    }
    public float CostLCY
    {
        get { return _CostLCY; }
        set { _CostLCY = value; }
    }

    public float CostUSD
    {
        get { return _CostUSD; }
        set { _CostUSD = value; }
    }
   
    public int CurrencyID
    {
        get { return _CurrencyID; }
        set { _CurrencyID = value; }
    }


    public string CurrencyCode
    {
        get { return _CurrencyCode; }
        set { _CurrencyCode = value; }
    }

    public int CountryID
    {
        get { return _CountryID; }
        set { _CountryID = value; }
    }
    public string CountryName
    {
        get { return _CountryName; }
        set { _CountryName = value; }
    }

    public int SubCategoryID
    {
        get { return _SubCategoryID; }
        set { _SubCategoryID = value; }
    }


    public string SubCategoryName
    {
        get { return _SubCategoryName; }
        set { _SubCategoryName = value; }
    }

    public int CompanyID
    {
        get { return _CompanyID; }
        set { _CompanyID = value; }
    }

    public string CompanyName
    {
        get { return _CompanyName; }
        set { _CompanyName = value; }
    }

    public int SubBusinessUnitID
    {
        get { return _SubBusinessUnitID; }
        set { _SubBusinessUnitID = value; }
    }

    public string SubBusinessUnitName
    {
        get { return _SubBusinessUnitName; }
        set { _SubBusinessUnitName = value; }
    }

    public DateTime EffectiveDate
    {
        get { return _EffectiveDate; }
        set { _EffectiveDate = value; }
    }

    public DateTime ExpirationDate
    {
        get { return _ExpirationDate; }
        set { _ExpirationDate = value; }
    }



    public DataSet GetSKPickingBoard(string fiscalYear,string fromDate, string toDate, string period, string fromQuantity, string toQuantity, string fromAmountUSD, string toAmountUSD, string fromCostUSD, string toCostUSD, string companyName, string currencyCode, string subCategoryName, string countryName, string subBusinessUnitName)
    {
        DataSet ds = new DataSet();

        using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString()))
            try
            {
                using (SqlCommand cmd = new SqlCommand("dbo.Web_SR_GetBudgetRecords", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;


                    if (fiscalYear == "Select One" || String.IsNullOrEmpty(fiscalYear))
                    {
                        cmd.Parameters.AddWithValue("FiscalYear", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("FiscalYear", fiscalYear);
                    }


                    if (fromDate == "Select One" || String.IsNullOrEmpty(fromDate))
                    {
                        cmd.Parameters.AddWithValue("FromDate", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("FromDate", Convert.ToDateTime(fromDate));
                    }

                    if (toDate == "Select One" || String.IsNullOrEmpty(toDate))
                    {
                        cmd.Parameters.AddWithValue("ToDate", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("ToDate", Convert.ToDateTime(toDate));
                    }

                    if (period == "Select One" || String.IsNullOrEmpty(period))
                    {
                        cmd.Parameters.AddWithValue("Period", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("Period", period);
                    }

                    if (fromQuantity == "Select One" || String.IsNullOrEmpty(fromQuantity))
                    {
                        cmd.Parameters.AddWithValue("FromQuantity", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("FromQuantity", Convert.ToSingle(fromQuantity));
                    }

                    if (toQuantity == "Select One" || String.IsNullOrEmpty(toQuantity))
                    {
                        cmd.Parameters.AddWithValue("ToQuantity", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("ToQuantity", Convert.ToSingle(toQuantity));
                    }

                    if (fromAmountUSD == "Select One" || String.IsNullOrEmpty(fromAmountUSD))
                    {
                        cmd.Parameters.AddWithValue("FromAmountUSD", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("FromAmountUSD", Convert.ToSingle(fromAmountUSD));
                    }

                    if (toAmountUSD == "Select One" || String.IsNullOrEmpty(toAmountUSD))
                    {
                        cmd.Parameters.AddWithValue("ToAmountUSD", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("ToAmountUSD", Convert.ToSingle(toAmountUSD));
                    }

                    if (fromCostUSD == "Select One" || String.IsNullOrEmpty(fromCostUSD))
                    {
                        cmd.Parameters.AddWithValue("FromCostUSD", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("FromCostUSD", Convert.ToSingle(fromCostUSD));
                    }

                    if (toCostUSD == "Select One" || String.IsNullOrEmpty(toCostUSD))
                    {
                        cmd.Parameters.AddWithValue("ToCostUSD", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("ToCostUSD", Convert.ToSingle(toCostUSD));
                    }

                    if (currencyCode == "Select One" || String.IsNullOrEmpty(currencyCode))
                    {
                        cmd.Parameters.AddWithValue("CurrencyCode", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("CurrencyCode", currencyCode);
                    }

                    if (countryName == "Select One" || String.IsNullOrEmpty(countryName))
                    {
                        cmd.Parameters.AddWithValue("CountryName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("CountryName", countryName);
                    }

                    if (subBusinessUnitName == "Select One" || String.IsNullOrEmpty(subBusinessUnitName))
                    {
                        cmd.Parameters.AddWithValue("SubBusinessUnitName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("SubBusinessUnitName", subBusinessUnitName);
                    }

                    if (companyName == "Select One" || String.IsNullOrEmpty(companyName))
                    {
                        cmd.Parameters.AddWithValue("CompanyName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("CompanyName", companyName);
                    }


                    if (subCategoryName == "Select One" || String.IsNullOrEmpty(subCategoryName))
                    {
                        cmd.Parameters.AddWithValue("SubCategoryName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("SubCategoryName", subCategoryName);
                    }

                    

                    connection.Open();
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(ds);
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        return ds;
    }


    public void UpdateSKPickingBoard(BudgetReportingChild li, int memberships)
    {
        SqlConnection sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString());
        SqlCommand sqlCmd = new SqlCommand("dbo.Web_SR_UpdateBudgets", sqlConn);
        sqlCmd.CommandType = CommandType.StoredProcedure;

        //   if (memberships == 1 || memberships == 2)
        //   {

        sqlCmd.Parameters.Add("@BudgetID", SqlDbType.Int).Value = li.BudgetID;
        sqlCmd.Parameters.Add("@Date", SqlDbType.DateTime).Value = li.Date;
        sqlCmd.Parameters.Add("@Quantity", SqlDbType.Float).Value = li.Quantity;
        sqlCmd.Parameters.Add("@EffectiveDate", SqlDbType.DateTime).Value = li.EffectiveDate;
        sqlCmd.Parameters.Add("@ExpirationDate", SqlDbType.DateTime).Value = li.ExpirationDate;

        if (li.AmountLCY == 0)
        {
            sqlCmd.Parameters.Add("@AmountLCY", SqlDbType.Money).Value = DBNull.Value;
        }
        else
        {
            sqlCmd.Parameters.Add("@AmountLCY", SqlDbType.Money).Value = li.AmountLCY;
        }

        if (li.AmountUSD == 0)
        {
            sqlCmd.Parameters.Add("@AmountUSD", SqlDbType.Money).Value = DBNull.Value;
        }
        else
        {
            sqlCmd.Parameters.Add("@AmountUSD", SqlDbType.Money).Value = li.AmountUSD;
        }


        if (li.CostLCY == 0)
        {
            sqlCmd.Parameters.Add("@CostLCY", SqlDbType.Money).Value = DBNull.Value;
        }
        else
        {
            sqlCmd.Parameters.Add("@CostLCY", SqlDbType.Money).Value = li.CostLCY;
        }

        if (li.CostUSD == 0)
        {
            sqlCmd.Parameters.Add("@CostUSD", SqlDbType.Money).Value = DBNull.Value;
        }
        else
        {
            sqlCmd.Parameters.Add("@CostUSD", SqlDbType.Money).Value = li.CostUSD;
        }


        if (li.Period == string.Empty)
        {
            sqlCmd.Parameters.Add("@Period", SqlDbType.VarChar).Value = DBNull.Value;
        }
        else
        {
            sqlCmd.Parameters.Add("@Period", SqlDbType.VarChar).Value = li.Period;
        }

        if (li.FiscalYear == 0)
        {
            sqlCmd.Parameters.Add("@FiscalYear", SqlDbType.VarChar).Value = DBNull.Value;
        }
        else
        {
            sqlCmd.Parameters.Add("@FiscalYear", SqlDbType.VarChar).Value = li.FiscalYear;
        }
        
        if (li.CurrencyCode == string.Empty)
        {
            sqlCmd.Parameters.Add("@CurrencyCode", SqlDbType.VarChar).Value = DBNull.Value;
        }
        else
        {
            sqlCmd.Parameters.Add("@CurrencyCode", SqlDbType.VarChar).Value = li.CurrencyCode;
        }
        if (li.CountryName == string.Empty)
        {
            sqlCmd.Parameters.Add("@CountryName", SqlDbType.VarChar).Value = DBNull.Value;
        }
        else
        {
            sqlCmd.Parameters.Add("@CountryName", SqlDbType.VarChar).Value = li.CountryName;
        }
        if (li.SubBusinessUnitName == string.Empty)
        {
            sqlCmd.Parameters.Add("@SubBusinessUnitName", SqlDbType.VarChar).Value = DBNull.Value;
        }
        else
        {
            sqlCmd.Parameters.Add("@SubBusinessUnitName", SqlDbType.VarChar).Value = li.SubBusinessUnitName;
        }
        if (li.CompanyName == string.Empty)
        {
            sqlCmd.Parameters.Add("@CompanyName", SqlDbType.VarChar).Value = DBNull.Value;
        }
        else
        {
            sqlCmd.Parameters.Add("@CompanyName", SqlDbType.VarChar).Value = li.CompanyName;
        }
      
        if (String.IsNullOrEmpty(li.SubCategoryName))
        {
            sqlCmd.Parameters.Add("@SubCategoryName", SqlDbType.VarChar).Value = DBNull.Value;
        }
        else
        {
            sqlCmd.Parameters.Add("@SubCategoryName", SqlDbType.VarChar).Value = li.SubCategoryName;
        }

        if (String.IsNullOrEmpty(HttpContext.Current.User.Identity.Name))
        {
            sqlCmd.Parameters.Add("@UpdateUser", SqlDbType.VarChar).Value = "sysadmin";
        }
        else
        {
            sqlCmd.Parameters.Add("@UpdateUser", SqlDbType.VarChar).Value = HttpContext.Current.User.Identity.Name;
        }
        //  }

        try
        {
            sqlConn.Open();
            sqlCmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }


}
