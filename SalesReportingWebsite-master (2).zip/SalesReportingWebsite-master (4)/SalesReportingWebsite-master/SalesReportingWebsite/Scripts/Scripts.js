﻿$(function () {
    $("[id$=txtFromDate]").datepicker({
        showOn: 'button',
        buttonImageOnly: true,
        buttonImage: '../Image/calendar.png'
    });   
});

$(function () {
    $("[id$=txtToDate]").datepicker({
        showOn: 'button',
        buttonImageOnly: true,
        buttonImage: '../Image/calendar.png'
    });
});

$(function () {
    $("input[type=text][id*=AdjustmentDate]").datepicker({
        showOn: 'button',
        buttonImageOnly: true,
        buttonImage: '../Image/calendar.png'
    });
});


$(function () {
    $("#dialog").dialog({
        autoOpen: false,
        show: {
            effect: "blind",
            duration: 1000
        },
        hide: {
            effect: "explode",
            duration: 1000
        }
    });

    $("#btnAddNewAdjustments").on("click", function () {
        $("#dialog").dialog("open");
    });
    
});

